from __future__ import annotations
from flask import send_file
import hashlib, hmac, http.cookiejar, io, json, os, secrets, shutil, socket, ssl, subprocess, sys, threading, time, urllib.request, urllib.error, uuid, zipfile, platform, re, tempfile, tarfile
import zstandard
from urllib.parse import quote, urlencode, urlparse
import psutil
import paramiko
from datetime import datetime
from pathlib import Path
from typing import Any
from flask import Flask, Response, abort, flash, jsonify, redirect, render_template, request, session, stream_with_context, url_for, send_file
from waitress import serve
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
import ota_control as ota
from dataclasses import asdict
from release_gate import CheckResult,ReleaseEvidenceStore,ReleaseGatePolicy,ReleaseIdentity,TestRun
from predictive import DisabledAIProvider,HTTPJSONAIProvider,IncidentAIService,MetricStore,deterministic_suggestions,linear_forecast,recurring_failures,robust_anomaly
from agent_backend.system_health import collect_summary as collect_system_health_summary
from agent_backend.system_health import format_bytes as _bytes
from agent_backend.system_health import run_capture as _run_capture
from agent_backend.notifications import EmailChannel,NotificationDispatcher,TelegramChannel,WebChannel,environment_label
from deployment_platform import DeploymentComponent, DeploymentEnvironment, DeploymentEvidenceStore, RetentionPolicy, RetentionService
import agent_backend.db_backup as db_backup  # P4 Backup/DB/Storage Center -- referenced as db_backup.X to avoid
                                              # colliding with deployment_platform.RetentionService (release
                                              # retention, a different concern -- see db_backup.py module docstring).
import agent_backend.fleet as fleet  # P5 Multi-server: Server Registry / Fleet Health -- see fleet.py module docstring.
import agent_backend.incident_recovery as recovery  # Server Incident Recovery Console -- see incident_recovery.py module docstring.

AGENT_VERSION="2.24.48-docker-runtime"
# Bumped when the wire contract changes in a way a caller might need to
# branch on (new required fields, new endpoints a promotion depends on).
# Independent of AGENT_VERSION: two different AGENT_VERSION builds can
# share the same API_PROTOCOL_VERSION. Compatibility is judged by protocol
# + capabilities, never by comparing version strings.
API_PROTOCOL_VERSION=2
# Capabilities this Agent build actually implements. A promotion (or the
# DEV Target Agents table) checks REQUIRED_CAPABILITIES against this list
# -- never AGENT_VERSION strings -- to decide COMPATIBLE/INCOMPATIBLE.
AGENT_CAPABILITIES=["image_release_receive","digest_verify","remote_deploy","deploy_status","health_status","agent_self_update","qa_image_release_receive","qa_chunked_release_receive","qa_deploy","tutorial_chunked_release_receive","tutorial_deploy","tutorial_status","release_gate_evidence","operations_incidents","predictive_health","incident_ai_advisory","deployment_platform","build_once_local","mes_release_test_gate"]
AGENT_HOME=Path(os.environ.get("WORKSHOP_AGENT_HOME","/opt/mesflow-agent"))
TARGET_HOME=Path(os.environ.get("WORKSHOP_TARGET_HOME","/opt/mesflow"))
QA_HOME=Path(os.environ.get("MESFLOW_QA_HOME","/opt/mesflow-qa-center"))
HOST=os.environ.get("WORKSHOP_AGENT_HOST","0.0.0.0"); PORT=int(os.environ.get("WORKSHOP_AGENT_PORT","8090"))
MES_URL=os.environ.get("WORKSHOP_MES_URL","http://127.0.0.1:8080").rstrip("/")
QA_URL=os.environ.get("MESFLOW_QA_URL","http://mesflow-qa-center:8095").rstrip("/")
QA_PORT=int(os.environ.get("MESFLOW_QA_PORT","8095"))
QA_VERIFY_TIMEOUT=max(20,int(os.environ.get("MESFLOW_QA_VERIFY_TIMEOUT","60")))
RUNTIME_MODE=os.environ.get("MESFLOW_AGENT_RUNTIME","host").strip().lower() or "host"
DEPLOY_ENABLED=os.environ.get("MESFLOW_AGENT_DEPLOY_ENABLED","1").strip().lower() in {"1","true","yes","on"}
HOST_OPS_ENABLED=os.environ.get("MESFLOW_AGENT_HOST_OPS_ENABLED","1").strip().lower() in {"1","true","yes","on"}
MAX_UPLOAD_MB=int(os.environ.get("WORKSHOP_AGENT_MAX_UPLOAD_MB","1024")); URL_PREFIX=os.environ.get("WORKSHOP_AGENT_URL_PREFIX","/agent").rstrip("/")
MAX_EXTRACT_MB=int(os.environ.get("WORKSHOP_AGENT_MAX_EXTRACT_MB",str(MAX_UPLOAD_MB*4)))
MES_VERIFY_TIMEOUT=max(60,int(os.environ.get("WORKSHOP_MES_VERIFY_TIMEOUT","180")))
ZIP_EXTRACT_TIMEOUT=max(30,int(os.environ.get("WORKSHOP_AGENT_ZIP_EXTRACT_TIMEOUT","180")))
COMPOSE_VALIDATE_TIMEOUT=max(30,int(os.environ.get("WORKSHOP_AGENT_COMPOSE_VALIDATE_TIMEOUT","120")))
BUILD_TIMEOUT=max(300,int(os.environ.get("WORKSHOP_AGENT_BUILD_TIMEOUT","1800")))
IMAGE_RELEASE_TYPE="mesflow-image-release"
CONFIG_DIR=AGENT_HOME/"config"; DATA_DIR=AGENT_HOME/"data"; UPLOAD_DIR=DATA_DIR/"uploads"; RELEASES_DIR=DATA_DIR/"releases"; LOG_DIR=DATA_DIR/"logs"
STATE_FILE=DATA_DIR/"state.json"; CONFIG_FILE=CONFIG_DIR/"agent.json"; AGENT_LOG=LOG_DIR/"agent.log"
DEPLOY_TX_FILE=DATA_DIR/"deploy_transaction.json"; DEPLOY_LOCK_FILE=DATA_DIR/"deploy.lock"
QA_UPLOAD_DIR=DATA_DIR/"qa_uploads"; QA_LOG=LOG_DIR/"qa_process.log"
# QA_UPLOAD_DIR is scratch extraction space shared by the current
# /qa-release/upload receiver and _stage_qa_release_from_workspace_artifact
# (DEV's own Deploy Local). The legacy full-source QA deploy path that used
# to also share this directory (plus its own QA_RELEASES_DIR final-storage
# dir, /qa/upload, /qa/deploy/<version>, /qa/delete/<version>) was removed --
# see reports/RELEASE_DEPLOY_UX_CLEANUP.md.
QA_IMAGE_RELEASES_DIR=DATA_DIR/"qa_image_releases"
ESP_TUTORIAL_UPLOAD_DIR=DATA_DIR/"esp_tutorial_uploads"
TUTORIAL_UPLOAD_DIR=DATA_DIR/"tutorial_uploads"; TUTORIAL_ARTIFACT_DIR=DATA_DIR/"tutorial_artifacts"
TUTORIAL_UPLOAD_DIR.mkdir(parents=True,exist_ok=True); TUTORIAL_ARTIFACT_DIR.mkdir(parents=True,exist_ok=True)
ESP_TUTORIAL_HOME=Path(os.environ.get("MESFLOW_ESP_TUTORIAL_HOME",str(TARGET_HOME/"runtime/tutorials/esp-kiosk")))
ESP_TUTORIAL_MAX_MB=max(32,int(os.environ.get("MESFLOW_ESP_TUTORIAL_MAX_MB","512")))
def _default_workspace_root() -> Path:
    """Resolve the MESFlow workspace root when no explicit env var is set.

    The Agent frequently runs as root (systemd `User=root`, or root inside
    the Docker image), where `Path.home()` resolves to `/root` and silently
    produces a non-existent `/root/workspace/mesflow` instead of the real
    invoking user's workspace (e.g. `/home/dell/workspace/mesflow`). Prefer,
    in order: an explicit override, the sudo-invoking user's home, the
    login-owner of the controlling terminal, then finally `Path.home()`.
    """
    override = os.environ.get("MESFLOW_WORKSPACE_ROOT")
    if override:
        return Path(override).expanduser()
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user and sudo_user != "root":
        candidate = Path(f"/home/{sudo_user}/workspace/mesflow")
        if candidate.exists():
            return candidate
    if os.geteuid() == 0:
        try:
            login = os.getlogin()
        except OSError:
            login = ""
        if login and login != "root":
            candidate = Path(f"/home/{login}/workspace/mesflow")
            if candidate.exists():
                return candidate
    return Path.home()/"workspace/mesflow"

WORKSPACE_ROOT=_default_workspace_root()
ESP_BUILD_ENABLED=os.environ.get("ESP_BUILD_ENABLED","1").strip().lower() in {"1","true","yes","on"}
ESP_KIOSK_SOURCE_DIR=Path(os.environ.get("ESP_KIOSK_SOURCE_DIR",str(WORKSPACE_ROOT/"esp-kiosk"))).expanduser()
ESP_BUILDER_LOCK=threading.Lock()
MESFLOW_SOURCE_DIR=Path(os.environ.get("MESFLOW_SOURCE_DIR",str(WORKSPACE_ROOT/"mesflow"))).expanduser()
MESFLOW_BUILD_ENABLED=os.environ.get("MESFLOW_BUILD_ENABLED","1").strip().lower() in {"1","true","yes","on"}
MESFLOW_BUILD_LOCK=threading.Lock()
# task: AGENT_PACKAGE_BUILD_PUSH -- Build Agent Package (scripts/build-agent-release.sh).
# Same convention as MESFLOW_SOURCE_DIR/ESP_KIOSK_SOURCE_DIR: Path(__file__)
# resolves to /app/agent.py (the image's own baked copy, which does NOT
# include scripts/ -- see docker/Dockerfile's COPY list) inside a running
# container, not the workspace-mounted source the build script and its own
# `cd "$(dirname ...)/.."` need. An explicit env var (set in
# compose.dev.override.yml alongside MESFLOW_SOURCE_DIR) points this at the
# real bind-mounted workspace path.
DEPLOY_AGENT_SOURCE_DIR=Path(os.environ.get("DEPLOY_AGENT_SOURCE_DIR",str(WORKSPACE_ROOT/"deploy-agent"))).expanduser()
AGENT_PACKAGE_BUILD_LOCK=threading.Lock()
# Release retention: how many built application releases (artifacts/releases/
# <version>) to keep as full deployable artifacts (ZIP + local staging copy +
# Docker image). "3" means current + previous + previous-2 -- enough to
# support an immediate rollback plus one extra safety margin. Never affects
# database backups (DATA_DIR/mes_backups), which are retained separately and
# untouched by _cleanup_old_releases(). See docs/operations for the policy.
MESFLOW_RELEASE_RETENTION=max(1,int(os.environ.get("MESFLOW_RELEASE_RETENTION","3") or "3"))

# --- QA Center: Build Once / Promote Same Artifact, applied to the second
# application this Agent can build/deploy/promote. Deliberately independent
# globals/state/locks from every MESFlow one above -- QA and MESFlow
# promotion state must never cross-contaminate (see AGENTS.md, "Release
# Manager Safety"). Same DEV-only build gate (MESFLOW_BUILD_ENABLED) since
# both applications build on the same DEV host.
QA_CENTER_SOURCE_DIR=Path(os.environ.get("QA_CENTER_SOURCE_DIR",str(WORKSPACE_ROOT/"qa-center"))).expanduser()
QA_BUILD_LOCK=threading.Lock()
QA_RELEASE_RETENTION=max(1,int(os.environ.get("QA_RELEASE_RETENTION","3") or "3"))
SERVER_ROLE=os.environ.get("SERVER_ROLE","DEV").strip().upper()

def _source_build_allowed() -> bool:
    """Return whether this Agent is the explicitly configured LOCAL builder."""
    return SERVER_ROLE == "DEV" and MESFLOW_BUILD_ENABLED

def _require_local_source_build(component: str) -> None:
    """Prevent legacy source packages from becoming a target-side rebuild path."""
    if not _source_build_allowed():
        raise RuntimeError(
            f"TARGET_SOURCE_BUILD_FORBIDDEN: {component} source builds are allowed only "
            "on the DEV/LOCAL Agent; upload an immutable image release instead"
        )
for d in (CONFIG_DIR,UPLOAD_DIR,RELEASES_DIR,LOG_DIR,QA_UPLOAD_DIR,QA_IMAGE_RELEASES_DIR,ESP_TUTORIAL_UPLOAD_DIR): d.mkdir(parents=True,exist_ok=True)
app=Flask(__name__); app.config.update(
    MAX_CONTENT_LENGTH=MAX_UPLOAD_MB*1024*1024,
    APPLICATION_ROOT=URL_PREFIX or "/",
    SESSION_COOKIE_NAME="mesflow_agent_session",
    SESSION_COOKIE_PATH=f"{URL_PREFIX}/" if URL_PREFIX else "/",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

class DirectPrefixMiddleware:
    """Allow direct access at /agent while still supporting nginx X-Forwarded-Prefix."""
    def __init__(self, wrapped, prefix):
        self.wrapped=wrapped; self.prefix=(prefix or "").rstrip("/")
    def __call__(self, environ, start_response):
        path=environ.get("PATH_INFO","")
        if self.prefix and not environ.get("SCRIPT_NAME") and (path==self.prefix or path.startswith(self.prefix+"/")):
            environ["SCRIPT_NAME"]=self.prefix
            environ["PATH_INFO"]=path[len(self.prefix):] or "/"
        return self.wrapped(environ,start_response)

app.wsgi_app=DirectPrefixMiddleware(
    ProxyFix(app.wsgi_app,x_for=1,x_proto=1,x_host=1,x_port=1,x_prefix=1),
    URL_PREFIX,
)

# ---------------------------------------------------------------------
# Frontend cache busting (reports/DEPLOY_AGENT_FRONTEND_CACHE_BUST.md).
# A rebuilt Agent must never require the operator to hard-refresh/
# Incognito to see new JS/CSS -- every template references static assets
# through static_url() below, which appends a query string that changes
# exactly when the underlying static file bytes change (a deterministic
# content hash, not mtime -- an mtime-only signal changes on every
# rebuild even for byte-identical content, defeating the whole point of
# letting versioned assets be cached aggressively).
# ---------------------------------------------------------------------
def _compute_frontend_build_id(static_dir=None) -> str:
    static_dir=Path(static_dir if static_dir is not None else app.static_folder)
    h=hashlib.sha256()
    try:
        for path in sorted(static_dir.rglob("*")):
            if path.is_file():
                h.update(path.relative_to(static_dir).as_posix().encode("utf-8"))
                h.update(path.read_bytes())
    except OSError:
        pass
    return h.hexdigest()[:10]

FRONTEND_BUILD_ID=f"{AGENT_VERSION}-{_compute_frontend_build_id()}"

def static_url(filename:str)->str:
    """Cache-busted static asset URL. An explicit helper -- deliberately
    NOT a global override of url_for() -- so this only ever touches
    static asset URLs; every other url_for() call in this codebase
    (redirects, form actions, API endpoints) is completely unaffected."""
    return url_for('static',filename=filename)+'?v='+FRONTEND_BUILD_ID
app.jinja_env.globals['static_url']=static_url

@app.after_request
def _apply_cache_policy(response):
    """Versioned static assets: safe to cache aggressively/immutably --
    their URL only ever repeats for byte-identical content. Everything
    else (HTML pages, JSON APIs): must always revalidate, so a freshly
    rebuilt Agent's new HTML -- which references the new asset URL --
    is never served stale from a shared/browser cache."""
    if request.path.startswith('/static/'):
        response.headers['Cache-Control']='public, max-age=31536000, immutable'
    else:
        response.headers['Cache-Control']='no-cache, must-revalidate'
    return response
_state_lock=threading.Lock(); _job_lock=threading.Lock(); _qa_job_lock=threading.Lock(); _tutorial_job_lock=threading.Lock(); _esp_tutorial_job_lock=threading.Lock()
MES_JOB_ACTIVE_STATES={"queued","uploading","validating","building","deploying","verifying"}
def now_text(): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def display_datetime(value):
    try:return datetime.fromisoformat(str(value).replace("Z","+00:00")).strftime("%d/%m/%Y %H:%M")
    except (TypeError,ValueError):return str(value or "")
def load_json(p,default):
    try:return json.loads(Path(p).read_text(encoding="utf-8"))
    except (FileNotFoundError,json.JSONDecodeError,OSError):return default
def save_json(p,v):
    p=Path(p); t=p.with_suffix(p.suffix+".tmp"); t.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding="utf-8"); t.replace(p)
def append_log(m):
    line=f"[{now_text()}] {m}"; print(line,flush=True)
    with AGENT_LOG.open("a",encoding="utf-8") as f:f.write(line+"\n")

def esp_builder_job_update(status,message,**extra):
    def mutate(state):
        job=dict(state.get("esp_builder_job") or {})
        job.update(status=status,message=message,updated_at=now_text(),**extra)
        state["esp_builder_job"]=job
    return update_state(mutate).get("esp_builder_job")

def _register_built_ota_package(package):
    with zipfile.ZipFile(package) as archive:
        root="esp-kiosk-firmware/"
        manifest=json.loads(archive.read(root+"manifest.json").decode("utf-8"))
        version=str(manifest.get("version") or "").strip()
        hardware=str(manifest.get("board") or manifest.get("hardware_model") or "").strip()
        binary=archive.read(root+"firmware.bin")
    if not version or not hardware or not binary: raise ValueError("PACKAGE_FAILED")
    return ota._save_firmware(io.BytesIO(binary),f"ESP_Kiosk_{version}.bin",version,hardware)

def _run_esp_builder():
    try:
        if not ESP_BUILD_ENABLED: raise ValueError("ESP_BUILD_DISABLED")
        if not ESP_KIOSK_SOURCE_DIR.is_dir(): raise ValueError("SOURCE_NOT_FOUND")
        script=ESP_KIOSK_SOURCE_DIR/"scripts"/"build-ota-package.sh"
        if not script.is_file(): raise ValueError("BUILD_SCRIPT_NOT_FOUND")
        esp_builder_job_update("CHECKING","Checking source and Arduino build configuration",source_path=str(ESP_KIOSK_SOURCE_DIR))
        esp_builder_job_update("BUILDING","Compiling ESP firmware")
        log_path=LOG_DIR/"esp-builder.log"; env=os.environ.copy(); env["PYTHONUTF8"]="1"
        with log_path.open("w",encoding="utf-8") as log:
            result=subprocess.run([str(script)],cwd=str(ESP_KIOSK_SOURCE_DIR),env=env,stdout=log,stderr=subprocess.STDOUT,text=True,timeout=BUILD_TIMEOUT)
        log_tail=tail(log_path,80)
        if result.returncode != 0:
            reason="COMPILE_FAILED" if "error:" in log_tail.lower() else "BUILD_FAILED"
            esp_builder_job_update("FAILED",reason,log_file=str(log_path),log_tail=log_tail,error_code=reason); return
        esp_builder_job_update("PACKAGING","Packaging and validating OTA artifact",log_file=str(log_path),log_tail=log_tail)
        packages=sorted((ESP_KIOSK_SOURCE_DIR/"artifacts/esp-kiosk/ota").glob("*_OTA.zip"),key=lambda p:p.stat().st_mtime,reverse=True)
        if not packages: raise ValueError("PACKAGE_FAILED")
        artifact=_register_built_ota_package(packages[0])
        esp_builder_job_update("SUCCESS",f"Firmware {artifact['version']} đã sẵn sàng cho OTA",artifact=artifact,package=str(packages[0]),log_file=str(log_path),log_tail=log_tail)
    except subprocess.TimeoutExpired:
        esp_builder_job_update("FAILED","BUILD_TIMEOUT",error_code="BUILD_TIMEOUT")
    except Exception as exc:
        code=str(exc) if str(exc).isupper() else "REGISTER_FAILED"
        esp_builder_job_update("FAILED",code,error_code=code)
    finally:
        if ESP_BUILDER_LOCK.locked(): ESP_BUILDER_LOCK.release()

def start_esp_builder():
    if not ESP_BUILDER_LOCK.acquire(False): raise RuntimeError("BUILD_ALREADY_RUNNING")
    try:
        esp_builder_job_update("QUEUED","Build job đã được xếp hàng")
        threading.Thread(target=_run_esp_builder,daemon=True).start()
    except Exception:
        ESP_BUILDER_LOCK.release(); raise

PROMOTION_STATE_FILE=CONFIG_DIR/"promotion-state.json"
_promotion_lock=threading.Lock()
# Independent QA Center promotion state -- separate file, separate lock,
# separate state.json keys throughout (qa_release_build_job,
# qa_local_deploy_job, qa_promote_test_job, ...). MESFlow's promotion state
# is never read or written by any QA_* function and vice versa.
QA_PROMOTION_STATE_FILE=CONFIG_DIR/"promotion-state.qa-center.json"
_qa_promotion_lock=threading.Lock()
_qa_promote_test_lock=threading.Lock()

def _releases_root():
    return MESFLOW_SOURCE_DIR.parent/"artifacts"/"releases"

def _release_dir_for(version):
    return _releases_root()/version

def _release_contamination(version):
    """Detect a version whose frozen artifact cannot be trusted.

    Two independent checks: (1) an explicit CONTAMINATED.json marker placed
    next to a known-bad release (never overwrites release.json/checksums.txt
    themselves), and (2) a live check that the Docker tag recorded in this
    release's release.json still points at the exact image id that was
    frozen — if a later build silently moved the tag (the 65.8.44.65
    incident), this catches it even without a marker file.
    """
    root=_release_dir_for(version)
    marker=load_json(root/"CONTAMINATED.json",{})
    if marker.get("contaminated"):
        return {"contaminated":True,"reason":marker.get("reason","Marked contaminated"),"source":"marker"}
    meta=load_json(root/"release.json",{})
    image=str(meta.get("image") or ""); expected_id=str(meta.get("image_id") or "")
    if image and expected_id:
        try:
            r=subprocess.run(["docker","image","inspect",image,"--format","{{.Id}}"],capture_output=True,text=True,timeout=15)
            if r.returncode==0:
                actual_id=r.stdout.strip()
                if actual_id and actual_id!=expected_id:
                    return {"contaminated":True,"reason":f"Docker tag {image} now points at {actual_id}, not the frozen id {expected_id}. A later build moved the tag.","source":"tag_drift"}
        except Exception:
            pass
    return {"contaminated":False}

def _load_promotion_state():
    with _promotion_lock:
        return load_json(PROMOTION_STATE_FILE,{})

def _reset_promotion_state(version,artifact):
    state={
        "version":version,
        "source_commit":artifact.get("source_commit",""),
        "package_sha256":artifact.get("package_sha256",""),
        "image":artifact.get("image",""),
        "image_digest":artifact.get("digest") or artifact.get("image_digest",""),
        "image_id":artifact.get("image_id",""),
        "expected_schema_revision":artifact.get("schema_revision",""),
        "build_status":"PASS",
        "local_status":"NOT_TESTED","local_pass":False,
        "test_status":"NOT_DEPLOYED","test_pass":False,
        "production_status":"NOT_DEPLOYED","production_pass":False,
    }
    with _promotion_lock:
        save_json(PROMOTION_STATE_FILE,state)
    return state

def _sync_release_promotion_json(version,state):
    """Mirror the tracked promotion state into
    artifacts/releases/<version>/PROMOTION.json.

    That per-release file (unlike release.json/checksums.txt/the ZIP) is
    meant to be mutated as promotion progresses -- scripts/promote-test.sh
    and any external tooling read it directly, so it must not silently
    drift from what the Agent itself believes.
    """
    path=_release_dir_for(version)/"PROMOTION.json"
    doc=load_json(path,{})
    doc.update(version=version,image_digest=state.get("image_digest",""),source_commit=state.get("source_commit",""))
    doc["local"]={"status":"success" if state.get("local_pass") else (state.get("local_status") or "NOT_DEPLOYED"),
                  "message":state.get("local_message","")}
    doc["production_test"]={"status":"success" if state.get("test_pass") else (state.get("test_status") or "NOT_DEPLOYED"),
                             "message":state.get("test_message","")}
    doc["production"]={"status":"success" if state.get("production_pass") else (state.get("production_status") or "NOT_DEPLOYED"),
                        "message":state.get("production_message","")}
    try: save_json(path,doc)
    except OSError: pass  # best-effort; the Agent's own promotion-state.json remains authoritative

def _update_promotion_state(version,artifact,**fields):
    """Merge fields into the tracked promotion state for `version`.

    If the tracked state belongs to a different version, it is reset first
    — promotion status never silently carries over to a different artifact.
    """
    with _promotion_lock:
        state=load_json(PROMOTION_STATE_FILE,{})
    if state.get("version")!=version:
        state=_reset_promotion_state(version,artifact)
    state.update(fields)
    with _promotion_lock:
        save_json(PROMOTION_STATE_FILE,state)
    _sync_release_promotion_json(version,state)
    return state

def _v70_release(version):
    try:return int(str(version).split('.')[0])>=70
    except (ValueError,IndexError):return False

def _gate_identity(version):
    artifact=_artifact_for_release(version)
    ident=ReleaseIdentity(version=str(artifact.get("version") or version),source_commit=str(artifact.get("source_commit") or ""),
        artifact=str(artifact.get("image") or ""),artifact_digest=str(artifact.get("digest") or artifact.get("image_digest") or ""),
        package_sha256=str(artifact.get("package_sha256") or ""),schema_revision=str(artifact.get("schema_revision") or ""))
    ident.validate();return ident

def _run_from_payload(payload):
    checks=tuple(CheckResult(str(x.get("name") or "unnamed"),str(x.get("status") or "ERROR").replace("PASSED","PASS"),
        bool(x.get("required",True)),str(x.get("message") or ""),dict(x.get("metadata") or {})) for x in payload.get("checks",[]))
    status=str(payload.get("status") or "ERROR").replace("PASSED","PASS").replace("FAILED","FAIL")
    return TestRun(str(payload.get("run_id") or ""),str(payload.get("environment") or ""),str(payload.get("profile") or ""),status,
        str(payload.get("artifact_digest") or ""),str(payload.get("started_at") or ""),str(payload.get("finished_at") or payload.get("ended_at") or ""),checks,
        int(payload.get("total_tests") or payload.get("total") or 0),int(payload.get("passed_tests") or payload.get("passed") or 0),
        int(payload.get("failed_tests") or payload.get("failed") or 0),int(payload.get("skipped_tests") or 0),str(payload.get("target_url") or ""),
        str(payload.get("report_path") or payload.get("report_file") or ""),str(payload.get("log_path") or payload.get("log_file") or ""))

def _gate_evidence(version,write=True):
    ident=_gate_identity(version);store=ReleaseEvidenceStore(_release_dir_for(version));raw=store.list_runs()
    runs=[_run_from_payload(x) for x in raw]
    local=next((x for x in reversed(runs) if x.environment=="LOCAL" and x.artifact_digest==ident.artifact_digest),None)
    test=next((x for x in reversed(runs) if x.environment=="TEST" and x.artifact_digest==ident.artifact_digest),None)
    promotion=load_json(PROMOTION_STATE_FILE,{}) if _load_promotion_state().get("version")==version else {}
    deployment={"status":"PASS" if promotion.get("test_deployment_verified") else str(promotion.get("test_status") or "NOT_DEPLOYED"),
                "deployed_digest":str(promotion.get("test_deployed_digest") or ""),"target":str(promotion.get("test_target") or "")}
    issues=load_json(_release_dir_for(version)/"KNOWN_ISSUES.json",[]);issues=issues if isinstance(issues,list) else []
    evidence_complete=bool(raw and local and test and promotion.get("test_deployment_verified"))
    decision=ReleaseGatePolicy.evaluate(ident,build_status="PASS",local_run=local,test_deployment=deployment,test_run=test,
        known_issues=issues,evidence_complete=evidence_complete)
    payload={"release":{"version":ident.version,"source_commit":ident.source_commit,"artifact":ident.artifact,
              "artifact_digest":ident.artifact_digest,"package_sha256":ident.package_sha256,"schema_revision":ident.schema_revision},
             "build":{"status":"PASS"},"local":{"status":local.status if local else "NOT_RUN","run_id":local.run_id if local else None},
             "test_deployment":deployment,"test":{"status":test.status if test else "NOT_RUN","run_id":test.run_id if test else None},
             "known_issues":issues,"known_blocking_issues":sum(bool(x.get("blocking") and not x.get("resolved_at")) for x in issues),
             "evidence_complete":evidence_complete,"decision":decision,"runs":raw}
    if write:payload["evidence_files"]=store.write_summary(payload)
    return payload

def _record_gate_run(version,payload):
    ident=_gate_identity(version);run=_run_from_payload(payload)
    if not run.run_id or run.environment not in {"LOCAL","TEST"}:raise ValueError("INVALID_TEST_RUN")
    if run.artifact_digest!=ident.artifact_digest:raise ValueError("ARTIFACT_MISMATCH")
    store=ReleaseEvidenceStore(_release_dir_for(version));store.append_run(run)
    evidence=_gate_evidence(version)
    fields={"release_gate":evidence["decision"]["decision"],"evidence_complete":evidence["evidence_complete"]}
    if run.environment=="LOCAL":fields.update(local_pass=evidence["local"]["status"]=="PASS",local_status=evidence["local"]["status"])
    if run.environment=="TEST":fields.update(test_pass=evidence["decision"]["decision"]=="READY_FOR_PRODUCTION_APPROVAL",test_status=evidence["test"]["status"])
    _update_promotion_state(version,_artifact_for_release(version),**fields)
    return evidence

def _received_release_digest(version):
    """The image_digest THIS Agent itself received and deployed for
    `version`, read from its own local RELEASES_DIR/<version>/release.json
    -- the receive-side layout, populated by /upload + /deploy. Deliberately
    NOT _gate_identity()'s artifacts/releases/ workspace layout: that only
    ever exists on DEV. Real bug found live the first time the release-test
    gate endpoint was exercised against an actual Production Test host:
    _gate_identity(version) there raised INVALID_ARTIFACT_DIGEST because
    DEV's workspace tree simply isn't present on a receiving target."""
    meta=load_json(RELEASES_DIR/version/"release.json",{})
    digest=str(meta.get("image_digest") or "").strip()
    if not re.fullmatch(r"sha256:[0-9a-f]{64}",digest):
        raise ValueError(f"NO_LOCAL_RELEASE_DIGEST: {RELEASES_DIR/version/'release.json'} missing/invalid image_digest")
    return digest

def _run_qa_profile(version,environment,timeout=600,artifact_digest=None):
    """Runs the given release-gate profile against THIS Agent's own local
    QA Center (QA_URL is always this host's own internal-only QA Center --
    never a remote one) and returns the raw run payload, WITHOUT recording
    it anywhere. Split out of _invoke_qa_profile() so a "TEST" run can be
    triggered remotely: only the Agent physically co-located with a given
    MESFlow instance can reach that instance's own internal-only QA
    Center, so a "release-test" run against the Production Test target is
    always executed BY that target's own Agent (via the
    /release-manager/run-test-gate/<version> endpoint below) and the raw
    payload is shipped back over HTTP to the promoting (DEV) Agent, which
    records it into its own evidence store -- see _remote_agent_run_test_gate()
    and the v70 branch of _run_promote_test().

    artifact_digest defaults to _gate_identity(version) (DEV's own
    workspace-tree view, correct for the LOCAL call site below) -- pass it
    explicitly (see _received_release_digest()) when this runs on a
    receiving target, which has no such workspace tree at all."""
    if artifact_digest is None:
        artifact_digest=_gate_identity(version).artifact_digest
    profile="release-local" if environment=="LOCAL" else "release-test"
    body=json.dumps({"profile":profile,"release_version":version,"artifact_digest":artifact_digest}).encode()
    request_start=urllib.request.Request(QA_URL+"/api/release-runs",data=body,method="POST",headers={"Content-Type":"application/json"})
    try:
        with urllib.request.urlopen(request_start,timeout=20) as response:started=json.loads(response.read().decode())
    except Exception as exc:raise RuntimeError(f"QA_RUNNER_UNAVAILABLE:{type(exc).__name__}:{exc}") from exc
    run_id=str((started.get("run") or {}).get("run_id") or "")
    if not run_id:raise RuntimeError("QA_RUNNER_INVALID_RESPONSE")
    deadline=time.time()+timeout;last={}
    while time.time()<deadline:
        time.sleep(2)
        with urllib.request.urlopen(QA_URL+f"/api/runs/{quote(run_id)}",timeout=20) as response:last=json.loads(response.read().decode()).get("run") or {}
        if last.get("status") not in {"RUNNING","QUEUED"}:break
    else:raise RuntimeError("QA_RUN_TIMEOUT")
    return {**last,"run_id":run_id,"environment":environment,"profile":profile,"artifact_digest":artifact_digest,
             "finished_at":last.get("ended_at"),"total_tests":last.get("total",0),"passed_tests":last.get("passed",0),"failed_tests":last.get("failed",0)}

def _invoke_qa_profile(version,environment,timeout=600):
    payload=_run_qa_profile(version,environment,timeout=timeout)
    return _record_gate_run(version,payload)

def _run_local_gate(version):
    try:
        evidence=_invoke_qa_profile(version,"LOCAL")
        update_state(lambda s:s.update(release_local_gate_job={"version":version,"status":evidence["local"]["status"],"finished_at":now_text(),"decision":evidence["decision"]}))
    except Exception as exc:
        artifact=_artifact_for_release(version);_update_promotion_state(version,artifact,local_status="BLOCKED",local_pass=False,local_message=str(exc))
        update_state(lambda s:s.update(release_local_gate_job={"version":version,"status":"BLOCKED","finished_at":now_text(),"message":str(exc)}))

def _actual_running_mes_image_id():
    ds=_docker_mes_state()
    cid=(ds.get("container_ids") or {}).get("mesflow","")
    if not cid: return ""
    try:
        r=subprocess.run(["docker","inspect",cid,"--format","{{.Image}}"],capture_output=True,text=True,timeout=15)
        return r.stdout.strip() if r.returncode==0 else ""
    except Exception:
        return ""

def _actual_schema_revision(base_urls=None):
    """Read the real applied Alembic head from /api/system/ready.

    Deliberately not `schema_version` (an app-defined system_meta label that
    looks like an app version string) — see AGENTS.md: never infer schema
    from the app version.
    """
    payload,code=http_json("/api/system/ready",6)
    if code==200: return str(payload.get("migration_head") or "")
    return ""

def _http_smoke_ok(base_urls=None,timeout=6):
    """Minimal server-side smoke check: the login page renders and looks like MESFlow."""
    for base in _mes_url_candidates():
        try:
            ctx=ssl._create_unverified_context() if base.lower().startswith("https://") else None
            req=urllib.request.Request(base+"/login",headers={"Host":"localhost","User-Agent":"MESFlow-Deploy-Agent"})
            with urllib.request.urlopen(req,timeout=timeout,context=ctx) as r:
                body=r.read(4096).decode("utf-8",errors="replace")
                if r.status==200 and ("MESFlow" in body or "mesflow" in body.lower()):
                    return True
        except Exception:
            continue
    return False

def _record_local_deploy_result(version,success,message=""):
    """Called after a Release Manager-initiated local deploy finishes.

    Computes LOCAL_PASS from real evidence: exact image bytes (image id, not
    tag), applied schema vs the frozen expected schema, and an HTTP smoke
    check — never from the deploy job's return code alone.
    """
    artifact=_artifact_for_release(version)
    if not artifact.get("version"): return
    contamination=_release_contamination(version)
    if not success:
        _update_promotion_state(version,artifact,local_status="FAILED",local_pass=False,local_message=message)
        return
    if contamination.get("contaminated"):
        _update_promotion_state(version,artifact,local_status="FAILED",local_pass=False,
                                 local_message=f"CONTAMINATED release: {contamination.get('reason')}")
        return
    actual_id=_actual_running_mes_image_id()
    expected_id=str(artifact.get("image_id") or "")
    image_ok=bool(expected_id) and actual_id==expected_id
    expected_schema=str(artifact.get("schema_revision") or "")
    actual_schema=_actual_schema_revision()
    schema_ok=bool(expected_schema) and expected_schema not in ("unknown","") and actual_schema==expected_schema
    smoke_ok=_http_smoke_ok()
    infrastructure_ok=image_ok and schema_ok and smoke_ok
    # V70 separates successful deployment/preflight from machine-produced QA.
    # The latter arrives as an immutable release-local TestRun.
    local_pass=infrastructure_ok and not _v70_release(version)
    reasons=[]
    if not image_ok: reasons.append(f"running image id {actual_id or 'unknown'} != frozen id {expected_id or 'unknown'}")
    if not schema_ok: reasons.append(f"schema expected={expected_schema or 'unknown'} actual={actual_schema or 'unknown'}")
    if not smoke_ok: reasons.append("browser/HTTP smoke check failed")
    _update_promotion_state(version,artifact,
        local_status=("PASS" if local_pass else "AWAITING_QA" if infrastructure_ok else "FAILED"),local_pass=local_pass,
        local_message=("LOCAL_PASS" if local_pass else "Infrastructure verified; release-local QA evidence required" if infrastructure_ok else "; ".join(reasons)),
        actual_schema_revision=actual_schema,image_id_verified=image_ok,smoke_ok=smoke_ok,
        zip_sha_unchanged=True,image_digest_unchanged=image_ok)
    if infrastructure_ok and _v70_release(version):
        update_state(lambda s:s.update(release_local_gate_job={"version":version,"status":"QUEUED","started_at":now_text()}))
        threading.Thread(target=_run_local_gate,args=(version,),daemon=True).start()
    if local_pass:
        # Run cleanup only after a successful, verified deployment -- never
        # on a failed or unverified one.
        try: _cleanup_old_releases("LOCAL_PASS")
        except Exception as ex: append_log(f"Release cleanup after LOCAL_PASS failed: {type(ex).__name__}: {ex}")

def _release_summary():
    version_file=MESFLOW_SOURCE_DIR/"VERSION.txt"
    version=version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else "—"
    try:
        commit=subprocess.run(["git","-C",str(MESFLOW_SOURCE_DIR),"rev-parse","--short","HEAD"],capture_output=True,text=True,timeout=5).stdout.strip() or "unknown"
    except Exception: commit="unknown"
    latest=sorted(_releases_root().glob("*/image-info.json"),key=lambda p:p.stat().st_mtime,reverse=True)
    build=load_json(latest[0],{}) if latest else {}
    if latest:
        package=latest[0].parent/f"MESFlow_{build.get('version','')}.deploy.zip"
        release_meta=load_json(latest[0].parent/"release.json",{})
        build={**build,"package":str(package),"package_sha256":sha(package) if package.is_file() else "",
               "image_id":release_meta.get("image_id",""),"schema_revision":release_meta.get("schema_revision","")}
    contamination=_release_contamination(build.get("version","")) if build.get("version") else {"contaminated":False}
    build_job=load_state().get("release_build_job") or {}
    build_state={"QUEUED":"BUILDING","BUILDING":"BUILDING","SUCCESS":"PASS","FAILED":"FAILED"}.get(build_job.get("status",""),"IDLE" if not build_job else "IDLE")
    promotion=load_json(PROMOTION_STATE_FILE,{})
    if promotion.get("version")!=build.get("version"): promotion={"version":build.get("version",""),"local_status":"NOT_TESTED","test_status":"NOT_DEPLOYED","production_status":"NOT_DEPLOYED"}
    expected=str(promotion.get("expected_schema_revision") or build.get("schema_revision") or "")
    actual=str(promotion.get("actual_schema_revision") or "")
    schema_pass=bool(expected and actual and expected not in ("unknown","") and expected==actual)
    local_pass=bool(promotion.get("local_pass")); test_pass=bool(promotion.get("test_pass"))
    zip_ok=bool(promotion.get("zip_sha_unchanged")); digest_ok=bool(promotion.get("image_digest_unchanged"))
    production_promote_enabled=os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() in {"1","true","yes","on"}
    # Production target health must come from a *fresh* read-only preflight,
    # not a stale cached one — infrastructure can go unhealthy between
    # checks, so an old "healthy" result must not silently keep gating
    # PASS. PREFLIGHT_MAX_AGE_SECONDS matches the window an operator would
    # reasonably trust without re-checking immediately before promoting.
    preflight=load_json(CONFIG_DIR/"production-preflight.json",{})
    PREFLIGHT_MAX_AGE_SECONDS=900
    preflight_age=None
    try: preflight_age=(datetime.now()-datetime.strptime(preflight.get("checked_at",""),"%Y-%m-%d %H:%M:%S")).total_seconds()
    except (ValueError,TypeError): pass
    preflight_fresh=preflight_age is not None and 0<=preflight_age<=PREFLIGHT_MAX_AGE_SECONDS
    target_healthy=preflight_fresh and bool(preflight.get("healthy"))
    evidence_gate=None
    if _v70_release(str(build.get("version") or "")):
        try:evidence_gate=_gate_evidence(str(build["version"]),write=False);test_pass=bool(evidence_gate["decision"]["ready"])
        except Exception:evidence_gate=None;test_pass=False
    gate_ok=local_pass and test_pass and zip_ok and digest_ok and schema_pass and not contamination.get("contaminated") and target_healthy
    # Exact blocking reason, so the UI never just shows a disabled button.
    build_block=None if MESFLOW_BUILD_ENABLED else "Build is disabled on this Agent (MESFLOW_BUILD_ENABLED=0 — this host is not DEV)."
    local_block=None
    if not build.get("version"): local_block="No release has been built yet."
    elif contamination.get("contaminated"): local_block=f"Release {build.get('version')} is CONTAMINATED: {contamination.get('reason')}"
    test_block=None
    if not local_pass: test_block="BLOCKED: QA Center chưa LOCAL_PASS cho artifact hiện tại. Hãy Deploy Local và chờ LOCAL_PASS."
    elif contamination.get("contaminated"): test_block=f"Release {build.get('version')} is CONTAMINATED: {contamination.get('reason')}"
    elif not (os.environ.get("MESFLOW_PRODUCTION_TEST_AGENT_URL") or "").strip(): test_block="BLOCKED: Chưa cấu hình Production Test Agent. Cần MESFLOW_PRODUCTION_TEST_AGENT_URL/_USER/_PASSWORD."
    production_block=None
    if not gate_ok:
        missing=[]
        if not local_pass: missing.append("LOCAL_PASS")
        if not test_pass: missing.append("TEST_PASS")
        if not zip_ok: missing.append("ZIP SHA unchanged")
        if not digest_ok: missing.append("image digest unchanged")
        if not schema_pass: missing.append("schema PASS")
        if contamination.get("contaminated"): missing.append("release not contaminated")
        if not target_healthy:
            if not (os.environ.get("MESFLOW_PRODUCTION_AGENT_URL") or "").strip():
                missing.append("Production target not configured (set MESFLOW_PRODUCTION_AGENT_URL/_USER/_PASSWORD)")
            elif not preflight_fresh:
                missing.append(f"Production preflight missing or stale (>{PREFLIGHT_MAX_AGE_SECONDS//60}min old — run Production Preflight)")
            else:
                missing.append("Production preflight reports unhealthy")
        production_block="Blocked: "+", ".join(missing) if missing else "Blocked"
    elif not production_promote_enabled:
        production_block="Gate PASS, but production execution is disabled on this Agent until a human sets MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 and clicks confirm."
    production_status=promotion.get("production_status") or ("READY" if gate_ok else "NOT_DEPLOYED")
    # While a promote-test job is actively running (QUEUED/UPLOADING/
    # DEPLOYING/VERIFYING) for this exact version, surface its live status
    # instead of the last *persisted* test_status -- otherwise the UI's
    # Production Test indicator sits at its old value (e.g. NOT_DEPLOYED)
    # through the entire upload+deploy, only ever jumping straight to
    # PASS/FAILED at the very end, never showing UPLOADING/DEPLOYING.
    test_job=load_state().get("promote_test_job") or {}
    tracked_version=str(promotion.get("version") or build.get("version") or "")
    test_job_live=(test_job.get("status") in {"QUEUED","UPLOADING","DEPLOYING","VERIFYING"}
                   and tracked_version and canonical_version(str(test_job.get("version") or ""))==canonical_version(tracked_version))
    test_state=test_job.get("status") if test_job_live else promotion.get("test_status","NOT_DEPLOYED")
    return {"source_path":str(MESFLOW_SOURCE_DIR),"source_exists":MESFLOW_SOURCE_DIR.is_dir(),"source_version":version,"git":commit,
            "status":"clean" if MESFLOW_SOURCE_DIR.is_dir() else "missing","latest":build,"contamination":contamination,
            "states":{"build":build_state,"local":promotion.get("local_status","NOT_TESTED"),
                      "test":test_state,"production":production_status},
            "blocked":{"build":build_block,"local":local_block,"test":test_block,"production":production_block},
            "production_preflight":preflight,"production_preflight_fresh":preflight_fresh,"production_target_healthy":target_healthy,
            "production_target_configured":bool((os.environ.get("MESFLOW_PRODUCTION_AGENT_URL") or "").strip()),
            "release_gate_evidence":evidence_gate,
            "promotion":{**promotion,"expected_schema_revision":expected,"actual_schema_revision":actual,"schema_pass":schema_pass,
                        "production_gate":gate_ok,"production_promote_enabled":production_promote_enabled,
                        "history":["Built" if build.get("version") else "Not built",
                                   "Local PASS" if local_pass else "Local NOT TESTED",
                                   "Test PASS" if test_pass else "Test NOT DEPLOYED",
                                   "Production PASS" if promotion.get("production_pass") else "Production NOT DEPLOYED"]}}

def release_build_update(status,message,**extra):
    def mutate(s):
        j=dict(s.get("release_build_job") or {});j.update(status=status,message=message,updated_at=now_text(),**extra);s["release_build_job"]=j
    return update_state(mutate).get("release_build_job")

def _run_release_build():
    try:
        if not MESFLOW_BUILD_ENABLED: raise ValueError("BUILD_DISABLED")
        script=MESFLOW_SOURCE_DIR/"scripts"/"build-release.sh"
        if not MESFLOW_SOURCE_DIR.is_dir(): raise ValueError("SOURCE_NOT_FOUND")
        if not script.is_file(): raise ValueError("BUILD_SCRIPT_NOT_FOUND")
        release_build_update("BUILDING","Đang build Docker image tại DEV",source_path=str(MESFLOW_SOURCE_DIR))
        log_path=LOG_DIR/"mesflow-builder.log"
        with log_path.open("w",encoding="utf-8") as log:
            result=subprocess.run([str(script)],cwd=str(MESFLOW_SOURCE_DIR),stdout=log,stderr=subprocess.STDOUT,text=True,timeout=BUILD_TIMEOUT)
        log_tail=tail(log_path,100)
        if result.returncode: release_build_update("FAILED","BUILD_FAILED",error_code="BUILD_FAILED",log_tail=log_tail,log_file=str(log_path));return
        summary=_release_summary(); latest=sorted((MESFLOW_SOURCE_DIR.parent/"artifacts"/"releases").glob("*/image-info.json"),key=lambda p:p.stat().st_mtime,reverse=True)
        if not latest: raise ValueError("PACKAGE_NOT_FOUND")
        info=load_json(latest[0],{}); release_build_update("SUCCESS","Local build complete",latest={**info,"package":str(latest[0].parent/("MESFlow_"+info.get("version","")+".deploy.zip"))},source=summary,log_tail=log_tail,log_file=str(log_path))
    except subprocess.TimeoutExpired:
        release_build_update("FAILED","BUILD_TIMEOUT",error_code="BUILD_TIMEOUT")
    except Exception as exc:
        code=str(exc) if str(exc).isupper() else "BUILD_FAILED";release_build_update("FAILED",code,error_code=code)
    finally:
        if MESFLOW_BUILD_LOCK.locked(): MESFLOW_BUILD_LOCK.release()

def start_release_build():
    if not MESFLOW_BUILD_LOCK.acquire(False): raise RuntimeError("BUILD_ALREADY_RUNNING")
    try:
        release_build_update("QUEUED","Build release queued");threading.Thread(target=_run_release_build,daemon=True).start()
    except Exception:
        MESFLOW_BUILD_LOCK.release();raise

def _run_version_bump(target_version=""):
    """Run scripts/bump-version.sh: a fast, source-only edit (VERSION.txt,
    __init__.py, release.json, compose.yml) -- never builds/tags/pushes a
    Docker image. DEV-only (build-enabled), same as Build Release, since
    Production Test/Production never carry or need MESFlow source."""
    if not MESFLOW_BUILD_ENABLED: raise ValueError("BUILD_DISABLED")
    if not MESFLOW_SOURCE_DIR.is_dir(): raise ValueError("SOURCE_NOT_FOUND")
    script=MESFLOW_SOURCE_DIR/"scripts"/"bump-version.sh"
    if not script.is_file(): raise ValueError("BUMP_SCRIPT_NOT_FOUND")
    before=(MESFLOW_SOURCE_DIR/"VERSION.txt").read_text(encoding="utf-8-sig").strip() if (MESFLOW_SOURCE_DIR/"VERSION.txt").is_file() else ""
    args=[str(script)]
    target_version=str(target_version or "").strip()
    if target_version:
        if not re.fullmatch(r"\d+\.\d+\.\d+\.\d+",target_version): raise ValueError("VERSION_INVALID")
        args.append(target_version)
    log_path=LOG_DIR/"version-bump.log"
    with log_path.open("w",encoding="utf-8") as log:
        result=subprocess.run(args,cwd=str(MESFLOW_SOURCE_DIR),stdout=log,stderr=subprocess.STDOUT,text=True,timeout=30)
    log_tail=tail(log_path,60)
    if result.returncode:
        lines=[ln for ln in log_tail.strip().splitlines() if ln.strip()]
        raise RuntimeError(lines[-1] if lines else "VERSION_BUMP_FAILED")
    after=(MESFLOW_SOURCE_DIR/"VERSION.txt").read_text(encoding="utf-8-sig").strip() if (MESFLOW_SOURCE_DIR/"VERSION.txt").is_file() else ""
    entry={"at":now_text(),"before":before,"after":after,"log_tail":log_tail}
    def f(s): s["version_bump"]=entry
    update_state(f)
    append_log(f"Version bump: {before} -> {after}")
    return entry

def _promotion_state(version):
    p=MESFLOW_SOURCE_DIR.parent/"artifacts"/"releases"/version/"PROMOTION.json"
    return load_json(p,{}) if p.is_file() else {}

def _artifact_for_release(version):
    root=MESFLOW_SOURCE_DIR.parent/"artifacts"/"releases"/version
    package=root/f"MESFlow_{version}.deploy.zip"
    info=load_json(root/"image-info.json",{}); meta=load_json(root/"release.json",{})
    return {"version":version,"image":meta.get("image",info.get("image")),"digest":meta.get("image_digest",info.get("digest")),
            "image_id":meta.get("image_id",""),"schema_revision":meta.get("schema_revision",""),
            "package":str(package),"package_sha256":sha(package) if package.is_file() else "",
            "source_commit":meta.get("source_commit",""),"built_at":meta.get("built_at","")}

# --- Unified deployment history (Release/Deploy UX cleanup) ---------------
# One cross-component record store, additive alongside the existing
# per-component job/history state (job/history for MESFlow LOCAL,
# qa_local_deploy_job/qa_target_deploy_job for QA) which stays exactly as it
# was -- nothing here replaces or migrates old state. This is the backing
# store for the Deployment History tab: it is the only place a TEST-stage
# promotion or an Agent Update ever gets a persisted history entry (those
# previously only ever kept a single "latest job" slot, no history array).
DEPLOYMENT_HISTORY_TERMINAL={"success","failed","SUCCESS","FAILED","rolled_back","ROLLED_BACK","interrupted"}

def _record_deployment_history(component,environment,*,version="",from_version="",status="",message="",
                                started_at="",finished_at="",deployment_id="",log_file="",rolled_back_to=None,steps=None):
    if status not in DEPLOYMENT_HISTORY_TERMINAL:
        return None
    entry={"id":uuid.uuid4().hex,"component":component,"environment":environment,
           "version":version,"from_version":from_version,"status":status,"message":message,
           "started_at":started_at,"finished_at":finished_at,"deployment_id":deployment_id,
           "log_file":log_file,"rolled_back_to":rolled_back_to,"steps":steps or {},
           "recorded_at":now_text()}
    def mutate(s):
        lst=s.setdefault("deployment_history",[])
        # A worker can call its own *_update() more than once with the same
        # terminal status (retries/duplicate finalization) -- de-dupe on
        # deployment_id when one is present so refreshing doesn't double-count.
        if deployment_id and any(x.get("deployment_id")==deployment_id and x.get("component")==component for x in lst):
            return
        lst.insert(0,entry)
        s["deployment_history"]=lst[:500]
    update_state(mutate)
    return entry

def _deployment_history_result(status,rolled_back_to):
    """Normalize the many raw status spellings into the 4 outcomes the UI
    must visually distinguish (task section 17): a plain FAILED must never
    look the same as a FAILED that WAS rolled back or a FAILED whose
    rollback itself failed."""
    s=str(status or "").lower()
    if s in ("success",): return "SUCCESS"
    if s in ("failed","interrupted"):
        if rolled_back_to: return "ROLLED_BACK"
        return "FAILED"
    return str(status or "").upper() or "UNKNOWN"

def _deployment_history_query(component=None,environment=None,result=None,q=None,page=1,page_size=20):
    items=list(load_state().get("deployment_history") or [])
    def matches(e):
        if component and e.get("component")!=component: return False
        if environment and e.get("environment")!=environment: return False
        if result and _deployment_history_result(e.get("status"),e.get("rolled_back_to"))!=result: return False
        if q:
            hay=f"{e.get('version','')} {e.get('from_version','')} {e.get('message','')}".lower()
            if q.lower() not in hay: return False
        return True
    filtered=[e for e in items if matches(e)]
    total=len(filtered)
    page=max(1,int(page or 1)); page_size=max(1,min(100,int(page_size or 20)))
    start=(page-1)*page_size
    page_items=filtered[start:start+page_size]
    out=[]
    for e in page_items:
        d=dict(e); d["result"]=_deployment_history_result(e.get("status"),e.get("rolled_back_to"))
        try:
            if e.get("started_at") and e.get("finished_at"):
                from datetime import datetime as _dt
                fmt="%Y-%m-%d %H:%M:%S"
                dur=(_dt.strptime(e["finished_at"][:19],fmt)-_dt.strptime(e["started_at"][:19],fmt)).total_seconds()
                d["duration_seconds"]=max(0,int(dur))
        except Exception:
            pass
        out.append(d)
    return {"items":out,"total":total,"page":page,"page_size":page_size}

# --- Release retention / cleanup ------------------------------------------
# Two independent, config-only policies (never touches database backups):
# keep the newest MESFLOW_RELEASE_RETENTION built application releases as
# full deployable artifacts (release ZIP + local staging copy + Docker
# image); everything older is removed only once it is provably safe. This
# never runs unattended -- it is only ever invoked right after a verified
# successful local deploy (LOCAL_PASS) or a verified successful Production
# Test promotion (TEST_PASS). See reports/SESSION_EXCEPTION_SIMPLIFICATION.md
# ("RELEASE RETENTION") and docs/operations for the full policy writeup.

def _dir_size(path):
    total=0
    try:
        for p in Path(path).rglob('*'):
            if p.is_file():
                try: total+=p.stat().st_size
                except OSError: pass
    except OSError: pass
    return total

def _release_cleanup_candidates():
    """All built application release versions under artifacts/releases,
    newest-build-first (by release.json's mtime -- the moment the build was
    frozen -- falling back to the directory's own mtime for a partial/
    corrupt entry so it never sorts ahead of real releases)."""
    root=_releases_root()
    if not root.is_dir(): return []
    out=[]
    for d in root.iterdir():
        if not d.is_dir() or d.name.startswith('.'): continue
        marker=d/"release.json"
        try: mtime=marker.stat().st_mtime if marker.is_file() else d.stat().st_mtime
        except OSError: continue
        out.append((mtime,d.name))
    out.sort(reverse=True)
    return [name for _,name in out]

def _release_cleanup_blockers(version,keep_versions):
    """Every reason `version` must NOT be cleaned up right now; [] means safe.
    Named 1:1 against the policy: currently deployed / active rollback
    target / part of an active deployment / being promoted / referenced by
    an active job. Never a version-count heuristic alone."""
    if version in keep_versions:
        return ["WITHIN_RETENTION_WINDOW"]
    reasons=[]
    target=canonical_version(version)
    try:
        if target and canonical_version(current_file_version())==target:
            reasons.append("CURRENTLY_DEPLOYED")
    except Exception: pass
    state=load_state()
    job=state.get("job") or {}
    if job.get("status") in MES_JOB_ACTIVE_STATES:
        if canonical_version(str(job.get("version") or ""))==target:
            reasons.append("ACTIVE_DEPLOYMENT_JOB")
        if canonical_version(str(job.get("from_version") or ""))==target:
            reasons.append("ACTIVE_ROLLBACK_TARGET")  # what an in-flight deploy would roll back to on failure
    history=state.get("history") or []
    if history and canonical_version(str(history[0].get("from_version") or ""))==target:
        reasons.append("ROLLBACK_TARGET_OF_LAST_DEPLOY")  # what a manual rollback of the last deploy would restore
    promote_job=state.get("promote_test_job") or {}
    if promote_job.get("status") in ("QUEUED","UPLOADING","DEPLOYING","VERIFYING") and canonical_version(str(promote_job.get("version") or ""))==target:
        reasons.append("BEING_PROMOTED")
    agent_job=state.get("agent_update_job") or {}
    if agent_job.get("status") in ("QUEUED","PUSHING","UPDATING") and canonical_version(str(agent_job.get("mes_version") or ""))==target:
        reasons.append("REFERENCED_BY_ACTIVE_AGENT_UPDATE_JOB")
    promotion=load_json(PROMOTION_STATE_FILE,{})
    if canonical_version(str(promotion.get("version") or ""))==target and not (promotion.get("local_pass") and promotion.get("test_pass")):
        reasons.append("PROMOTION_IN_PROGRESS")  # not yet fully proven through Build Once/Promote Same Artifact
    return reasons

def _cleanup_stray_staging(now,removed,bytes_freed,errors):
    """Orphaned temp-upload/staging leftovers from an interrupted upload or
    a crash mid-copy (normal operation always cleans these up inline in a
    `finally` block; this only ever catches what a crash left behind).
    Age-gated at 1 hour so an upload genuinely in progress is never touched."""
    cutoff=now-3600
    for base,label in ((UPLOAD_DIR,"temp_upload"),):
        if not base.is_dir(): continue
        for entry in base.iterdir():
            try:
                if entry.stat().st_mtime>=cutoff: continue
                size=_dir_size(entry) if entry.is_dir() else entry.stat().st_size
                if entry.is_dir(): shutil.rmtree(entry)
                else: entry.unlink()
                removed.append({"type":label,"path":str(entry),"bytes":size})
                bytes_freed["value"]+=size
            except OSError as ex:
                errors.append(f"{entry}: {ex}")
    if RELEASES_DIR.is_dir():
        for entry in RELEASES_DIR.iterdir():
            if not entry.name.startswith('.'): continue  # .{version}.replacement-*/.{version}.previous-* only
            try:
                if entry.stat().st_mtime>=cutoff: continue
                size=_dir_size(entry)
                shutil.rmtree(entry)
                removed.append({"type":"old_staging","path":str(entry),"bytes":size})
                bytes_freed["value"]+=size
            except OSError as ex:
                errors.append(f"{entry}: {ex}")

def _cleanup_old_releases(trigger):
    """Run the release retention policy. Safe to call any number of times;
    idempotent (nothing left to remove on a repeat call is not an error).
    Returns and persists a report of exactly what was removed/kept/blocked."""
    now=time.time()
    removed=[]; kept=[]; blocked={}; errors=[]; bytes_freed={"value":0}
    candidates=_release_cleanup_candidates()
    keep_versions=set(candidates[:MESFLOW_RELEASE_RETENTION])
    for version in candidates:
        reasons=_release_cleanup_blockers(version,keep_versions)
        if reasons:
            if reasons==["WITHIN_RETENTION_WINDOW"]: kept.append(version)
            else: blocked[version]=reasons
            continue
        root=_release_dir_for(version)
        # Old release ZIP (+ its checksum sidecar) -- never release.json /
        # checksums.txt / PROMOTION.json / image-info.json / BUILD_REPORT.md,
        # which the immutable-once build guard depends on existing forever.
        for pattern in (f"MESFlow_{version}.deploy.zip",f"MESFlow_{version}.deploy.zip.sha256"):
            f=root/pattern
            if f.is_file():
                try:
                    size=f.stat().st_size; f.unlink()
                    removed.append({"type":"release_zip","version":version,"path":str(f),"bytes":size})
                    bytes_freed["value"]+=size
                except OSError as ex: errors.append(f"{f}: {ex}")
        # Old local staging/bundle copy (the unpacked release this Agent
        # would deploy locally from) -- RELEASES_DIR/<version>.
        staging=RELEASES_DIR/version
        if staging.is_dir():
            try:
                size=_dir_size(staging); shutil.rmtree(staging)
                removed.append({"type":"old_staging","version":version,"path":str(staging),"bytes":size})
                bytes_freed["value"]+=size
            except OSError as ex: errors.append(f"{staging}: {ex}")
        # Corresponding unused Docker image -- targeted `docker rmi` of this
        # exact tag only. Never `docker system prune`. A failure here (e.g.
        # the image is still referenced by a stopped container) is logged,
        # not fatal to the rest of the cleanup pass.
        image_tag=f"{os.environ.get('MESFLOW_IMAGE_REPOSITORY','mesflow-app')}:{version}"
        r=_run_capture(["docker","rmi",image_tag],30)
        if r.get("ok"):
            removed.append({"type":"docker_image","version":version,"image":image_tag})
        elif "No such image" not in (r.get("stderr") or ""):
            errors.append(f"docker rmi {image_tag}: {(r.get('stderr') or '').strip()[:200]}")
    # Second pass: local staging copies (RELEASES_DIR/<version>) whose
    # artifacts/releases build record is already gone entirely (e.g. from
    # before this retention policy existed, or from any external cleanup of
    # artifacts/releases). Same safety checks apply; a version already
    # missing its build record can never be "within the retention window".
    if RELEASES_DIR.is_dir():
        candidate_set=set(candidates)
        for entry in RELEASES_DIR.iterdir():
            if not entry.is_dir() or entry.name.startswith('.') or entry.name in candidate_set: continue
            version=entry.name
            reasons=_release_cleanup_blockers(version,keep_versions)
            if reasons:
                if reasons!=["WITHIN_RETENTION_WINDOW"]: blocked[version]=reasons
                continue
            try:
                size=_dir_size(entry); shutil.rmtree(entry)
                removed.append({"type":"old_staging","version":version,"path":str(entry),"bytes":size})
                bytes_freed["value"]+=size
            except OSError as ex:
                errors.append(f"{entry}: {ex}"); continue
            image_tag=f"{os.environ.get('MESFLOW_IMAGE_REPOSITORY','mesflow-app')}:{version}"
            r=_run_capture(["docker","rmi",image_tag],30)
            if r.get("ok"):
                removed.append({"type":"docker_image","version":version,"image":image_tag})
            elif "No such image" not in (r.get("stderr") or ""):
                errors.append(f"docker rmi {image_tag}: {(r.get('stderr') or '').strip()[:200]}")
    _cleanup_stray_staging(now,removed,bytes_freed,errors)
    report={"at":now_text(),"trigger":trigger,"retention":MESFLOW_RELEASE_RETENTION,
            "kept":kept,"blocked":blocked,"removed":removed,"bytes_freed":bytes_freed["value"],"errors":errors}
    def f(s): s["release_cleanup_report"]=report
    update_state(f)
    append_log(f"Release cleanup ({trigger}): removed={len(removed)} kept={len(kept)} blocked={len(blocked)} freed={_bytes(bytes_freed['value'])}"+(f" errors={len(errors)}" if errors else ""))
    return report

def _release_targets():
    raw=load_json(CONFIG_DIR/"release-targets.json",{})
    return raw if isinstance(raw,list) else [{"name":"LOCAL","role":"DEV","url":"local","status":"AVAILABLE"}]

# ---------------- Promote Production Test: remote Deploy Agent client ----------------
_promote_test_lock=threading.Lock()

class _RemoteAgentError(RuntimeError):
    pass

def _remote_agent_client(base_url,user,password,timeout=20):
    """Log in to a remote Deploy Agent's session-based auth, mirroring
    scripts/promote-test.sh exactly (same endpoints, same CSRF contract).
    Returns (opener, csrf_token)."""
    base=base_url.rstrip("/")
    jar=http.cookiejar.CookieJar()
    opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    def _get(path):
        req=urllib.request.Request(base+path,headers={"User-Agent":"MESFlow-Deploy-Agent-Promote"})
        with opener.open(req,timeout=timeout) as r: return r.read().decode("utf-8",errors="replace")
    def _csrf(html):
        m=re.search(r'name="csrf"\s+value="([^"]+)"',html)
        return m.group(1) if m else ""
    login_page=_get("/login")
    csrf=_csrf(login_page)
    data=urlencode({"username":user,"password":password,"csrf":csrf}).encode()
    req=urllib.request.Request(base+"/login",data=data,headers={"Content-Type":"application/x-www-form-urlencoded","User-Agent":"MESFlow-Deploy-Agent-Promote"})
    with opener.open(req,timeout=timeout) as r: r.read()
    home=_get("/")
    csrf2=_csrf(home)
    if not csrf2: raise _RemoteAgentError("REMOTE_LOGIN_FAILED: no session/csrf obtained (check target URL/credentials)")
    return opener,base,csrf2

def _remote_agent_upload(opener,base,csrf,zip_path,timeout=600,path="/upload",field_name="release_zip"):
    """multipart/form-data POST of a release ZIP to a remote Agent endpoint.
    Defaults to MESFlow's /upload; QA promotion passes path="/qa-release/upload"
    (same opener/CSRF contract, different route -- see _remote_agent_qa_upload)."""
    boundary=uuid.uuid4().hex
    zip_path=Path(zip_path)
    parts=[]
    def field(name,value):
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    field("csrf",csrf)
    parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{field_name}"; filename="{zip_path.name}"\r\n'
                   'Content-Type: application/zip\r\n\r\n').encode())
    parts.append(zip_path.read_bytes())
    parts.append(f"\r\n--{boundary}--\r\n".encode())
    body=b"".join(parts)
    req=urllib.request.Request(base+path,data=body,headers={
        "Content-Type":f"multipart/form-data; boundary={boundary}",
        "X-CSRF-Token":csrf,"User-Agent":"MESFlow-Deploy-Agent-Promote"})
    with opener.open(req,timeout=timeout) as r:
        return r.status,r.read().decode("utf-8",errors="replace")

def _remote_agent_deploy(opener,base,csrf,version,timeout=600,path_fmt="/deploy/{}"):
    """POST to a remote Agent's deploy-by-version endpoint. Defaults to
    MESFlow's /deploy/<version>; QA promotion passes path_fmt="/qa-release/deploy/{}"."""
    req=urllib.request.Request(base+path_fmt.format(quote(version,safe='')),data=urlencode({"csrf":csrf}).encode(),
        headers={"Content-Type":"application/x-www-form-urlencoded","X-CSRF-Token":csrf,"User-Agent":"MESFlow-Deploy-Agent-Promote"})
    with opener.open(req,timeout=timeout) as r:
        return r.status,r.read().decode("utf-8",errors="replace")

QA_CHUNK_BYTES=max(1024*1024,min(int(os.environ.get("MESFLOW_QA_UPLOAD_CHUNK_MB","16"))*1024*1024,64*1024*1024))

def _remote_agent_json_post(opener,base,path,csrf,payload,timeout=120,extra_headers=None):
    data=json.dumps(payload).encode("utf-8")
    headers={"Content-Type":"application/json","X-CSRF-Token":csrf,"User-Agent":"MESFlow-Deploy-Agent-Promote"}
    if extra_headers: headers.update(extra_headers)
    req=urllib.request.Request(base+path,data=data,headers=headers)
    try:
        with opener.open(req,timeout=timeout) as r:
            body=r.read().decode("utf-8",errors="replace")
            return json.loads(body or "{}")
    except urllib.error.HTTPError as e:
        body=e.read().decode("utf-8",errors="replace")
        try: detail=json.loads(body or "{}")
        except Exception: detail={"error":f"HTTP {e.code}: {e.reason}"}
        raise _RemoteAgentError(str(detail.get("error") or detail.get("message") or f"HTTP {e.code}: {e.reason}"))

def _remote_agent_qa_upload(opener,base,csrf,zip_path,timeout=600,progress=None):
    """Transfer a potentially multi-GB immutable QA release without one huge
    HTTP request. Cloud/reverse proxies commonly cap request bodies (the live
    Production Test path returned HTTP 413 for the ~2GB QA image artifact).
    The target receives small ordered chunks, verifies every chunk plus the
    final whole-file SHA256, then stages the exact original ZIP.
    """
    zip_path=Path(zip_path)
    total=zip_path.stat().st_size
    expected_sha=sha(zip_path)
    start=_remote_agent_json_post(opener,base,"/qa-release/chunk/start",csrf,{
        "filename":zip_path.name,"total_size":total,"sha256":expected_sha,"chunk_size":QA_CHUNK_BYTES},timeout=60)
    upload_id=str(start.get("upload_id") or "")
    if not upload_id: raise _RemoteAgentError(f"QA_CHUNK_START_FAILED: {start}")
    sent=0; index=0
    try:
        with zip_path.open("rb") as f:
            while True:
                chunk=f.read(QA_CHUNK_BYTES)
                if not chunk: break
                chunk_sha=hashlib.sha256(chunk).hexdigest()
                req=urllib.request.Request(
                    base+f"/qa-release/chunk/{quote(upload_id,safe='')}/{index}",data=chunk,
                    headers={"Content-Type":"application/octet-stream","X-CSRF-Token":csrf,
                             "X-Chunk-SHA256":chunk_sha,"User-Agent":"MESFlow-Deploy-Agent-Promote"})
                payload=None
                for attempt in range(1,4):
                    try:
                        with opener.open(req,timeout=timeout) as r:
                            payload=json.loads(r.read().decode("utf-8",errors="replace") or "{}")
                        break
                    except urllib.error.HTTPError as e:
                        body=e.read().decode("utf-8",errors="replace")
                        try: detail=json.loads(body or "{}")
                        except Exception: detail={"error":f"HTTP {e.code}: {e.reason}"}
                        error=str(detail.get("error") or detail)
                        # The target may have durably appended this chunk while
                        # its HTTP response was lost. Its ordered receiver then
                        # reports expected=index+1 on the retry; treat that exact
                        # state as the acknowledgement, never a wider mismatch.
                        if f"QA_CHUNK_OUT_OF_ORDER expected={index+1} got={index}" in error:
                            payload={"ok":True,"recovered_ack":True}
                            break
                        raise _RemoteAgentError(f"QA_CHUNK_UPLOAD_FAILED index={index}: {error}")
                    except (TimeoutError,OSError,urllib.error.URLError) as exc:
                        if attempt>=3:
                            raise _RemoteAgentError(
                                f"QA_CHUNK_UPLOAD_FAILED index={index} attempts={attempt}: "
                                f"{type(exc).__name__}: {exc}") from exc
                        time.sleep(attempt*2)
                sent += len(chunk); index += 1
                if not payload.get("ok"):
                    raise _RemoteAgentError(f"QA_CHUNK_UPLOAD_FAILED index={index-1}: {payload}")
                if progress:
                    progress(sent,total,index)
        if sent!=total: raise _RemoteAgentError(f"QA_CHUNK_SIZE_MISMATCH sent={sent} expected={total}")
        complete=_remote_agent_json_post(opener,base,f"/qa-release/chunk/{quote(upload_id,safe='')}/complete",csrf,{
            "sha256":expected_sha,"total_size":total,"chunks":index},timeout=timeout)
        if not complete.get("ok"):
            raise _RemoteAgentError(f"QA_CHUNK_COMPLETE_FAILED: {complete}")
        return 200,json.dumps(complete)
    except Exception:
        try:
            _remote_agent_json_post(opener,base,f"/qa-release/chunk/{quote(upload_id,safe='')}/abort",csrf,{},timeout=30)
        except Exception: pass
        raise

def _remote_agent_qa_deploy(opener,base,csrf,version,timeout=600):
    return _remote_agent_deploy(opener,base,csrf,version,timeout=timeout,path_fmt="/qa-release/deploy/{}")

def _remote_agent_run_test_gate(opener,base,csrf,version,timeout=650):
    """POST to a remote Agent's release-test QA gate endpoint and return
    the parsed JSON payload. Long timeout on purpose: the remote side
    blocks synchronously while ITS OWN local QA Center runs the full
    "release-test" check suite against ITS OWN internal MESFlow (mirrors
    _run_qa_profile()'s own up-to-600s wait, plus headroom for the extra
    HTTP hop) -- this call happens inside _run_promote_test()'s own
    background thread, so blocking here does not freeze the UI."""
    req=urllib.request.Request(base+f"/release-manager/run-test-gate/{quote(version,safe='')}",
        data=urlencode({"csrf":csrf}).encode(),
        headers={"Content-Type":"application/x-www-form-urlencoded","X-CSRF-Token":csrf,"User-Agent":"MESFlow-Deploy-Agent-Promote"})
    try:
        with opener.open(req,timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8",errors="replace"))
    except urllib.error.HTTPError as e:
        # urlopen()/opener.open() raise on any non-2xx status instead of
        # returning it -- without this, the endpoint's real {"ok":false,
        # "error":"..."} body (e.g. INVALID_ARTIFACT_DIGEST) is completely
        # lost behind a bare "HTTP Error 409: Conflict". Real bug found
        # live the first time this was exercised against an actual
        # Production Test host.
        try:
            return json.loads(e.read().decode("utf-8",errors="replace"))
        except Exception:
            return {"ok":False,"error":f"HTTP {e.code}: {e.reason}"}

def _remote_agent_status(opener,base,timeout=25):
    # Must reuse the authenticated opener (session cookie from
    # _remote_agent_client): /api/status is not in the Agent's login-exempt
    # route list, so an unauthenticated request gets redirected to the
    # login page's HTML instead of JSON, which then fails to parse as JSON
    # -- silently masking a real remote success as a bogus timeout.
    req=urllib.request.Request(base+"/api/status",headers={"User-Agent":"MESFlow-Deploy-Agent-Promote"})
    with opener.open(req,timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8",errors="replace"))

def _production_test_target():
    url=(os.environ.get("MESFLOW_PRODUCTION_TEST_AGENT_URL") or "").strip().rstrip("/")
    user=(os.environ.get("MESFLOW_PRODUCTION_TEST_AGENT_USER") or "admin").strip()
    password=(os.environ.get("MESFLOW_PRODUCTION_TEST_AGENT_PASSWORD") or "").strip()
    return url,user,password

def _production_target():
    url=(os.environ.get("MESFLOW_PRODUCTION_AGENT_URL") or "").strip().rstrip("/")
    user=(os.environ.get("MESFLOW_PRODUCTION_AGENT_USER") or "admin").strip()
    password=(os.environ.get("MESFLOW_PRODUCTION_AGENT_PASSWORD") or "").strip()
    return url,user,password

# Capabilities a target Agent must have before DEV will promote a MESFlow
# release to it. Deliberately excludes agent_self_update: a target can
# receive MESFlow releases perfectly well without supporting the Agent
# self-update protocol.
REQUIRED_PROMOTION_CAPABILITIES={"image_release_receive","digest_verify","remote_deploy","deploy_status","health_status"}
# Same idea for QA Center promotion -- a distinct capability set so an
# older target that can receive MESFlow releases but not QA ones (or vice
# versa) is reported precisely, never conflated with the MESFlow gate.
QA_REQUIRED_PROMOTION_CAPABILITIES={"qa_image_release_receive","qa_chunked_release_receive","qa_deploy","digest_verify","deploy_status","health_status"}
TUTORIAL_REQUIRED_CAPABILITIES={"tutorial_chunked_release_receive","tutorial_deploy","tutorial_status","digest_verify"}

def _remote_agent_tutorial_upload(opener,base,csrf,path,progress=None):
    path=Path(path); total=path.stat().st_size; digest=sha(path)
    start=_remote_agent_json_post(opener,base,"/tutorial-release/chunk/start",csrf,{"filename":path.name,"total_size":total,"sha256":digest,"chunk_size":QA_CHUNK_BYTES},timeout=60)
    upload_id=str(start.get("upload_id") or ""); sent=index=0
    if not upload_id: raise _RemoteAgentError("TUTORIAL_CHUNK_START_FAILED")
    try:
        with path.open("rb") as source:
            while chunk:=source.read(QA_CHUNK_BYTES):
                req=urllib.request.Request(base+f"/tutorial-release/chunk/{upload_id}/{index}",data=chunk,headers={"Content-Type":"application/octet-stream","X-CSRF-Token":csrf,"X-Chunk-SHA256":hashlib.sha256(chunk).hexdigest()})
                with opener.open(req,timeout=600) as response: result=json.loads(response.read() or "{}")
                if not result.get("ok"): raise _RemoteAgentError(f"TUTORIAL_CHUNK_UPLOAD_FAILED index={index}")
                sent+=len(chunk); index+=1
                if progress: progress(sent,total,index)
        return _remote_agent_json_post(opener,base,f"/tutorial-release/chunk/{upload_id}/complete",csrf,{"chunks":index,"sha256":digest,"total_size":total},timeout=900)
    except Exception:
        try: _remote_agent_json_post(opener,base,f"/tutorial-release/chunk/{upload_id}/abort",csrf,{},timeout=30)
        except Exception: pass
        raise

def _agent_compatibility(target_status,required=None):
    """Classify a target Agent's /api/status (or None/error on unreachable)
    as COMPATIBLE / UPDATE_AVAILABLE / INCOMPATIBLE / OFFLINE / NOT_CONFIGURED.

    Never blocks solely because AGENT_VERSION strings differ -- only a
    genuinely missing required capability makes it INCOMPATIBLE. `required`
    defaults to the MESFlow gate; pass QA_REQUIRED_PROMOTION_CAPABILITIES
    (or any other set) to check a different application's gate against the
    exact same target-status payload -- different applications may well
    have different capability requirements against the same Agent."""
    required=REQUIRED_PROMOTION_CAPABILITIES if required is None else required
    if not target_status or target_status.get("_unreachable"):
        return {"status":"OFFLINE","reason":str((target_status or {}).get("error") or "Target Agent unreachable"),"missing":[]}
    caps=target_status.get("capabilities")
    protocol=target_status.get("api_protocol_version")
    if caps is None and protocol is None:
        # Legacy Agent, predates capability reporting (API protocol 2). Its
        # actual capabilities cannot be positively confirmed from this
        # field alone -- but image-release receive/deploy/status/health
        # have existed since well before this reporting feature, so treat
        # it as usable and recommend an update rather than blocking it.
        return {"status":"UPDATE_AVAILABLE",
                "reason":f"Target Agent {target_status.get('agent_version','?')} does not report capabilities (predates API protocol {API_PROTOCOL_VERSION}). Treated as compatible based on legacy behavior; update recommended for explicit verification.",
                "missing":[]}
    caps=set(caps or [])
    missing=sorted(required-caps)
    if missing:
        return {"status":"INCOMPATIBLE",
                "reason":f"Target Agent {target_status.get('agent_version','?')} lacks {', '.join(missing)}",
                "missing":missing}
    if canonical_version(str(target_status.get("agent_version") or ""))!=canonical_version(AGENT_VERSION):
        return {"status":"UPDATE_AVAILABLE",
                "reason":f"Target is {target_status.get('agent_version')}; DEV has {AGENT_VERSION} available",
                "missing":[]}
    return {"status":"COMPATIBLE","reason":"","missing":[]}

def _query_target_agent(label,url_env,user_env,password_env):
    """Read-only: login (if a target is configured) + GET /api/status only."""
    url=(os.environ.get(url_env) or "").strip().rstrip("/")
    row={"name":label,"role":None,"agent_version":None,"api_protocol_version":None,"capabilities":[],
         "mesflow_version":None,"mesflow_healthy":None,"build_enabled":None,"configured":bool(url)}
    if not url:
        row["compatibility"]={"status":"NOT_CONFIGURED","reason":f"No target configured (set {url_env}/{user_env}/{password_env})","missing":[]}
        return row
    user=(os.environ.get(user_env) or "admin").strip(); password=(os.environ.get(password_env) or "").strip()
    try:
        if not password: raise _RemoteAgentError("no password configured")
        opener,base,csrf=_remote_agent_client(url,user,password)
        status=_remote_agent_get_json(opener,base,"/api/status")
    except Exception as ex:
        row["compatibility"]=_agent_compatibility({"_unreachable":True,"error":str(ex)})
        return row
    mes=status.get("mes") or {}
    row.update(role=status.get("server_role"),agent_version=status.get("agent_version"),
               api_protocol_version=status.get("api_protocol_version"),capabilities=status.get("capabilities") or [],
               mesflow_version=mes.get("version"),mesflow_healthy=mes.get("healthy"),build_enabled=status.get("build_enabled"))
    row["compatibility"]=_agent_compatibility(status)
    return row

def _target_agents_table():
    local_mes=mes_status()
    rows=[{"name":"LOCAL","role":SERVER_ROLE,"agent_version":AGENT_VERSION,"api_protocol_version":API_PROTOCOL_VERSION,
           "capabilities":AGENT_CAPABILITIES,"mesflow_version":local_mes.get("version"),"mesflow_healthy":local_mes.get("healthy"),
           "build_enabled":MESFLOW_BUILD_ENABLED,"configured":True,
           "compatibility":{"status":"COMPATIBLE","reason":"","missing":[]}}]
    rows.append(_query_target_agent("PRODUCTION TEST","MESFLOW_PRODUCTION_TEST_AGENT_URL","MESFLOW_PRODUCTION_TEST_AGENT_USER","MESFLOW_PRODUCTION_TEST_AGENT_PASSWORD"))
    rows.append(_query_target_agent("PRODUCTION","MESFLOW_PRODUCTION_AGENT_URL","MESFLOW_PRODUCTION_AGENT_USER","MESFLOW_PRODUCTION_AGENT_PASSWORD"))
    for row in rows[1:]:
        row["latest_agent_version"]=AGENT_VERSION
        row["updater_configured"]=bool(_agent_updater_target("PRODUCTION_TEST" if row["name"]=="PRODUCTION TEST" else "PRODUCTION")[0])
    return rows

# ---------------- Safe remote Agent update (no SSH) ----------------
def _agent_releases_root():
    return MESFLOW_SOURCE_DIR.parent/"artifacts"/"deploy-agent"/"releases"

def _deploy_agent_source_version():
    version_file=DEPLOY_AGENT_SOURCE_DIR/"VERSION.txt"
    try:
        return version_file.read_text(encoding="utf-8-sig").strip()
    except OSError:
        return ""

def _latest_agent_release():
    root=_agent_releases_root()
    if not root.is_dir(): return {}
    candidates=sorted(root.glob("*/agent-release.json"),key=lambda p:p.stat().st_mtime,reverse=True)
    if not candidates: return {}
    manifest=load_json(candidates[0],{})
    version=str(manifest.get("version") or "")
    release_dir=candidates[0].parent
    package=release_dir/f"AGENT_UPDATE_{version}.zip"
    package_exists=package.is_file()
    package_sha256=""
    sha_file=release_dir/f"AGENT_UPDATE_{version}.zip.sha256"
    if sha_file.is_file():
        # sha256sum(1) format: "<hex>  <filename>" -- take just the hex.
        package_sha256=sha_file.read_text(encoding="utf-8",errors="replace").split()[0:1]
        package_sha256=package_sha256[0] if package_sha256 else ""
    return {**manifest,"package":str(package),"package_exists":package_exists,
            "package_size":package.stat().st_size if package_exists else 0,
            "package_sha256":package_sha256,"release_dir":str(release_dir)}

# ---------------- Build Agent Package (task: AGENT_PACKAGE_BUILD_PUSH) ----------------
# DEV-only pipeline that turns the current workspace source into the exact
# immutable AGENT_UPDATE_<version>.zip artifact Bootstrap's /updater/update
# already knows how to install (deploy-agent/updater/updater.py's
# extract_and_verify_artifact() -- unmodified, untouched by this task; see
# bootstrap/AGENTS.md: "Bootstrap must remain the installer/update
# authority", "do not duplicate updater logic in DEV Agent"). This job only
# produces the artifact and reuses the existing _push_agent_update()/
# start_agent_update() to hand it to Bootstrap -- it does not reimplement
# verify/install/restart/health-check, all of which stay inside Bootstrap's
# single synchronous /updater/update call.
def agent_package_build_job_update(status,message,**extra):
    def mutate(state):
        job=dict(state.get("agent_package_build_job") or {})
        job.update(status=status,message=message,updated_at=now_text(),**extra)
        transitions=list(job.get("transitions") or [])
        if not transitions or transitions[-1].get("status")!=status:
            transitions.append({"status":status,"at":now_text(),"message":message})
        job["transitions"]=transitions
        state["agent_package_build_job"]=job
    return update_state(mutate).get("agent_package_build_job")

def _run_agent_version_bump(target_version=""):
    """Run deploy-agent/scripts/bump-version.sh: a fast, source-only edit
    (VERSION.txt, agent.py's AGENT_VERSION, docker/Dockerfile,
    docker/compose.linux.yml, docker/compose.windows.yml, README.md,
    docs/DEPLOY_DOCKER.md) -- never builds/tags/pushes a Docker image.
    DEV-only (build-enabled), same as Build Agent Package."""
    if not MESFLOW_BUILD_ENABLED: raise ValueError("BUILD_DISABLED")
    if not DEPLOY_AGENT_SOURCE_DIR.is_dir(): raise ValueError("SOURCE_NOT_FOUND")
    script=DEPLOY_AGENT_SOURCE_DIR/"scripts"/"bump-version.sh"
    if not script.is_file(): raise ValueError("BUMP_SCRIPT_NOT_FOUND")
    version_file=DEPLOY_AGENT_SOURCE_DIR/"VERSION.txt"
    before=version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else ""
    args=[str(script)]
    target_version=str(target_version or "").strip()
    if target_version:
        if not re.fullmatch(r"\d+\.\d+\.\d+(-docker-runtime)?",target_version): raise ValueError("VERSION_INVALID")
        args.append(target_version)
    log_path=LOG_DIR/"agent-version-bump.log"
    with log_path.open("w",encoding="utf-8") as log:
        result=subprocess.run(args,cwd=str(DEPLOY_AGENT_SOURCE_DIR),stdout=log,stderr=subprocess.STDOUT,text=True,timeout=30)
    log_tail=tail(log_path,60)
    if result.returncode:
        lines=[ln for ln in log_tail.strip().splitlines() if ln.strip()]
        raise RuntimeError(lines[-1] if lines else "VERSION_BUMP_FAILED")
    after=version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else ""
    entry={"at":now_text(),"before":before,"after":after,"log_tail":log_tail}
    def f(s): s["agent_version_bump"]=entry
    update_state(f)
    append_log(f"Deploy Agent version bump: {before} -> {after}")
    return entry

def _run_agent_package_build():
    try:
        source_version=_deploy_agent_source_version()
        script=DEPLOY_AGENT_SOURCE_DIR/"scripts"/"build-agent-release.sh"
        if not DEPLOY_AGENT_SOURCE_DIR.is_dir():
            agent_package_build_job_update("FAILED","SOURCE_NOT_FOUND",error_code="SOURCE_NOT_FOUND");return
        if not script.is_file():
            agent_package_build_job_update("FAILED","BUILD_SCRIPT_NOT_FOUND",error_code="BUILD_SCRIPT_NOT_FOUND");return
        agent_package_build_job_update("BUILDING","Preflight, version check, tests, package build",
            version=source_version,job_id=f"agent-package-{int(time.time())}",started_at=now_text())
        log_path=LOG_DIR/"agent-package-builder.log"
        with log_path.open("w",encoding="utf-8") as log:
            result=subprocess.run([str(script)],cwd=str(DEPLOY_AGENT_SOURCE_DIR),stdout=log,stderr=subprocess.STDOUT,text=True,timeout=BUILD_TIMEOUT)
        log_tail=tail(log_path,120)
        if result.returncode!=0:
            reason="TESTS_FAILED" if "TESTS_FAILED" in log_tail else \
                   "VERSION_ALREADY_RELEASED" if "VERSION_ALREADY_RELEASED" in log_tail else \
                   "VERSION_INVALID" if "VERSION_INVALID" in log_tail else \
                   "IMAGE_TAG_CONTAMINATED" if "IMAGE_TAG_CONTAMINATED" in log_tail else "BUILD_FAILED"
            agent_package_build_job_update("FAILED",reason,error_code=reason,log_file=str(log_path),log_tail=log_tail);return
        release=_latest_agent_release()
        agent_package_build_job_update("SUCCESS",f"Package {release.get('version','')} sẵn sàng",
            release=release,log_file=str(log_path),log_tail=log_tail)
    except subprocess.TimeoutExpired:
        agent_package_build_job_update("FAILED","BUILD_TIMEOUT",error_code="BUILD_TIMEOUT")
    except Exception as exc:
        code=str(exc) if str(exc).isupper() else "BUILD_FAILED"
        agent_package_build_job_update("FAILED",code,error_code=code)
    finally:
        if AGENT_PACKAGE_BUILD_LOCK.locked(): AGENT_PACKAGE_BUILD_LOCK.release()

def start_agent_package_build():
    if not AGENT_PACKAGE_BUILD_LOCK.acquire(False): raise RuntimeError("AGENT_PACKAGE_BUILD_ALREADY_RUNNING")
    try:
        agent_package_build_job_update("QUEUED","Build Agent Package đã được xếp hàng")
        threading.Thread(target=_run_agent_package_build,daemon=True).start()
    except Exception:
        AGENT_PACKAGE_BUILD_LOCK.release(); raise

def _deployment_platform_store():
    return DeploymentEvidenceStore(DATA_DIR/"deployment_platform")

def _deployment_platform_summary(mes=None,qa=None,mes_release=None,qa_release=None):
    """Normalized read model over the three existing deployment adapters.

    Mutation remains in the proven MESFlow/QA/updater paths; this projection
    gives Release Manager one vocabulary without duplicating those mechanics.

    Release Tab Performance Fix follow-up (reports/
    DEPLOY_AGENT_REFRESH_PERFORMANCE_FIX.md): mes/qa/mes_release/qa_release
    are optional so a caller that already computed them (the Release Deploy
    tab context builder) can pass them straight through instead of this
    function silently recomputing all four -- each one a real Docker
    inspect / QA network probe / release-summary (SHA-hashing) call --
    a SECOND time for the exact same request. A standalone caller (the
    /api/deployment-platform route) omits them and gets the previous
    from-scratch behavior, unchanged.
    """
    state=load_state()
    mes=mes if mes is not None else mes_status()
    qa=qa if qa is not None else qa_status()
    mes_release=mes_release if mes_release is not None else _release_summary()
    qa_release=qa_release if qa_release is not None else _qa_release_summary()
    agent_release=_latest_agent_release()
    mes_history=list(state.get("history") or []);qa_history=list(state.get("qa_history") or [])
    def component(name,running,healthy,latest,previous,states,rollback):
        return {"component":name,"running":running or "UNKNOWN","available":str((latest or {}).get("version") or ""),
                "previous":previous or "","healthy":bool(healthy),"artifact_digest":str((latest or {}).get("digest") or (latest or {}).get("image_digest") or ""),
                "artifact":str((latest or {}).get("package") or ""),"states":states,"rollback_available":bool(rollback)}
    components=[
      component(DeploymentComponent.MESFLOW.value,mes.get("version"),mes.get("healthy"),mes_release.get("latest"),
                str((mes_history[0] if mes_history else {}).get("from_version") or ""),mes_release.get("states") or {},bool(mes_history)),
      component(DeploymentComponent.QA_CENTER.value,qa.get("version"),qa.get("online"),qa_release.get("latest"),
                str((qa_history[0] if qa_history else {}).get("from_version") or ""),qa_release.get("states") or {},bool(qa_history)),
      component(DeploymentComponent.DEPLOY_AGENT.value,AGENT_VERSION,True,agent_release,
                str((state.get("agent_update_job") or {}).get("from_version") or ""),{"update":str((state.get("agent_update_job") or {}).get("status") or "IDLE")},
                bool((state.get("agent_update_job") or {}).get("from_version"))),
    ]
    return {"components":components,"environments":[e.value for e in DeploymentEnvironment],
            "artifact_policy":{"build_environment":"LOCAL","build_role":"DEV","build_enabled":_source_build_allowed(),
                               "test_rebuild":False,"production_rebuild":False,
                               "target_actions":["receive","verify","load","activate","health","rollback"]},
            "deployments":_deployment_platform_store().list(50),"generated_at":datetime.now().astimezone().isoformat(timespec="seconds")}

def _platform_retention_preview(component_name):
    component=DeploymentComponent(component_name)
    if component is DeploymentComponent.MESFLOW:
        candidates=_release_cleanup_candidates();root=_releases_root();retention=MESFLOW_RELEASE_RETENTION
        rows=[]
        versions=[str(version) for version in candidates]
        keep=set(versions[:retention])
        for version in versions:
            release_dir=_release_dir_for(version);meta=load_json(release_dir/"release.json",{});reasons=_release_cleanup_blockers(version,keep)
            rows.append({"version":version,"path":str(release_dir),"size_bytes":_dir_size(release_dir),"status":"SUCCESS",
                         "built_at":str(meta.get("built_at") or meta.get("created_at") or ""),"current":"CURRENTLY_DEPLOYED" in reasons,"previous":"ROLLBACK_TARGET_OF_LAST_DEPLOY" in reasons,
                         "pinned":(release_dir/"PINNED").is_file(),
                         "active_deployment":bool({"ACTIVE_DEPLOYMENT_JOB","ACTIVE_ROLLBACK_TARGET","BEING_PROMOTED"}&set(reasons)),
                         "evidence_protected":"PROMOTION_IN_PROGRESS" in reasons})
    elif component is DeploymentComponent.QA_CENTER:
        candidates=_qa_release_cleanup_candidates();root=_qa_releases_root();retention=QA_RELEASE_RETENTION
        versions=[str(version) for version in candidates];keep=set(versions[:retention]);rows=[]
        for version in versions:
            release_dir=_qa_release_dir_for(version);meta=load_json(release_dir/"release.json",{});reasons=_qa_release_cleanup_blockers(version,keep)
            rows.append({"version":version,"path":str(release_dir),"size_bytes":_dir_size(release_dir),"status":"SUCCESS",
                         "built_at":str(meta.get("built_at") or meta.get("created_at") or ""),"current":"CURRENTLY_DEPLOYED" in reasons,"previous":False,
                         "pinned":(release_dir/"PINNED").is_file(),
                         "active_deployment":bool({"ACTIVE_DEPLOYMENT_JOB","BEING_PROMOTED"}&set(reasons)),
                         "evidence_protected":"PROMOTION_IN_PROGRESS" in reasons})
    else:
        root=_agent_releases_root();retention=max(2,int(os.environ.get("MESFLOW_AGENT_RELEASE_RETENTION","5")));latest=_latest_agent_release();rows=[]
        manifests=sorted(root.glob("*/agent-release.json"),key=lambda p:p.stat().st_mtime,reverse=True) if root.is_dir() else []
        for manifest_path in manifests:
            meta=load_json(manifest_path,{});version=str(meta.get("version") or manifest_path.parent.name)
            rows.append({"version":version,"path":str(manifest_path.parent),"size_bytes":_dir_size(manifest_path.parent),"status":"SUCCESS",
                         "built_at":str(meta.get("built_at") or ""),"current":version==AGENT_VERSION,"previous":False,"pinned":(manifest_path.parent/"PINNED").is_file(),
                         "active_deployment":False,"evidence_protected":version==str(latest.get("version") or "")})
    return RetentionService(root,RetentionPolicy(keep_last_successful=retention)).preview(rows)

def _agent_updater_target(role):
    prefix="MESFLOW_PRODUCTION_TEST_AGENT" if role=="PRODUCTION_TEST" else "MESFLOW_PRODUCTION_AGENT"
    url=(os.environ.get(f"{prefix}_UPDATER_URL") or "").strip().rstrip("/")
    token=(os.environ.get(f"{prefix}_UPDATER_TOKEN") or "").strip()
    return url,token

def _push_agent_update(url,token,zip_path,timeout=300):
    data=Path(zip_path).read_bytes()
    req=urllib.request.Request(url+"/updater/update",data=data,method="POST",
        headers={"Authorization":f"Bearer {token}","Content-Type":"application/zip","User-Agent":"MESFlow-Deploy-Agent-Updater"})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8",errors="replace"))
    except urllib.error.HTTPError as e:
        body=e.read().decode("utf-8",errors="replace")
        try: return json.loads(body)
        except json.JSONDecodeError: return {"ok":False,"status":"FAILED","error":f"HTTP {e.code}: {body[:500]}"}

def agent_update_job_update(status,message,**extra):
    def mutate(s):
        j=dict(s.get("agent_update_job") or {});j.update(status=status,message=message,updated_at=now_text(),**extra);s["agent_update_job"]=j
    job=update_state(mutate).get("agent_update_job")
    if status in DEPLOYMENT_HISTORY_TERMINAL:
        role=str((job or {}).get("role") or "")
        env={"PRODUCTION_TEST":"TEST","PRODUCTION":"PRODUCTION"}.get(role,role or "LOCAL")
        try:
            _record_deployment_history("DEPLOY_AGENT",env,version=str((job or {}).get("version") or ""),
                status=status,message=message,started_at=(job or {}).get("started_at",""),finished_at=now_text(),
                deployment_id=f"agent-update-{role}-{(job or {}).get('version','')}-{(job or {}).get('updated_at','')}")
        except Exception as ex: append_log(f"Deployment history recording failed (agent update): {type(ex).__name__}: {ex}")
    return job

_agent_update_lock=threading.Lock()

def _run_agent_update(role):
    try:
        release=_latest_agent_release()
        if not release.get("package_exists"):
            raise _RemoteAgentError("AGENT_ARTIFACT_NOT_FOUND: run scripts/build-agent-release.sh first")
        url,token=_agent_updater_target(role)
        if not url or not token:
            raise _RemoteAgentError(f"AGENT_UPDATER_NOT_CONFIGURED: set the updater URL/token env vars for {role}")
        if role=="PRODUCTION" and os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() not in {"1","true","yes","on"}:
            raise _RemoteAgentError("PRODUCTION_AGENT_UPDATE_NOT_APPROVED: set MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 on this Agent for a Production Agent update")
        agent_update_job_update("UPDATING",f"Pushing Agent update {release.get('version')} to {url} (no SSH)",role=role,version=release.get("version"))
        result=_push_agent_update(url,token,release["package"])
        status=str(result.get("status") or "FAILED")
        if status not in {"SUCCESS","ROLLED_BACK"}: status="FAILED"
        agent_update_job_update(status,json.dumps(result)[:1000],role=role,version=release.get("version"),result=result)
    except Exception as exc:
        code=str(exc) if isinstance(exc,_RemoteAgentError) else f"{type(exc).__name__}: {exc}"
        agent_update_job_update("FAILED",code,role=role)
    finally:
        if _agent_update_lock.locked(): _agent_update_lock.release()

def start_agent_update(role):
    if not _agent_update_lock.acquire(False): raise RuntimeError("AGENT_UPDATE_ALREADY_RUNNING")
    try:
        agent_update_job_update("QUEUED","Agent update queued",role=role)
        threading.Thread(target=_run_agent_update,args=(role,),daemon=True).start()
    except Exception:
        _agent_update_lock.release(); raise

def _remote_agent_get_json(opener,base,path,timeout=20):
    req=urllib.request.Request(base+path,headers={"User-Agent":"MESFlow-Deploy-Agent-Promote"})
    with opener.open(req,timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8",errors="replace"))

def _remote_agent_post_json(opener,base,path,csrf,payload=None,timeout=30):
    """POST a JSON body to an already-authenticated remote Agent route,
    same CSRF contract as every other _remote_agent_* call (P5 fleet
    proxy routes: remote backup trigger, restore-drill trigger, etc)."""
    body=json.dumps(payload or {}).encode()
    req=urllib.request.Request(base+path,data=body,method="POST",
        headers={"Content-Type":"application/json","X-CSRF-Token":csrf,"User-Agent":"MESFlow-Deploy-Agent-Promote"})
    with opener.open(req,timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8",errors="replace"))

def _target_preflight(opener,base):
    """Read-only production preflight: GET only, via the already-authenticated
    session. Never uploads a release and never calls /deploy/<version>."""
    status=_remote_agent_get_json(opener,base,"/api/status")
    try: ops=_remote_agent_get_json(opener,base,"/api/ops/summary")
    except Exception as ex: ops={"error":str(ex)}
    try: backups=_remote_agent_get_json(opener,base,"/api/ops/backups")
    except Exception as ex: backups={"error":str(ex)}
    mes=status.get("mes") or {}; docker=mes.get("docker") or {}
    job=status.get("job") or {}
    job_running=job.get("status") in {"queued","uploading","validating","building","deploying","verifying"}
    build_disabled=(status.get("build_enabled") is False)
    postgres_health=(docker.get("service_health") or {}).get("postgres","unknown")
    disk=ops.get("disk") if isinstance(ops,dict) else None
    disk_ok=bool(disk) and disk.get("percent") is not None and disk.get("percent")<90
    mes_healthy=bool(mes.get("healthy"))
    ops_reachable=isinstance(ops,dict) and "error" not in ops
    backups_reachable=isinstance(backups,dict) and "error" not in backups
    healthy=(mes_healthy and build_disabled and status.get("deploy_enabled") is True
             and postgres_health in ("healthy","none") and not job_running
             and ops_reachable and (not disk or disk_ok))
    return {
        "checked_at":now_text(),
        "agent":{"version":status.get("agent_version"),"server_role":status.get("server_role"),
                 "build_enabled":status.get("build_enabled"),"deploy_enabled":status.get("deploy_enabled"),
                 "job_running":job_running},
        "mes":{"version":mes.get("version"),"healthy":mes_healthy,"schema_actual":mes.get("migration_head") or ""},
        "postgres":{"health":postgres_health},
        "disk":disk or {"note":"unavailable"},
        "docker":{"running":ops.get("docker_running") if ops_reachable else None,
                  "unhealthy":ops.get("docker_unhealthy") if ops_reachable else None} if ops_reachable else {"error":ops.get("error")},
        "backups":backups if backups_reachable else {"error":backups.get("error")},
        "release_compatible":bool(status.get("deploy_enabled")) and build_disabled,
        "healthy":healthy,
    }

def _run_production_preflight():
    url,user,password=_production_target()
    if not url or not password:
        raise _RemoteAgentError("PRODUCTION_AGENT_NOT_CONFIGURED: set MESFLOW_PRODUCTION_AGENT_URL/_USER/_PASSWORD")
    opener,base,csrf=_remote_agent_client(url,user,password)
    report=_target_preflight(opener,base)
    save_json(CONFIG_DIR/"production-preflight.json",report)
    return report

def promote_test_update(status,message,**extra):
    def mutate(s):
        j=dict(s.get("promote_test_job") or {});j.update(status=status,message=message,updated_at=now_text(),**extra);s["promote_test_job"]=j
    job=update_state(mutate).get("promote_test_job")
    if status in DEPLOYMENT_HISTORY_TERMINAL:
        try:
            _record_deployment_history("MESFLOW","TEST",version=str((job or {}).get("version") or ""),
                status=status,message=message,started_at=(job or {}).get("started_at",""),finished_at=now_text(),
                deployment_id=f"promote-test-{(job or {}).get('version','')}-{(job or {}).get('updated_at','')}")
        except Exception as ex: append_log(f"Deployment history recording failed (promote test): {type(ex).__name__}: {ex}")
    return job

def _run_promote_test(version):
    try:
        artifact=_artifact_for_release(version)
        if not artifact.get("package") or not Path(artifact["package"]).is_file():
            raise _RemoteAgentError("PACKAGE_NOT_FOUND")
        contamination=_release_contamination(version)
        if contamination.get("contaminated"):
            raise _RemoteAgentError(f"RELEASE_CONTAMINATED: {contamination.get('reason')}")
        promotion=_load_promotion_state()
        if promotion.get("version")!=version or not promotion.get("local_pass"):
            raise _RemoteAgentError("LOCAL_PASS_REQUIRED")
        url,user,password=_production_test_target()
        if not url or not password:
            raise _RemoteAgentError("PRODUCTION_TEST_AGENT_NOT_CONFIGURED: set MESFLOW_PRODUCTION_TEST_AGENT_URL/_USER/_PASSWORD")
        zip_path=Path(artifact["package"])
        local_sha=sha(zip_path)
        if artifact.get("package_sha256") and artifact["package_sha256"]!=local_sha:
            raise _RemoteAgentError("PACKAGE_SHA_SELF_CHECK_FAILED")
        opener,base,csrf=_remote_agent_client(url,user,password)
        # Version compatibility gate: online, correct role, required
        # capabilities present, build disabled -- never blocks solely
        # because AGENT_VERSION strings differ.
        target_status=_remote_agent_get_json(opener,base,"/api/status")
        compat=_agent_compatibility(target_status)
        if compat["status"]=="INCOMPATIBLE":
            raise _RemoteAgentError(f"TARGET_AGENT_INCOMPATIBLE: {compat['reason']}")
        if target_status.get("server_role") not in ("PRODUCTION_TEST",):
            raise _RemoteAgentError(f"TARGET_AGENT_WRONG_ROLE: expected PRODUCTION_TEST, target reports {target_status.get('server_role')!r}")
        if target_status.get("build_enabled"):
            raise _RemoteAgentError("TARGET_AGENT_BUILD_ENABLED: Production Test must not have source-build capability (MESFLOW_BUILD_ENABLED must be false)")
        promote_test_update("UPLOADING",f"Uploading {zip_path.name} (sha256={local_sha[:12]}...) to {url}",version=version)
        _remote_agent_upload(opener,base,csrf,zip_path)
        promote_test_update("DEPLOYING",f"Deploying {version} on target (--no-build; server enforces image-release contract)",version=version)
        _remote_agent_deploy(opener,base,csrf,version)
        deadline=time.time()+MES_VERIFY_TIMEOUT
        last={}
        while time.time()<deadline:
            time.sleep(3)
            try: last=_remote_agent_status(opener,base)
            except Exception as ex: last={"error":str(ex)}; continue
            job=last.get("job") or {}
            if job.get("status")=="success" and canonical_version(str(job.get("version") or ""))==canonical_version(version):
                break
            if job.get("status")=="failed":
                raise _RemoteAgentError(f"REMOTE_DEPLOY_FAILED: {job.get('message')}")
        else:
            raise _RemoteAgentError(f"REMOTE_DEPLOY_TIMEOUT: last status {last}")
        # The remote Agent's own run_job() already verified the image digest
        # byte-for-byte before starting the container (IMAGE_DIGEST_MISMATCH
        # aborts the deploy) — see _verify_and_prepare_image_release(). Here
        # we only need to confirm the remote reports the right version and is
        # healthy; a failed remote digest check would already show as
        # job.status == "failed" above.
        mes=(last or {}).get("mes") or {}
        remote_version=canonical_version(str(mes.get("version") or ""))
        version_ok=remote_version==canonical_version(version)
        healthy_ok=bool(mes.get("healthy"))
        if not (version_ok and healthy_ok):
            raise _RemoteAgentError(f"REMOTE_VERIFY_FAILED: version_ok={version_ok} healthy_ok={healthy_ok} mes={mes}")
        promote_test_update("VERIFYING","Checking remote schema and browser smoke",version=version)
        v70=_v70_release(version)
        _update_promotion_state(version,artifact,
            test_status="AWAITING_QA" if v70 else "PASS",test_pass=not v70,
            test_deployment_verified=True,test_deployed_digest=str(artifact.get("digest") or artifact.get("image_digest") or ""),
            test_message=("TEST deployment verified; release-test QA evidence required" if v70 else f"TEST_PASS: remote version={remote_version} healthy={healthy_ok}"),
            test_target=url)
        if not v70:
            promote_test_update("SUCCESS",f"TEST_PASS: {version} verified on {url}",version=version)
        elif "mes_release_test_gate" not in (target_status.get("capabilities") or []):
            # Older target Agent, pre-dating this gate: deployment is real
            # and verified, but nothing can run the release-test QA check
            # remotely yet. Degrade visibly rather than silently -- never
            # invent a PASS.
            promote_test_update("SUCCESS",
                f"TEST deployed and digest verified: {version}; release-test QA gate skipped "
                f"(target Agent {target_status.get('agent_version','')} does not support "
                f"mes_release_test_gate yet -- update the Deploy Agent on that host)",version=version)
        else:
            # Only the Agent physically co-located with a MESFlow instance
            # can reach that instance's own internal-only QA Center -- ask
            # the TARGET Agent to run "release-test" against ITS OWN local
            # QA Center (mirrors _run_local_gate(), just over HTTP), then
            # record the returned evidence into THIS (promoting) Agent's
            # own evidence store, since DEV owns the authoritative
            # production-readiness gate for this release.
            promote_test_update("RUNNING_TEST_QA_GATE",
                "Deployed and verified; running release-test QA evidence on the Production Test Agent's own QA Center",
                version=version)
            try:
                gate_response=_remote_agent_run_test_gate(opener,base,csrf,version)
                if not gate_response.get("ok"):
                    raise RuntimeError(str(gate_response.get("error") or "TEST_QA_GATE_FAILED"))
                # _record_gate_run() already appends this TEST run to the
                # evidence store and calls _update_promotion_state() itself
                # (test_status = this TEST run's own PASS/FAIL, test_pass =
                # the FULL holistic gate decision -- LOCAL run + TEST
                # deployment + TEST run + no blocking known issues, a
                # stricter bar than LOCAL_PASS on purpose since this is the
                # last checkpoint before Production). Do not recompute or
                # overwrite either field here.
                evidence=_record_gate_run(version,gate_response["payload"])
                test_status_final=evidence["test"]["status"]
                promote_test_update("SUCCESS",
                    f"TEST deployed and digest verified: {version}; release-test QA {test_status_final} "
                    f"(production-readiness: {evidence['decision']['decision']})",version=version)
            except Exception as gate_exc:
                # The DEPLOYMENT itself succeeded (test_deployment_verified
                # is already True above) -- only the QA evidence step
                # failed. Keep that distinction visible instead of masking
                # a real deploy success as a promote failure.
                gate_code=f"{type(gate_exc).__name__}: {gate_exc}"
                _update_promotion_state(version,artifact,test_status="FAILED",test_pass=False,
                    test_message=f"Deployed OK, but release-test QA gate failed: {gate_code}")
                promote_test_update("SUCCESS",
                    f"TEST deployed and digest verified: {version}; release-test QA gate FAILED: {gate_code}",version=version)
        # Run cleanup only after a successful, verified promotion.
        try: _cleanup_old_releases("TEST_PASS")
        except Exception as ex: append_log(f"Release cleanup after TEST_PASS failed: {type(ex).__name__}: {ex}")
    except Exception as exc:
        code=str(exc) if isinstance(exc,_RemoteAgentError) else f"{type(exc).__name__}: {exc}"
        try:
            artifact=_artifact_for_release(version)
            _update_promotion_state(version,artifact,test_status="FAILED",test_pass=False,test_message=code)
        except Exception:
            pass
        promote_test_update("FAILED",code,error_code=code)
    finally:
        if _promote_test_lock.locked(): _promote_test_lock.release()

def start_promote_test(version):
    if not _promote_test_lock.acquire(False): raise RuntimeError("PROMOTE_TEST_ALREADY_RUNNING")
    try:
        promote_test_update("QUEUED","Promote to Production Test queued",version=version,started_at=now_text())
        threading.Thread(target=_run_promote_test,args=(version,),daemon=True).start()
    except Exception:
        _promote_test_lock.release(); raise

# =====================================================================
# QA Center: Build Once / Promote Same Artifact
#
# Applies the exact same architecture as MESFlow above -- immutable image,
# immutable release ZIP (image + compose.yml + metadata only, never
# application source), Deploy Local -> LOCAL_PASS -> Promote Production
# Test -> TEST_PASS -> human-gated Promote Production -- to the second
# application this Agent can build/deploy/promote. Reuses, unmodified, the
# exact same low-level plumbing MESFlow uses: load_json/save_json/
# update_state/load_state, sha()/canonical_version()/norm()/
# safe_extract_zip(), _run_capture()/_dir_size()/_bytes(), and the whole
# _remote_agent_* HTTP client (_remote_agent_client/_remote_agent_qa_upload/
# _remote_agent_qa_deploy/_remote_agent_status/_remote_agent_get_json) and
# _agent_compatibility() capability gate. Only the QA-specific policy
# (what "currently deployed"/"healthy"/"the compose file" mean for QA) is
# written fresh -- MESFlow's own functions above are never modified to
# reach here, so the existing, tested MESFlow pipeline is unaffected.
# QA's promotion state, jobs and locks are 100% independent of MESFlow's
# (separate state.json keys, separate QA_PROMOTION_STATE_FILE) -- see
# AGENTS.md "Release Manager Safety".
# =====================================================================

def _qa_releases_root():
    return QA_CENTER_SOURCE_DIR.parent/"artifacts"/"qa-center"/"releases"

def _qa_release_dir_for(version):
    return _qa_releases_root()/version

def _qa_release_contamination(version):
    """Identical policy to _release_contamination(), scoped to QA's own
    releases root and image tag."""
    root=_qa_release_dir_for(version)
    marker=load_json(root/"CONTAMINATED.json",{})
    if marker.get("contaminated"):
        return {"contaminated":True,"reason":marker.get("reason","Marked contaminated"),"source":"marker"}
    meta=load_json(root/"release.json",{})
    image=str(meta.get("image") or ""); expected_id=str(meta.get("image_id") or "")
    if image and expected_id:
        try:
            r=subprocess.run(["docker","image","inspect",image,"--format","{{.Id}}"],capture_output=True,text=True,timeout=15)
            if r.returncode==0:
                actual_id=r.stdout.strip()
                if actual_id and actual_id!=expected_id:
                    return {"contaminated":True,"reason":f"Docker tag {image} now points at {actual_id}, not the frozen id {expected_id}. A later build moved the tag.","source":"tag_drift"}
        except Exception: pass
    return {"contaminated":False}

def _qa_artifact_for_release(version):
    root=_qa_release_dir_for(version)
    package=root/f"QACenter_{version}.deploy.zip"
    info=load_json(root/"image-info.json",{}); meta=load_json(root/"release.json",{})
    return {"version":version,"image":meta.get("image",info.get("image")),"digest":meta.get("image_digest",info.get("digest")),
            "image_id":meta.get("image_id",""),"package":str(package),"package_sha256":sha(package) if package.is_file() else "",
            "source_commit":meta.get("source_commit",""),"built_at":meta.get("built_at","")}

def _qa_load_promotion_state():
    with _qa_promotion_lock:
        return load_json(QA_PROMOTION_STATE_FILE,{})

def _qa_reset_promotion_state(version,artifact):
    state={"application":"qa-center","version":version,"source_commit":artifact.get("source_commit",""),
           "package_sha256":artifact.get("package_sha256",""),"image":artifact.get("image",""),
           "image_digest":artifact.get("digest") or artifact.get("image_digest",""),"image_id":artifact.get("image_id",""),
           "build_status":"PASS","local_status":"NOT_TESTED","local_pass":False,
           "test_status":"NOT_DEPLOYED","test_pass":False,"production_status":"NOT_DEPLOYED","production_pass":False}
    with _qa_promotion_lock: save_json(QA_PROMOTION_STATE_FILE,state)
    return state

def _qa_sync_release_promotion_json(version,state):
    path=_qa_release_dir_for(version)/"PROMOTION.json"
    doc=load_json(path,{})
    doc.update(application="qa-center",version=version,image_digest=state.get("image_digest",""),source_commit=state.get("source_commit",""))
    doc["local"]={"status":"success" if state.get("local_pass") else (state.get("local_status") or "NOT_DEPLOYED"),"message":state.get("local_message","")}
    doc["production_test"]={"status":"success" if state.get("test_pass") else (state.get("test_status") or "NOT_DEPLOYED"),"message":state.get("test_message","")}
    doc["production"]={"status":"success" if state.get("production_pass") else (state.get("production_status") or "NOT_DEPLOYED"),"message":state.get("production_message","")}
    try: save_json(path,doc)
    except OSError: pass

def _qa_update_promotion_state(version,artifact,**fields):
    with _qa_promotion_lock:
        state=load_json(QA_PROMOTION_STATE_FILE,{})
    if state.get("version")!=version:
        state=_qa_reset_promotion_state(version,artifact)
    state.update(fields)
    with _qa_promotion_lock: save_json(QA_PROMOTION_STATE_FILE,state)
    _qa_sync_release_promotion_json(version,state)
    return state

# --- QA build (DEV only) -------------------------------------------------

def qa_release_build_update(status,message,**extra):
    def mutate(s):
        j=dict(s.get("qa_release_build_job") or {});j.update(status=status,message=message,updated_at=now_text(),**extra);s["qa_release_build_job"]=j
    return update_state(mutate).get("qa_release_build_job")

def _qa_release_summary():
    version_file=QA_CENTER_SOURCE_DIR/"current"/"VERSION"
    version=version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else "—"
    try:
        commit=subprocess.run(["git","-C",str(QA_CENTER_SOURCE_DIR),"rev-parse","--short","HEAD"],capture_output=True,text=True,timeout=5).stdout.strip() or "unknown"
    except Exception: commit="unknown"
    latest=sorted(_qa_releases_root().glob("*/image-info.json"),key=lambda p:p.stat().st_mtime,reverse=True) if _qa_releases_root().is_dir() else []
    build=load_json(latest[0],{}) if latest else {}
    if latest:
        package=latest[0].parent/f"QACenter_{build.get('version','')}.deploy.zip"
        release_meta=load_json(latest[0].parent/"release.json",{})
        build={**build,"package":str(package),"package_sha256":sha(package) if package.is_file() else "",
               "image_id":release_meta.get("image_id","")}
    contamination=_qa_release_contamination(build.get("version","")) if build.get("version") else {"contaminated":False}
    build_job=load_state().get("qa_release_build_job") or {}
    build_state={"QUEUED":"BUILDING","BUILDING":"BUILDING","SUCCESS":"PASS","FAILED":"FAILED"}.get(build_job.get("status",""),"IDLE" if not build_job else "IDLE")
    promotion=load_json(QA_PROMOTION_STATE_FILE,{})
    if promotion.get("version")!=build.get("version"): promotion={"version":build.get("version",""),"local_status":"NOT_TESTED","test_status":"NOT_DEPLOYED","production_status":"NOT_DEPLOYED"}
    local_pass=bool(promotion.get("local_pass")); test_pass=bool(promotion.get("test_pass"))
    zip_ok=bool(promotion.get("zip_sha_unchanged")); digest_ok=bool(promotion.get("image_digest_unchanged"))
    production_promote_enabled=os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() in {"1","true","yes","on"}
    gate_ok=local_pass and test_pass and zip_ok and digest_ok and not contamination.get("contaminated")
    build_block=None if MESFLOW_BUILD_ENABLED else "Build is disabled on this Agent (MESFLOW_BUILD_ENABLED=0 — this host is not DEV)."
    local_block=None
    if not build.get("version"): local_block="No QA release has been built yet."
    elif contamination.get("contaminated"): local_block=f"Release {build.get('version')} is CONTAMINATED: {contamination.get('reason')}"
    test_block=None
    if not local_pass: test_block="BLOCKED: QA Center chưa LOCAL_PASS cho artifact hiện tại. Hãy Deploy Local và chờ LOCAL_PASS."
    elif contamination.get("contaminated"): test_block=f"Release {build.get('version')} is CONTAMINATED: {contamination.get('reason')}"
    elif not (os.environ.get("MESFLOW_PRODUCTION_TEST_AGENT_URL") or "").strip(): test_block="BLOCKED: Chưa cấu hình Production Test Agent. Cần MESFLOW_PRODUCTION_TEST_AGENT_URL/_USER/_PASSWORD."
    production_block=None
    if not gate_ok:
        missing=[]
        if not local_pass: missing.append("LOCAL_PASS")
        if not test_pass: missing.append("TEST_PASS")
        if not zip_ok: missing.append("ZIP SHA unchanged")
        if not digest_ok: missing.append("image digest unchanged")
        if contamination.get("contaminated"): missing.append("not contaminated")
        production_block="Missing: "+", ".join(missing)
    elif not production_promote_enabled:
        production_block="MESFLOW_PRODUCTION_PROMOTE_ENABLED is not set on this Agent."
    return {"application":"qa-center","source_path":str(QA_CENTER_SOURCE_DIR),"source_exists":QA_CENTER_SOURCE_DIR.is_dir(),
            "source_version":version,"git":commit,"latest":build,"contamination":contamination,
            "states":{"build":build_state,"local":promotion.get("local_status","NOT_TESTED"),
                      "test":promotion.get("test_status","NOT_DEPLOYED"),"production":promotion.get("production_status","NOT_DEPLOYED")},
            "promotion":{**promotion,"production_gate":gate_ok,"production_promote_enabled":production_promote_enabled},
            "blocked":{"build":build_block,"local":local_block,"test":test_block,"production":production_block},
            "production_target_configured":bool((os.environ.get("MESFLOW_PRODUCTION_AGENT_URL") or "").strip())}

def _run_qa_version_bump(target_version=""):
    """Run qa-center/scripts/bump-version.sh: a fast, source-only edit
    (current/VERSION, current/agent.py's APP_VERSION) -- never builds/tags/
    pushes a Docker image. DEV-only (build-enabled), same as QA Build
    Release, since Production Test/Production never carry or need QA
    Center source."""
    if not MESFLOW_BUILD_ENABLED: raise ValueError("BUILD_DISABLED")
    if not QA_CENTER_SOURCE_DIR.is_dir(): raise ValueError("SOURCE_NOT_FOUND")
    script=QA_CENTER_SOURCE_DIR/"scripts"/"bump-version.sh"
    if not script.is_file(): raise ValueError("BUMP_SCRIPT_NOT_FOUND")
    version_file=QA_CENTER_SOURCE_DIR/"current"/"VERSION"
    before=version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else ""
    args=[str(script)]
    target_version=str(target_version or "").strip()
    if target_version:
        if not re.fullmatch(r"\d+\.\d+\.\d+(\.\d+)?",target_version): raise ValueError("VERSION_INVALID")
        args.append(target_version)
    log_path=LOG_DIR/"qa-version-bump.log"
    with log_path.open("w",encoding="utf-8") as log:
        result=subprocess.run(args,cwd=str(QA_CENTER_SOURCE_DIR),stdout=log,stderr=subprocess.STDOUT,text=True,timeout=30)
    log_tail=tail(log_path,60)
    if result.returncode:
        lines=[ln for ln in log_tail.strip().splitlines() if ln.strip()]
        raise RuntimeError(lines[-1] if lines else "VERSION_BUMP_FAILED")
    after=version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else ""
    entry={"at":now_text(),"before":before,"after":after,"log_tail":log_tail}
    def f(s): s["qa_version_bump"]=entry
    update_state(f)
    append_log(f"QA Center version bump: {before} -> {after}")
    return entry

def _run_qa_release_build():
    try:
        if not MESFLOW_BUILD_ENABLED: raise ValueError("BUILD_DISABLED")
        script=QA_CENTER_SOURCE_DIR/"scripts"/"build-release.sh"
        if not QA_CENTER_SOURCE_DIR.is_dir(): raise ValueError("SOURCE_NOT_FOUND")
        if not script.is_file(): raise ValueError("BUILD_SCRIPT_NOT_FOUND")
        qa_release_build_update("BUILDING","Đang build QA Center Docker image tại DEV",source_path=str(QA_CENTER_SOURCE_DIR))
        log_path=LOG_DIR/"qa-release-builder.log"
        with log_path.open("w",encoding="utf-8") as log:
            result=subprocess.run([str(script)],cwd=str(QA_CENTER_SOURCE_DIR),stdout=log,stderr=subprocess.STDOUT,text=True,timeout=BUILD_TIMEOUT)
        log_tail=tail(log_path,120)
        if result.returncode: qa_release_build_update("FAILED","BUILD_FAILED",error_code="BUILD_FAILED",log_tail=log_tail,log_file=str(log_path));return
        latest=sorted(_qa_releases_root().glob("*/image-info.json"),key=lambda p:p.stat().st_mtime,reverse=True)
        if not latest: raise ValueError("PACKAGE_NOT_FOUND")
        info=load_json(latest[0],{})
        qa_release_build_update("SUCCESS","QA local build complete",
            latest={**info,"package":str(latest[0].parent/("QACenter_"+info.get("version","")+".deploy.zip"))},
            source=_qa_release_summary(),log_tail=log_tail,log_file=str(log_path))
    except subprocess.TimeoutExpired:
        qa_release_build_update("FAILED","BUILD_TIMEOUT",error_code="BUILD_TIMEOUT")
    except Exception as exc:
        code=str(exc) if str(exc).isupper() else "BUILD_FAILED";qa_release_build_update("FAILED",code,error_code=code)
    finally:
        if QA_BUILD_LOCK.locked(): QA_BUILD_LOCK.release()

def start_qa_release_build():
    if not QA_BUILD_LOCK.acquire(False): raise RuntimeError("BUILD_ALREADY_RUNNING")
    try:
        qa_release_build_update("QUEUED","QA build release queued");threading.Thread(target=_run_qa_release_build,daemon=True).start()
    except Exception:
        QA_BUILD_LOCK.release();raise

# --- QA Deploy Local (DEV, --no-build) -----------------------------------

def _qa_release_compose(log,args,check=True,timeout=300,env_extra=None):
    """Same shape as _docker_compose(), scoped to QA_HOME/compose.yml and
    MESFLOW_QA_IMAGE instead of TARGET_HOME/compose.yml and MESFLOW_IMAGE.
    Deliberately NOT named _qa_compose(): that name is already used by the
    legacy full-source QA deploy path below (different signature, different
    compose file -- QA_HOME/current/docker/compose.yml, project "mesflow-qa")
    -- a real bug caught live (Python silently shadows same-named top-level
    defs; calling this under the old name actually invoked the *legacy*
    function with mismatched positional args, corrupting nothing but raising
    a confusing io.UnsupportedOperation). Two distinctly-named functions
    keep both deploy paths independently correct during the transition
    (see section 13, "Legacy Deploy" in reports/QA_CENTER_BUILD_ONCE_PROMOTION.md)."""
    compose=QA_HOME/"compose.yml"
    if not compose.is_file(): raise RuntimeError(f"Missing {compose}")
    cmd=["docker","compose","-p",_qa_release_project_name(),"-f",str(compose),*args]
    log.write("RUN: "+" ".join(cmd)+"\n"); log.flush()
    env=os.environ.copy(); meta=load_json(QA_HOME/"release.json",{})
    if meta.get("image"): env["MESFLOW_QA_IMAGE"]=str(meta.get("image"))
    env.update(env_extra or {})
    r=subprocess.run(cmd,cwd=str(QA_HOME),env=env,stdout=log,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    if check and r.returncode:
        raise RuntimeError(f"docker compose {' '.join(args)} failed with code {r.returncode}")
    return r.returncode

def _qa_release_project_name():
    """Stable Compose ownership identity for QA image releases."""
    configured=(os.environ.get("MESFLOW_QA_COMPOSE_PROJECT") or "").strip()
    return configured or QA_HOME.name.replace("_","-").lower()

def _qa_takeover_legacy_container_if_needed(log):
    """Remove only a conflicting legacy/manual QA container.

    Once the named container belongs to this image-release Compose project,
    subsequent deploys rely on compose --force-recreate and do not perform a
    manual docker rm. Host bind-mounted runtime data is never touched.
    """
    inspect=subprocess.run([
        "docker","inspect","mesflow-qa-center","--format",
        '{{ index .Config.Labels "com.docker.compose.project" }}'
    ],capture_output=True,text=True,timeout=15)
    if inspect.returncode!=0:
        return False
    owner=(inspect.stdout or "").strip()
    expected=_qa_release_project_name()
    if owner==expected:
        log.write(f"Existing mesflow-qa-center already owned by Compose project {expected}; normal release update\n"); log.flush()
        return False
    log.write(f"Taking over legacy mesflow-qa-center container (owner={owner or 'none'}; expected={expected})\n"); log.flush()
    removed=subprocess.run(["docker","rm","-f","mesflow-qa-center"],capture_output=True,text=True,timeout=30)
    log.write((removed.stdout or "")+(removed.stderr or "")+"\n"); log.flush()
    if removed.returncode:
        raise RuntimeError(f"QA_LEGACY_TAKEOVER_FAILED: {(removed.stderr or removed.stdout or '').strip()}")
    return True

def _migrate_qa_runtime_data_if_needed(log):
    """One-time, safe migration of QA's real persistent data (state/logs/
    reports/config -- see reports/QA_CENTER_BUILD_ONCE_PROMOTION.md for the
    read-only audit that found it) from the legacy location
    (QA_HOME/current/runtime, bind-mounted by the old source-deploy
    compose.yml) to the new top-level QA_HOME/runtime (mounted by the new
    image-release compose.yml). Never runs if the new location already has
    content -- copy-once, never overwrite, old copy is left in place as a
    safety net (never deleted by this function)."""
    old=QA_HOME/"current"/"runtime"
    new=QA_HOME/"runtime"
    if not old.is_dir():
        return
    if new.is_dir() and any(new.iterdir()):
        return  # already migrated (or already has independent data) -- do not touch
    try:
        new.mkdir(parents=True,exist_ok=True)
        for item in old.iterdir():
            dest=new/item.name
            if item.is_dir(): shutil.copytree(item,dest,dirs_exist_ok=True)
            else: shutil.copy2(item,dest)
        log.write(f"Migrated QA persistent data: {old} -> {new} (old copy left in place)\n"); log.flush()
        append_log(f"QA runtime data migrated: {old} -> {new}")
    except OSError as ex:
        log.write(f"WARNING: QA runtime data migration failed ({ex}); continuing with a fresh {new}\n"); log.flush()

def _qa_actual_running_image_id():
    try:
        r=subprocess.run(["docker","inspect","mesflow-qa-center","--format","{{.Image}}"],capture_output=True,text=True,timeout=15)
        return r.stdout.strip() if r.returncode==0 else ""
    except Exception: return ""

def _qa_http_smoke_ok(timeout=6):
    try:
        payload,code=qa_http_json("/api/version",timeout)
        return code==200 and bool(payload.get("ok"))
    except Exception:
        return False

def _record_qa_local_deploy_result(version,success,message=""):
    """Same evidence-based LOCAL_PASS policy as _record_local_deploy_result():
    computed from the real running image id + real reported version + a real
    HTTP smoke check, never from the deploy job's return code alone."""
    artifact=_qa_artifact_for_release(version)
    if not artifact.get("version"): return
    contamination=_qa_release_contamination(version)
    if not success:
        _qa_update_promotion_state(version,artifact,local_status="FAILED",local_pass=False,local_message=message); return
    if contamination.get("contaminated"):
        _qa_update_promotion_state(version,artifact,local_status="FAILED",local_pass=False,
                                    local_message=f"CONTAMINATED release: {contamination.get('reason')}"); return
    actual_id=_qa_actual_running_image_id()
    expected_id=str(artifact.get("image_id") or "")
    image_ok=bool(expected_id) and actual_id==expected_id
    version_payload,code=qa_http_json("/api/version",6)
    actual_version=str(version_payload.get("version") or "")
    version_ok=code==200 and canonical_version(actual_version)==canonical_version(version)
    smoke_ok=_qa_http_smoke_ok()
    local_pass=image_ok and version_ok and smoke_ok
    reasons=[]
    if not image_ok: reasons.append(f"running image id {actual_id or 'unknown'} != frozen id {expected_id or 'unknown'}")
    if not version_ok: reasons.append(f"reported version {actual_version or 'unknown'} != {version}")
    if not smoke_ok: reasons.append("HTTP smoke check (/api/version) failed")
    _qa_update_promotion_state(version,artifact,
        local_status="PASS" if local_pass else "FAILED",local_pass=local_pass,
        local_message="LOCAL_PASS" if local_pass else "; ".join(reasons),
        actual_version=actual_version,image_id_verified=image_ok,smoke_ok=smoke_ok,
        zip_sha_unchanged=True,image_digest_unchanged=image_ok)
    if local_pass:
        # Run cleanup only after a successful, verified deployment.
        try: _qa_cleanup_old_releases("LOCAL_PASS")
        except Exception as ex: append_log(f"QA release cleanup after LOCAL_PASS failed: {type(ex).__name__}: {ex}")

def qa_local_deploy_update(status,message,**extra):
    def mutate(s):
        j=dict(s.get("qa_local_deploy_job") or {});j.update(status=status,message=message,updated_at=now_text(),**extra);s["qa_local_deploy_job"]=j
    job=update_state(mutate).get("qa_local_deploy_job")
    if status in DEPLOYMENT_HISTORY_TERMINAL:
        try:
            _record_deployment_history("QA_CENTER","LOCAL",version=str((job or {}).get("version") or ""),
                status=status,message=message,started_at=(job or {}).get("started_at",""),finished_at=now_text(),
                log_file=(job or {}).get("log_file",""),
                deployment_id=f"qa-local-{(job or {}).get('version','')}-{(job or {}).get('updated_at','')}")
        except Exception as ex: append_log(f"Deployment history recording failed (QA local deploy): {type(ex).__name__}: {ex}")
    return job

def _qa_deploy_from_staging(version,log):
    """The one shared deploy mechanic, used identically whether this Agent
    is DEV (staging populated from the workspace artifact) or a target
    (staging populated by /qa-release/upload): verify checksums -> docker
    load exact image -> verify digest -> install compose.yml/release.json
    at QA_HOME -> docker compose up -d --no-build (mesflow-qa-center only)
    -> health -> version. Never touches mesflow-app, PostgreSQL, or ESP
    services -- the compose command is scoped to exactly one service name.
    Raises on any failure; caller records the outcome into its own job key."""
    root=QA_IMAGE_RELEASES_DIR/version
    if not (root/"release.json").is_file(): raise RuntimeError(f"STAGED_RELEASE_NOT_FOUND: {root}")
    rel_version,meta=validate_qa_image_release_contract(root)
    if canonical_version(rel_version)!=canonical_version(version): raise RuntimeError(f"VERSION_MISMATCH in staged release: {rel_version}")
    for line in (root/"checksums.txt").read_text(encoding="utf-8").splitlines():
        parts=line.split(None,1)
        if len(parts)!=2: continue
        expected_sha,fname=parts[0].strip(),parts[1].strip()
        fpath=root/fname
        if fpath.is_file() and sha(fpath)!=expected_sha:
            raise RuntimeError(f"CHECKSUM_MISMATCH: {fname}")
    log.write("Checksums verified\n"); log.flush()
    tar_path=root/str(meta.get("bundle") or "")
    if not tar_path.is_file(): raise RuntimeError("IMAGE_BUNDLE_NOT_FOUND")
    log.write(f"docker load {tar_path.name}\n"); log.flush()
    r=subprocess.run(["docker","load","-i",str(tar_path)],capture_output=True,text=True,timeout=600)
    log.write((r.stdout or "")+(r.stderr or "")+"\n"); log.flush()
    if r.returncode: raise RuntimeError("DOCKER_LOAD_FAILED")
    expected_id=str(meta.get("image_id") or "")
    idr=subprocess.run(["docker","image","inspect",str(meta.get("image")),"--format","{{.Id}}"],capture_output=True,text=True,timeout=15)
    actual_id=idr.stdout.strip()
    if expected_id and actual_id!=expected_id: raise RuntimeError(f"IMAGE_DIGEST_MISMATCH: expected {expected_id} got {actual_id}")
    log.write(f"Image verified: {actual_id}\n"); log.flush()
    QA_HOME.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/"compose.yml",QA_HOME/"compose.yml")
    shutil.copy2(root/"release.json",QA_HOME/"release.json")
    _migrate_qa_runtime_data_if_needed(log)
    _qa_takeover_legacy_container_if_needed(log)
    # existing QA stays up until recreate: `up -d --force-recreate` only
    # tears the old mesflow-qa-center container down once the new one is
    # created from the newly-loaded image, so QA Center never goes fully
    # dark mid-deploy the way a stop-then-start sequence would.
    log.write(f"docker compose up -d --no-build --force-recreate mesflow-qa-center (image={meta.get('image')})\n"); log.flush()
    _qa_release_compose(log,["up","-d","--no-build","--force-recreate","mesflow-qa-center"])
    deadline=time.time()+90; healthy=False; last_seen=""
    while time.time()<deadline:
        time.sleep(2)
        v,code=qa_http_json("/api/version",4)
        last_seen=f"code={code} version={v.get('version')}"
        if code==200 and canonical_version(str(v.get("version") or ""))==canonical_version(version):
            healthy=True; break
    log.write(f"Health poll: {last_seen} healthy={healthy}\n")
    if not healthy: raise RuntimeError(f"QA_VERIFY_TIMEOUT: last seen {last_seen}")

def _stage_qa_release_from_workspace_artifact(version):
    """DEV only: copy the frozen workspace artifact (artifacts/qa-center/
    releases/<version>, from the immutable build) into this Agent's own
    local staging (QA_IMAGE_RELEASES_DIR) -- the same staging area a target
    Agent's /qa-release/upload would populate from a network upload. After
    this, DEV deploys from staging exactly like every other Agent does."""
    artifact=_qa_artifact_for_release(version)
    if not artifact.get("package") or not Path(artifact["package"]).is_file(): raise RuntimeError("PACKAGE_NOT_FOUND")
    extract=QA_UPLOAD_DIR/f"qa_image_release_{uuid.uuid4().hex}"; extract.mkdir(parents=True)
    try:
        safe_extract_zip(Path(artifact["package"]),extract)
        root=locate_qa_image_release_root(extract)
        validate_qa_image_release_contract(root)
        target=QA_IMAGE_RELEASES_DIR/version
        if target.exists(): shutil.rmtree(target)
        shutil.copytree(root,target)
    finally:
        shutil.rmtree(extract,ignore_errors=True)

def _run_qa_local_deploy(version):
    """DEV: stage from the workspace artifact, deploy, then record
    LOCAL_PASS from real evidence (image id, reported version, HTTP smoke)."""
    qa_local_deploy_update("DEPLOYING",f"Deploying QA Center {version}",version=version,started_at=now_text())
    log_path=LOG_DIR/f"qa_deploy_{version}_{datetime.now():%Y%m%d_%H%M%S}.log"
    status="failed"; message=""
    try:
        contamination=_qa_release_contamination(version)
        if contamination.get("contaminated"): raise RuntimeError(f"RELEASE_CONTAMINATED: {contamination.get('reason')}")
        with log_path.open("w",encoding="utf-8") as log:
            log.write(f"Deploying QA Center {version} (image-release, --no-build)\n"); log.flush()
            _stage_qa_release_from_workspace_artifact(version)
            _qa_deploy_from_staging(version,log)
        status="success"; message=f"QA {version} deployed and verified"
    except Exception as e:
        message=f"{type(e).__name__}: {e}"; append_log(f"QA local deploy failed: {message}")
    qa_local_deploy_update(status,message,version=version,log_file=str(log_path))
    try: _record_qa_local_deploy_result(version,status=="success",message)
    except Exception as ex: append_log(f"QA LOCAL_PASS recording failed: {type(ex).__name__}: {ex}")

def start_qa_local_deploy(version):
    threading.Thread(target=_run_qa_local_deploy,args=(version,),daemon=True).start()

def qa_target_deploy_update(status,message,**extra):
    def mutate(s):
        j=dict(s.get("qa_image_deploy_job") or {});j.update(status=status,message=message,updated_at=now_text(),**extra);s["qa_image_deploy_job"]=j
    job=update_state(mutate).get("qa_image_deploy_job")
    if status in DEPLOYMENT_HISTORY_TERMINAL:
        env={"PRODUCTION_TEST":"TEST","PRODUCTION":"PRODUCTION"}.get(SERVER_ROLE,SERVER_ROLE or "LOCAL")
        try:
            _record_deployment_history("QA_CENTER",env,version=str((job or {}).get("version") or ""),
                status=status,message=message,started_at=(job or {}).get("started_at",""),finished_at=now_text(),
                log_file=(job or {}).get("log_file",""),
                deployment_id=f"qa-target-{(job or {}).get('version','')}-{(job or {}).get('updated_at','')}")
        except Exception as ex: append_log(f"Deployment history recording failed (QA target deploy): {type(ex).__name__}: {ex}")
    return job

def _run_qa_target_deploy(version):
    """Target (PRODUCTION_TEST/PRODUCTION): deploy an already-uploaded,
    staged release. Never touches DEV-only promotion state -- the DEV side
    records TEST_PASS itself after polling this job to success."""
    qa_target_deploy_update("running",f"Deploying QA Center {version}",version=version,started_at=now_text())
    log_path=LOG_DIR/f"qa_target_deploy_{version}_{datetime.now():%Y%m%d_%H%M%S}.log"
    status="failed"; message=""
    try:
        contamination=_qa_release_contamination(version)
        if contamination.get("contaminated"): raise RuntimeError(f"RELEASE_CONTAMINATED: {contamination.get('reason')}")
        with log_path.open("w",encoding="utf-8") as log:
            log.write(f"Deploying QA Center {version} (image-release, --no-build)\n"); log.flush()
            _qa_deploy_from_staging(version,log)
        status="success"; message=f"QA {version} deployed and verified"
    except Exception as e:
        message=f"{type(e).__name__}: {e}"; append_log(f"QA target deploy failed: {message}")
    qa_target_deploy_update(status,message,version=version,log_file=str(log_path))

def start_qa_target_deploy(version):
    threading.Thread(target=_run_qa_target_deploy,args=(version,),daemon=True).start()

# --- QA retention (independent QA_RELEASE_RETENTION policy) --------------

def _qa_release_cleanup_candidates():
    root=_qa_releases_root()
    if not root.is_dir(): return []
    out=[]
    for d in root.iterdir():
        if not d.is_dir() or d.name.startswith('.'): continue
        marker=d/"release.json"
        try: mtime=marker.stat().st_mtime if marker.is_file() else d.stat().st_mtime
        except OSError: continue
        out.append((mtime,d.name))
    out.sort(reverse=True)
    return [name for _,name in out]

def _qa_release_cleanup_blockers(version,keep_versions):
    """Same named-reason policy as _release_cleanup_blockers(), scoped to
    QA's own current-version/job/promotion state."""
    if version in keep_versions:
        return ["WITHIN_RETENTION_WINDOW"]
    reasons=[]; target=canonical_version(version)
    try:
        if target and canonical_version(qa_current_version())==target:
            reasons.append("CURRENTLY_DEPLOYED")
    except Exception: pass
    state=load_state()
    job=state.get("qa_local_deploy_job") or {}
    if job.get("status") in ("running","DEPLOYING") and canonical_version(str(job.get("version") or ""))==target:
        reasons.append("ACTIVE_DEPLOYMENT_JOB")
    promote_job=state.get("qa_promote_test_job") or {}
    if promote_job.get("status") in ("QUEUED","UPLOADING","DEPLOYING","VERIFYING") and canonical_version(str(promote_job.get("version") or ""))==target:
        reasons.append("BEING_PROMOTED")
    promotion=load_json(QA_PROMOTION_STATE_FILE,{})
    if canonical_version(str(promotion.get("version") or ""))==target and not (promotion.get("local_pass") and promotion.get("test_pass")):
        reasons.append("PROMOTION_IN_PROGRESS")
    return reasons

def _qa_cleanup_old_releases(trigger):
    """QA's own release retention policy (QA_RELEASE_RETENTION, default 3).
    Same invariants as _cleanup_old_releases(): never release.json/
    checksums.txt/PROMOTION.json/image-info.json/BUILD_REPORT.md (the
    immutable-once guard needs them forever); targeted `docker rmi` only,
    never `docker system prune`; independent report/state key
    (qa_release_cleanup_report) so it can never be confused with MESFlow's."""
    now=time.time()
    removed=[]; kept=[]; blocked={}; errors=[]; bytes_freed={"value":0}
    candidates=_qa_release_cleanup_candidates()
    keep_versions=set(candidates[:QA_RELEASE_RETENTION])
    image_repo=os.environ.get("MESFLOW_QA_IMAGE_REPOSITORY","mesflow-qa-center")
    for version in candidates:
        reasons=_qa_release_cleanup_blockers(version,keep_versions)
        if reasons:
            if reasons==["WITHIN_RETENTION_WINDOW"]: kept.append(version)
            else: blocked[version]=reasons
            continue
        root=_qa_release_dir_for(version)
        for pattern in (f"QACenter_{version}.deploy.zip",f"QACenter_{version}.deploy.zip.sha256"):
            f=root/pattern
            if f.is_file():
                try:
                    size=f.stat().st_size; f.unlink()
                    removed.append({"type":"release_zip","version":version,"path":str(f),"bytes":size})
                    bytes_freed["value"]+=size
                except OSError as ex: errors.append(f"{f}: {ex}")
        staging=QA_IMAGE_RELEASES_DIR/version
        if staging.is_dir():
            try:
                size=_dir_size(staging); shutil.rmtree(staging)
                removed.append({"type":"old_staging","version":version,"path":str(staging),"bytes":size})
                bytes_freed["value"]+=size
            except OSError as ex: errors.append(f"{staging}: {ex}")
        image_tag=f"{image_repo}:{version}"
        r=_run_capture(["docker","rmi",image_tag],30)
        if r.get("ok"): removed.append({"type":"docker_image","version":version,"image":image_tag})
        elif "No such image" not in (r.get("stderr") or ""): errors.append(f"docker rmi {image_tag}: {(r.get('stderr') or '').strip()[:200]}")
    report={"application":"qa-center","at":now_text(),"trigger":trigger,"retention":QA_RELEASE_RETENTION,
            "kept":kept,"blocked":blocked,"removed":removed,"bytes_freed":bytes_freed["value"],"errors":errors}
    def f(s): s["qa_release_cleanup_report"]=report
    update_state(f)
    append_log(f"QA release cleanup ({trigger}): removed={len(removed)} kept={len(kept)} blocked={len(blocked)} freed={_bytes(bytes_freed['value'])}"+(f" errors={len(errors)}" if errors else ""))
    return report

# --- QA Promote Production Test (same remote-agent client as MESFlow) ---

def qa_promote_test_update(status,message,**extra):
    def mutate(s):
        j=dict(s.get("qa_promote_test_job") or {})
        if status in ("QUEUED","UPLOADING") and (status=="QUEUED" or j.get("status") not in ("QUEUED","UPLOADING","DEPLOYING","VERIFYING")):
            j={"job_id":f"qa-promote-test-{int(time.time())}","started_at":now_text()}
        if status!="FAILED":
            j.pop("error_code",None)
        j.update(status=status,message=message,updated_at=now_text(),**extra);s["qa_promote_test_job"]=j
    job=update_state(mutate).get("qa_promote_test_job")
    if status in DEPLOYMENT_HISTORY_TERMINAL:
        try:
            _record_deployment_history("QA_CENTER","TEST",version=str((job or {}).get("version") or ""),
                status=status,message=message,started_at=(job or {}).get("started_at",""),finished_at=now_text(),
                deployment_id=f"qa-promote-test-{(job or {}).get('version','')}-{(job or {}).get('updated_at','')}")
        except Exception as ex: append_log(f"Deployment history recording failed (QA promote test): {type(ex).__name__}: {ex}")
    return job

def _run_qa_promote_test(version):
    stage="PRECHECK"
    try:
        artifact=_qa_artifact_for_release(version)
        if not artifact.get("package") or not Path(artifact["package"]).is_file():
            raise _RemoteAgentError("PACKAGE_NOT_FOUND")
        contamination=_qa_release_contamination(version)
        if contamination.get("contaminated"):
            raise _RemoteAgentError(f"RELEASE_CONTAMINATED: {contamination.get('reason')}")
        promotion=_qa_load_promotion_state()
        if promotion.get("version")!=version or not promotion.get("local_pass"):
            raise _RemoteAgentError("LOCAL_PASS_REQUIRED")
        url,user,password=_production_test_target()
        if not url or not password:
            raise _RemoteAgentError("PRODUCTION_TEST_AGENT_NOT_CONFIGURED: set MESFLOW_PRODUCTION_TEST_AGENT_URL/_USER/_PASSWORD")
        zip_path=Path(artifact["package"])
        local_sha=sha(zip_path)
        if artifact.get("package_sha256") and artifact["package_sha256"]!=local_sha:
            raise _RemoteAgentError("PACKAGE_SHA_SELF_CHECK_FAILED")
        stage="AUTHENTICATING"
        auth_error=None
        for attempt in range(1,4):
            try:
                opener,base,csrf=_remote_agent_client(url,user,password,timeout=45)
                auth_error=None
                break
            except (TimeoutError,OSError,urllib.error.URLError) as exc:
                auth_error=exc
                qa_promote_test_update("QUEUED",f"Target authentication transient failure ({attempt}/3): {type(exc).__name__}: {exc}",version=version,stage=stage)
                if attempt<3: time.sleep(attempt*2)
        if auth_error is not None:
            raise auth_error
        stage="READING_TARGET_STATUS"
        target_status=_remote_agent_get_json(opener,base,"/api/status")
        compat=_agent_compatibility(target_status,QA_REQUIRED_PROMOTION_CAPABILITIES)
        if compat["status"]=="INCOMPATIBLE":
            raise _RemoteAgentError(f"TARGET_AGENT_INCOMPATIBLE: {compat['reason']}")
        if target_status.get("server_role") not in ("PRODUCTION_TEST",):
            raise _RemoteAgentError(f"TARGET_AGENT_WRONG_ROLE: expected PRODUCTION_TEST, target reports {target_status.get('server_role')!r}")
        if target_status.get("build_enabled"):
            raise _RemoteAgentError("TARGET_AGENT_BUILD_ENABLED: Production Test must not have source-build capability")
        qa_promote_test_update("UPLOADING",f"Uploading {zip_path.name} (sha256={local_sha[:12]}...) to {url}",version=version)
        stage="UPLOADING"
        def upload_progress(sent,total,chunks):
            percent=int(sent*100/total) if total else 0
            qa_promote_test_update("UPLOADING",
                f"Uploading {zip_path.name}: {percent}% ({sent}/{total} bytes, {chunks} chunks)",
                version=version,stage=stage,progress_percent=percent,uploaded_bytes=sent,total_bytes=total)
        _remote_agent_qa_upload(opener,base,csrf,zip_path,progress=upload_progress)
        qa_promote_test_update("DEPLOYING",f"Deploying QA {version} on target (--no-build)",version=version)
        stage="DEPLOYING"
        _remote_agent_qa_deploy(opener,base,csrf,version)
        stage="VERIFYING"
        deadline=time.time()+180
        last={}
        while time.time()<deadline:
            time.sleep(3)
            try: last=_remote_agent_status(opener,base)
            except Exception as ex: last={"error":str(ex)}; continue
            job=last.get("qa_image_deploy_job") or {}
            if job.get("status")=="success" and canonical_version(str(job.get("version") or ""))==canonical_version(version):
                break
            if job.get("status")=="failed":
                raise _RemoteAgentError(f"REMOTE_DEPLOY_FAILED: {job.get('message')}")
        else:
            raise _RemoteAgentError(f"REMOTE_DEPLOY_TIMEOUT: last status {last}")
        qa=(last or {}).get("qa") or {}
        remote_version=canonical_version(str(qa.get("version") or ""))
        version_ok=remote_version==canonical_version(version)
        healthy_ok=bool(qa.get("online"))
        if not (version_ok and healthy_ok):
            raise _RemoteAgentError(f"REMOTE_VERIFY_FAILED: version_ok={version_ok} healthy_ok={healthy_ok} qa={qa}")
        _qa_update_promotion_state(version,artifact,
            test_status="PASS",test_pass=True,
            test_message=f"TEST_PASS: remote version={remote_version} healthy={healthy_ok}",
            test_target=url)
        qa_promote_test_update("SUCCESS",f"TEST_PASS: QA {version} verified on {url}",version=version)
        try: _qa_cleanup_old_releases("TEST_PASS")
        except Exception as ex: append_log(f"QA release cleanup after TEST_PASS failed: {type(ex).__name__}: {ex}")
    except Exception as exc:
        raw=str(exc) if isinstance(exc,_RemoteAgentError) else f"{type(exc).__name__}: {exc}"
        code=f"{stage}: {raw}"
        try:
            artifact=_qa_artifact_for_release(version)
            _qa_update_promotion_state(version,artifact,test_status="FAILED",test_pass=False,test_message=code)
        except Exception: pass
        qa_promote_test_update("FAILED",code,error_code=code)
    finally:
        if _qa_promote_test_lock.locked(): _qa_promote_test_lock.release()

# QA_PROMOTE_EXPLAINABILITY_V1
_QA_ERROR_HELP = {
    "TESTS_FAILED": (
        "Build/package Agent thất bại ở bước test.",
        "Bấm Xem chi tiết lỗi để xem test nào fail; sửa lỗi đó rồi Build & Pack Agent lại.",
    ),
    "PRODUCTION_TEST_AGENT_NOT_CONFIGURED": ("Chưa cấu hình Agent Production Test.", "Cấu hình MESFLOW_PRODUCTION_TEST_AGENT_URL / _USER / _PASSWORD rồi kiểm tra lại."),
    "LOCAL_PASS_REQUIRED": ("QA Center chưa có LOCAL_PASS cho đúng artifact hiện tại.", "Deploy Local lại và chờ LOCAL_PASS."),
    "PACKAGE_NOT_FOUND": ("Không tìm thấy ZIP artifact QA đã build.", "Build Release lại để tạo artifact."),
    "PACKAGE_SHA_SELF_CHECK_FAILED": ("SHA256 của artifact đã thay đổi sau khi build.", "Không promote artifact này; build lại release mới."),
    "TARGET_AGENT_INCOMPATIBLE": ("Agent Production Test thiếu capability cần cho QA Center.", "Cập nhật Deploy Agent trên máy Production Test rồi kiểm tra lại."),
    "TARGET_AGENT_WRONG_ROLE": ("Agent đích không có SERVER_ROLE=PRODUCTION_TEST.", "Sửa cấu hình role của Agent đích; không promote vào server sai vai trò."),
    "TARGET_AGENT_BUILD_ENABLED": ("Production Test đang bật quyền build source.", "Đặt MESFLOW_BUILD_ENABLED=0 trên Agent Production Test."),
    "REMOTE_LOGIN_FAILED": ("Không đăng nhập được Agent Production Test.", "Kiểm tra URL, username, password và reverse proxy/tunnel."),
    "QA_CHUNK_UPLOAD_FAILED": ("Upload artifact QA lên Production Test bị lỗi.", "Kiểm tra network/proxy, dung lượng đĩa và log upload."),
    "REMOTE_DEPLOY_FAILED": ("Agent Production Test nhận artifact nhưng deploy thất bại.", "Mở log deploy trên Agent đích và xử lý lỗi được hiển thị."),
    "REMOTE_DEPLOY_TIMEOUT": ("Deploy trên Production Test quá thời gian chờ.", "Kiểm tra container/health trên Agent đích rồi retry."),
    "REMOTE_VERIFY_FAILED": ("Deploy xong nhưng version/health trên Production Test không đúng.", "Kiểm tra version thực tế và health QA Center trên máy Test."),
}

def _qa_error_explain(raw):
    raw = str(raw or '').strip()
    code = raw.split(':', 1)[0].strip() if raw else 'UNKNOWN'
    if '413' in raw:
        return {"code":"HTTP_413","reason":"Proxy từ chối artifact vì request quá lớn.","next_action":"Dùng Agent hỗ trợ qa_chunked_release_receive và kiểm tra proxy/tunnel.","detail":raw}
    for key, (reason, next_action) in _QA_ERROR_HELP.items():
        if key in raw:
            return {"code":key,"reason":reason,"next_action":next_action,"detail":raw}
    if 'no session/csrf' in raw.lower() or 'login' in raw.lower():
        return {"code":"REMOTE_LOGIN_FAILED","reason":"Không đăng nhập được Agent Production Test.","next_action":"Kiểm tra URL, username, password và reverse proxy/tunnel.","detail":raw}
    return {"code":code or 'UNKNOWN',"reason":raw or 'Không xác định được nguyên nhân.',"next_action":"Mở chi tiết lỗi/log và chạy lại Kiểm tra điều kiện Promote.","detail":raw}

def _qa_promote_test_preflight():
    summary = _qa_release_summary()
    latest = summary.get('latest') or {}
    promotion = summary.get('promotion') or {}
    checks = []
    def add(key, label, ok, detail='', next_action=''):
        checks.append({"key":key,"label":label,"ok":ok,"detail":str(detail or ''),"next_action":str(next_action or '')})

    version = str(latest.get('version') or '')
    add('release','Có release để promote',bool(version),version or 'Chưa build release','Build Release QA Center.' if not version else '')
    local_ok = bool(promotion.get('local_pass'))
    add('local_pass','LOCAL_PASS cho artifact hiện tại',local_ok,promotion.get('local_message') or '','Deploy Local và chờ LOCAL_PASS.' if not local_ok else '')
    package = Path(str(latest.get('package') or '')) if latest.get('package') else None
    package_ok = bool(package and package.is_file())
    add('artifact','Artifact ZIP tồn tại',package_ok,str(package or ''),'Build Release lại để tạo ZIP.' if not package_ok else '')

    url = (os.environ.get('MESFLOW_PRODUCTION_TEST_AGENT_URL') or '').strip()
    user = (os.environ.get('MESFLOW_PRODUCTION_TEST_AGENT_USER') or 'admin').strip()
    password = (os.environ.get('MESFLOW_PRODUCTION_TEST_AGENT_PASSWORD') or '').strip()
    configured = bool(url and password)
    add('PRODUCTION_TEST_AGENT_NOT_CONFIGURED','Production Test Agent đã cấu hình',configured,url or 'Chưa có URL','Cấu hình MESFLOW_PRODUCTION_TEST_AGENT_URL/_USER/_PASSWORD.' if not configured else '')

    if configured:
        try:
            opener, base, csrf = _remote_agent_client(url, user, password)
            target_status = _remote_agent_get_json(opener, base, '/api/status')
            add('reachable','Kết nối & đăng nhập Agent đích',True,f"{target_status.get('agent_version','?')} @ {url}")
            role_ok = target_status.get('server_role') == 'PRODUCTION_TEST'
            add('role','SERVER_ROLE = PRODUCTION_TEST',role_ok,str(target_status.get('server_role') or '—'),'Sửa SERVER_ROLE trên Agent đích.' if not role_ok else '')
            build_off = not bool(target_status.get('build_enabled'))
            add('build_disabled','Build source trên Test đã tắt',build_off,f"build_enabled={target_status.get('build_enabled')}",'Đặt MESFLOW_BUILD_ENABLED=0 trên Agent Test.' if not build_off else '')
            compat = _agent_compatibility(target_status, QA_REQUIRED_PROMOTION_CAPABILITIES)
            compat_ok = compat.get('status') != 'INCOMPATIBLE'
            add('capabilities','Capability QA tương thích',compat_ok,compat.get('reason') or 'OK','Cập nhật Deploy Agent trên máy Test.' if not compat_ok else '')
        except Exception as ex:
            info = _qa_error_explain(str(ex))
            add('reachable','Kết nối & đăng nhập Agent đích',False,info['reason'],info['next_action'])

    ready = all(x.get('ok') is True for x in checks)
    failed = next((x for x in checks if x.get('ok') is False), None)
    result = {
        "checked_at": now_text(), "ready": ready, "version": version, "checks": checks,
        "blocked_code": None if ready else (failed or {}).get('key','UNKNOWN').upper(),
        "blocked_reason": 'Sẵn sàng Promote to Test.' if ready else (failed or {}).get('detail','Chưa đủ điều kiện.'),
        "next_action": 'Bấm Promote to Test.' if ready else (failed or {}).get('next_action','Kiểm tra chi tiết bên dưới.'),
    }
    def mutate(state): state['qa_promote_test_preflight'] = result
    update_state(mutate)
    return result

def _release_system_issues(state=None):
    """Cheap UI-only issue summary from persisted state; no network/Docker polling."""
    state = state or load_state()
    issues = []
    jobs = [
        ("MESFlow deploy", "job"),
        ("QA Local", "qa_local_deploy_job"),
        ("QA Promote Test", "qa_promote_test_job"),
        ("MESFlow Promote Test", "promote_test_job"),
        ("QA Build", "qa_release_build_job"),
        ("Agent package", "agent_package_build_job"),
        ("Tutorial video", "tutorial_job"),
    ]
    bad = {"FAILED", "failed", "ERROR", "error", "WARNING", "warning"}
    for label, key in jobs:
        j = state.get(key) or {}
        status = str(j.get("status") or "")
        if status not in bad:
            continue
        if key=="tutorial_job" and (not _tutorial_job_is_current(j) or j.get("error_code") in {"TUTORIAL_AUTH_FAILED","TUTORIAL_AUTH_REQUIRED"}):
            continue
        raw = j.get("message") or j.get("error_code") or j.get("error") or "Unknown error"
        info = _qa_error_explain(raw)
        detail_parts = []
        for field, title in (
            ("error", "Error"), ("message", "Message"), ("log_tail", "Log tail"),
            ("output", "Output"), ("stderr", "stderr"), ("stdout", "stdout"),
            ("log_path", "Log file"),
        ):
            val = j.get(field)
            if val:
                text = str(val).strip()
                if text:
                    detail_parts.append(f"{title}:\n{text}")
        detail = "\n\n".join(detail_parts).strip() or str(info.get("detail") or raw)
        if "Tutorial builder exited with code 125" in str(raw):
            info = {
                "code": "TUTORIAL_DOCKER_RUN_FAILED",
                "reason": "Docker không khởi động được Tutorial builder (exit 125).",
                "next_action": "Mở chi tiết lỗi ngay bên dưới để xem lỗi docker run/mount/network/container cụ thể.",
                "detail": detail,
            }
        issues.append({
            "component": label,
            "status": status,
            "code": info["code"],
            "reason": info["reason"],
            "next_action": info["next_action"],
            "detail": detail,
            "log_path": str(j.get("log_path") or ""),
            "at": j.get("updated_at") or j.get("finished_at") or "",
        })
    return issues[:6]

def start_qa_promote_test(version):
    if not _qa_promote_test_lock.acquire(False): raise RuntimeError("PROMOTE_TEST_ALREADY_RUNNING")
    try:
        qa_promote_test_update("QUEUED","Promote QA to Production Test queued",version=version,started_at=now_text())
        threading.Thread(target=_run_qa_promote_test,args=(version,),daemon=True).start()
    except Exception:
        _qa_promote_test_lock.release(); raise

def _new_recovery_code():
    raw=secrets.token_hex(8).upper()
    return "-".join(raw[i:i+4] for i in range(0,16,4))
def _normalize_recovery_code(value):
    return "".join(ch for ch in (value or "").upper() if ch.isalnum())
def ensure_config():
    c=load_json(CONFIG_FILE,{}); changed=False; first_password=None; recovery_code=None
    configured_password=os.environ.get("MESFLOW_AGENT_ADMIN_PASSWORD","")
    if configured_password and len(configured_password)<10:
        raise RuntimeError("MESFLOW_AGENT_ADMIN_PASSWORD must contain at least 10 characters")
    if not c.get("secret_key"):c["secret_key"]=secrets.token_urlsafe(48);changed=True
    # Section 8 (P5): a stable, persisted identity this Agent instance can
    # report to a control plane -- distinct from agent_version (which many
    # different real instances legitimately share) and from hostname
    # (which can change). Generated once, kept forever.
    if not c.get("agent_instance_id"):c["agent_instance_id"]="agent-"+secrets.token_hex(16);changed=True
    if configured_password:
        if not c.get("password_hash") or not check_password_hash(c["password_hash"],configured_password):
            c["password_hash"]=generate_password_hash(configured_password);c["password_changed_at"]=now_text();changed=True
    elif not c.get("password_hash"):
        first_password=secrets.token_urlsafe(12);c["password_hash"]=generate_password_hash(first_password);changed=True
    if not c.get("recovery_code_hash"):
        recovery_code=_new_recovery_code()
        c["recovery_code_hash"]=generate_password_hash(_normalize_recovery_code(recovery_code));changed=True
        c["recovery_code_created_at"]=now_text()
    if changed:save_json(CONFIG_FILE,c)
    if first_password or recovery_code:
        old=(CONFIG_DIR/"FIRST_LOGIN.txt")
        existing=old.read_text(encoding="utf-8",errors="replace") if old.is_file() else ""
        if first_password is None:
            for line in existing.splitlines():
                if line.startswith("Password: "):first_password=line.split(": ",1)[1].strip()
        text=(f"Workshop Update Agent\nURL: http://SERVER-IP:{PORT}{URL_PREFIX or '/'}\nUsername: admin\n"
              f"Password: {first_password or '[existing password unchanged]'}\n"
              f"Recovery Code: {recovery_code or '[already created - use local reset or installer if lost]'}\n"
              "Store this file securely and delete it after recording the credentials.\n")
        old.write_text(text,encoding="utf-8")
    return c
app.secret_key=ensure_config()["secret_key"]

def _agent_instance_id():
    # ensure_config() already ran once at module load (line above) so the
    # field is guaranteed present by the time any request arrives -- a
    # lightweight read here, not the full ensure_config() (which also does
    # password/recovery-code file I/O), avoids adding that cost/any
    # concurrent-write race to a route that may be polled frequently.
    return load_json(CONFIG_FILE,{}).get("agent_instance_id","")
def load_state():return load_json(STATE_FILE,{"job":None,"history":[],"tutorial_job":None,"tutorial_history":[],"esp_tutorial_job":None,"esp_tutorial_history":[],"esp_builder_job":None})
def update_state(fn):
    with _state_lock:
        s=load_state();fn(s);save_json(STATE_FILE,s);return s
def logged_in():return bool(session.get("authenticated"))
@app.before_request
def protect():
    if request.endpoint in {"login","forgot_password","local_reset","static","live","health","ota_console","kiosk_ota_page","ota_firmware_list","ota_devices","ota_upload_and_flash","ota_job_status","ota_jobs","ota_cancel_job","ota_device_check","ota_device_download","ota_device_event","api_ops_summary","api_ops_docker","api_ops_logs","api_incidents","api_incident_detail","api_ops_predictions","api_ops_metric_trend","api_incident_ai_analysis","api_incident_notifications","api_notification_channels",
        "api_ops_db_summary","api_ops_db_backups","api_ops_db_backup_detail","api_ops_restore_drills","api_ops_storage","api_ops_storage_retention_preview","api_ops_db_audit",
        "api_servers_list","api_server_detail","api_server_health","api_server_storage","api_server_backups","api_server_incidents","api_fleet_summary","api_releases",
        "api_recovery_services","api_recovery_service_detail","api_recovery_service_logs","api_recovery_service_ports","api_recovery_preflight","api_recovery_system_check","api_recovery_diagnose","api_recovery_audit"}:return None
    if not logged_in():return redirect(url_for("login",next=f"{request.script_root}{request.path}"))
def verify_csrf():
    supplied=request.form.get("csrf","") or request.headers.get("X-CSRF-Token","")
    if request.is_json and not supplied:
        supplied=(request.get_json(silent=True) or {}).get("csrf","")
    if not hmac.compare_digest(str(supplied),str(session.get("csrf",""))):abort(403)
def safe_extract_zip(z,d):
    d=d.resolve()
    with zipfile.ZipFile(z) as a:
        if not a.infolist(): raise ValueError("ZIP is empty")
        total_uncompressed=sum(max(0,m.file_size) for m in a.infolist())
        if total_uncompressed>MAX_EXTRACT_MB*1024*1024:
            raise ValueError(f"ZIP expands beyond the {MAX_EXTRACT_MB} MB extraction limit")
        for m in a.infolist():
            if m.is_dir(): continue
            # A release package must contain ordinary files only.  Reject
            # symlink/special-file entries before extraction: they are not a
            # portable MESFlow package and can escape the intended tree on
            # platforms that restore link metadata.
            mode=(m.external_attr >> 16) & 0o170000
            if mode and mode not in (0o100000,):
                raise ValueError("ZIP contains a symlink or unsupported special file")
            target=(d/m.filename.replace("\\","/")).resolve()
            if d not in target.parents and target!=d:raise ValueError("ZIP contains unsafe path")
        a.extractall(d)
def locate_root(e):
    # Legacy pre-Docker "install/deploy_release.py" shape removed alongside
    # the legacy source-ZIP upload UI/routes -- every current caller (Deploy
    # Local, /upload's machine-to-machine artifact transfer) always deals in
    # the image-release contract (compose.yml + release.json) exclusively.
    c=[]
    if (e/"VERSION.txt").is_file():c.append(e)
    c += [x for x in e.iterdir() if x.is_dir() and (x/"VERSION.txt").is_file()]
    if len(c)!=1:raise ValueError("ZIP must contain exactly one release root")
    r=c[0]
    if not ((r/"compose.yml").is_file() and (r/"release.json").is_file()):
        raise ValueError("Release must contain compose.yml + release.json (Linux Docker image release)")
    return r
def validate_image_release_contract(root):
    root=Path(root)
    required=("VERSION.txt","release.json","compose.yml","checksums.txt","PROMOTION.json")
    missing=[x for x in required if not (root/x).is_file()]
    if missing: raise ValueError("Image release missing: "+", ".join(missing))
    meta=json.loads((root/"release.json").read_text(encoding="utf-8-sig"))
    version=norm((root/"VERSION.txt").read_text(encoding="utf-8-sig"))
    if meta.get("type") != IMAGE_RELEASE_TYPE: raise ValueError("release.json type must be mesflow-image-release")
    if canonical_version(str(meta.get("version",""))) != canonical_version(version): raise ValueError("Image release version mismatch")
    image=str(meta.get("image") or "").strip(); digest=str(meta.get("image_digest") or "").strip()
    if not image or not re.fullmatch(r"sha256:[0-9a-f]{64}",digest): raise ValueError("Image release requires image and image_digest")
    promotion=json.loads((root/"PROMOTION.json").read_text(encoding="utf-8-sig"))
    if promotion.get("version") and canonical_version(str(promotion["version"])) != canonical_version(version): raise ValueError("PROMOTION version mismatch")
    return version,meta

QA_IMAGE_RELEASE_TYPE="qa-center-image-release"
def locate_qa_image_release_root(e):
    """Same shape rule as locate_root(), for a QA Center image-release ZIP
    (built by qa-center/scripts/build-release.sh) -- exactly one root
    carrying VERSION + compose.yml + release.json."""
    c=[]
    if (e/"VERSION").is_file(): c.append(e)
    c += [x for x in e.iterdir() if x.is_dir() and (x/"VERSION").is_file()]
    if len(c)!=1: raise ValueError("QA release ZIP must contain exactly one root with VERSION")
    r=c[0]
    if not ((r/"compose.yml").is_file() and (r/"release.json").is_file()):
        raise ValueError("QA image release must contain compose.yml + release.json")
    return r
def validate_qa_image_release_contract(root):
    root=Path(root)
    required=("VERSION","release.json","compose.yml","checksums.txt","PROMOTION.json")
    missing=[x for x in required if not (root/x).is_file()]
    if missing: raise ValueError("QA image release missing: "+", ".join(missing))
    meta=json.loads((root/"release.json").read_text(encoding="utf-8-sig"))
    version=norm((root/"VERSION").read_text(encoding="utf-8-sig"))
    if meta.get("type") != QA_IMAGE_RELEASE_TYPE: raise ValueError("release.json type must be qa-center-image-release")
    if canonical_version(str(meta.get("version",""))) != canonical_version(version): raise ValueError("QA image release version mismatch")
    image=str(meta.get("image") or "").strip(); digest=str(meta.get("image_digest") or "").strip()
    if not image or not re.fullmatch(r"sha256:[0-9a-f]{64}",digest): raise ValueError("QA image release requires image and image_digest")
    promotion=json.loads((root/"PROMOTION.json").read_text(encoding="utf-8-sig"))
    if promotion.get("version") and canonical_version(str(promotion["version"])) != canonical_version(version): raise ValueError("QA PROMOTION version mismatch")
    return version,meta
def norm(v):
    v=v.strip()
    if not v or len(v)>64 or any(ch not in set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-") for ch in v):raise ValueError("Invalid version")
    return v
def canonical_version(v):
    # Compare deploy/runtime versions without harmless formatting differences.
    # Keep every numeric component: 65.8.44.7 must NOT equal 65.8.44.
    return str(v or "").strip().lstrip("Vv").strip()
def _hash_file_sha256(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
_SHA_CACHE_LOCK=threading.Lock(); _SHA_CACHE={}  # str(path) -> (mtime_ns, size, hexdigest)
def sha(p):
    # Release Tab Performance Fix follow-up (reports/DEPLOY_AGENT_REFRESH_PERFORMANCE_FIX.md):
    # release artifacts here are real 70-500+MB ZIPs (MESFlow/QA Center
    # deploy packages). _release_summary()/_qa_release_summary() call this
    # on EVERY page load of the Release & Deploy tab purely to display the
    # already-built artifact's digest -- re-hashing hundreds of MB just to
    # show the same unchanged value was the single most expensive thing
    # that page did. Cached by (mtime_ns, size): any real change to the
    # file (a fresh build overwrites it) gives it a different mtime/size,
    # which invalidates the cache automatically -- a changed file is
    # always re-hashed. This never returns a digest that doesn't match
    # the file's current bytes, so authoritative deploy-time verification
    # elsewhere (which compares against a freshly-read local hash) is not
    # weakened by this cache either.
    p=Path(p)
    try: st=p.stat()
    except OSError: return _hash_file_sha256(p)
    key=str(p)
    with _SHA_CACHE_LOCK:
        cached=_SHA_CACHE.get(key)
        if cached and cached[0]==st.st_mtime_ns and cached[1]==st.st_size: return cached[2]
    digest=_hash_file_sha256(p)
    with _SHA_CACHE_LOCK: _SHA_CACHE[key]=(st.st_mtime_ns,st.st_size,digest)
    return digest
def tail(p,n=200):
    try:return "\n".join(Path(p).read_text(encoding="utf-8",errors="replace").splitlines()[-n:])
    except OSError:return ""
def current_file_version():
    for p in (TARGET_HOME/"VERSION.txt", TARGET_HOME/"app/current/VERSION.txt"):
        if p.is_file():
            return p.read_text(encoding="utf-8-sig").strip()
    return "Chưa cài"
def _mes_url_candidates():
    values=[]
    for base in [MES_URL, "http://127.0.0.1", "https://127.0.0.1", "http://localhost", "https://localhost"]:
        base=(base or "").rstrip("/")
        if base and base not in values: values.append(base)
    return values

def _http_json_base(base,path,timeout=4):
    try:
        ctx=ssl._create_unverified_context() if base.lower().startswith("https://") else None
        req=urllib.request.Request(base+path,headers={"Host":"localhost","User-Agent":"MESFlow-Deploy-Agent"})
        with urllib.request.urlopen(req,timeout=timeout,context=ctx) as r:
            raw=r.read().decode("utf-8",errors="replace")
            try: payload=json.loads(raw)
            except json.JSONDecodeError: payload={"ok":False,"error":"Invalid JSON response","body":raw[:2000]}
            payload.setdefault("_agent_base_url",base)
            return payload,r.status
    except urllib.error.HTTPError as e:
        raw=e.read().decode("utf-8",errors="replace")
        try: payload=json.loads(raw)
        except json.JSONDecodeError: payload={"ok":False,"error":str(e),"body":raw[:2000]}
        payload.setdefault("http_status",e.code);payload.setdefault("_agent_base_url",base)
        return payload,e.code
    except Exception as e:
        return {"ok":False,"error":str(e),"_agent_base_url":base},0

# Real bug found+fixed live (reports/RELEASE_PAGE_PERFORMANCE_AUDIT.md): when
# this Agent's container is not on the same Docker network as the MESFlow
# container, resolving MES_URL's hostname (e.g. `mesflow-app`) fails with
# glibc's resolver EAI_AGAIN -- which takes ~5s per attempt and, critically,
# is NOT bounded by urlopen's `timeout=` parameter (that only covers the
# socket connect/read stage, which never starts if DNS resolution itself
# hangs). mes_status() alone makes 3 independent http_json() calls per
# Release page load (version/health/ready), each re-walking the candidate
# list from scratch -- measured 15.2s for mes_status() alone, ~99% of the
# Release page's entire load time, on every single page load. A given base
# URL's reachability does not change from one call to the next within a few
# seconds, so remembering a fresh connection-level failure (HTTP status
# code 0 -- DNS/connect/timeout, as opposed to a real HTTP error response)
# for a short window is safe and turns 3 full 5s DNS stalls per page load
# into at most one.
_MES_BASE_UNREACHABLE_LOCK=threading.Lock()
_MES_BASE_UNREACHABLE={}  # base_url -> monotonic() timestamp of last connection-level failure
_MES_BASE_UNREACHABLE_TTL=45

def _mes_base_recently_unreachable(base):
    with _MES_BASE_UNREACHABLE_LOCK:
        ts=_MES_BASE_UNREACHABLE.get(base)
    return ts is not None and (time.monotonic()-ts)<_MES_BASE_UNREACHABLE_TTL

def _mark_mes_base_reachability(base,code):
    with _MES_BASE_UNREACHABLE_LOCK:
        if code: _MES_BASE_UNREACHABLE.pop(base,None)  # any real HTTP response (even an error status) proves the network path works
        else: _MES_BASE_UNREACHABLE[base]=time.monotonic()

def http_json(path,timeout=4):
    last=({"ok":False,"error":"No MES URL candidates"},0)
    first_http_error=None
    for base in _mes_url_candidates():
        if _mes_base_recently_unreachable(base):
            last=({"ok":False,"error":"UNREACHABLE_CACHED","_agent_base_url":base},0)
            continue
        payload,code=_http_json_base(base,path,timeout)
        _mark_mes_base_reachability(base,code)
        last=(payload,code)
        if code==200:
            return payload,code
        if code and first_http_error is None:
            first_http_error=(payload,code)
    return first_http_error or last

def _docker_mes_state():
    if os.name=="nt" or not (TARGET_HOME/"compose.yml").is_file():
        return {"available":False,"running":False,"healthy":False,"health":"unknown","services":[]}
    try:
        base=["docker","compose","-f",str(TARGET_HOME/"compose.yml")]
        env=os.environ.copy(); meta=load_json(TARGET_HOME/"release.json",{}); ref=meta.get("image_ref") or (f"{meta.get('image')}@{meta.get('image_digest')}" if meta.get("image") and meta.get("image_digest") else "")
        if ref: env["MESFLOW_IMAGE"]=ref
        r=subprocess.run([*base,"ps","--status","running","--services"],cwd=str(TARGET_HOME),env=env,capture_output=True,text=True,errors="replace",timeout=12)
        services=[x.strip() for x in r.stdout.splitlines() if x.strip()]
        # The production gateway is an independent Compose project.  Application
        # health is intentionally limited to services owned by this stack.
        required=("postgres","mesflow"); service_health={}; ids={}
        for service in required:
            if service not in services: service_health[service]="stopped"; continue
            q=subprocess.run([*base,"ps","-q",service],cwd=str(TARGET_HOME),env=env,capture_output=True,text=True,errors="replace",timeout=12)
            cid=q.stdout.strip().splitlines()[0] if q.returncode==0 and q.stdout.strip() else "";ids[service]=cid
            health="unknown"
            if cid:
                ins=subprocess.run(["docker","inspect","--format","{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}",cid],capture_output=True,text=True,errors="replace",timeout=12)
                if ins.returncode==0 and ins.stdout.strip(): health=ins.stdout.strip()
            service_health[service]=health
        running=r.returncode==0 and all(x in services for x in required)
        healthy=running and all(service_health.get(x) in ("healthy","none") for x in required)
        health="healthy" if healthy else "unhealthy" if running else "stopped"
        return {"available":r.returncode==0,"running":running,"healthy":healthy,"health":health,"services":services,"service_health":service_health,"container_id":ids.get("mesflow","")+"","container_ids":ids,"stderr":r.stderr.strip()}
    except Exception as e:
        return {"available":False,"running":False,"healthy":False,"health":"unknown","services":[],"error":str(e)}

def _classify_health(payload, http_status):
    checks = payload.get("checks") if isinstance(payload.get("checks"), dict) else {}
    db_check = checks.get("database") if isinstance(checks.get("database"), dict) else {}
    disk_check = checks.get("disk") if isinstance(checks.get("disk"), dict) else {}
    critical_errors = payload.get("critical_errors") or []
    disk_warning = bool(disk_check) and (
        disk_check.get("warning") is True
        or disk_check.get("capacity_ok") is False
        or disk_check.get("ok") is False
    )
    critical_ok = bool(payload.get("critical_ok", payload.get("ok", False)))
    legacy_disk_only_warning = bool(db_check.get("ok")) and not critical_errors and disk_warning
    if (http_status == 200 and critical_ok) or legacy_disk_only_warning:
        return "warning" if disk_warning or payload.get("status") == "warning" else "healthy"
    return "failed"

def mes_status():
    docker_state=_docker_mes_state()
    # Live-verified follow-up (reports/DEPLOY_AGENT_REFRESH_PERFORMANCE_FIX.md):
    # on a host where mesflow-app is genuinely stopped, these 3 http_json()
    # calls each cascade through up to 5 URL candidates (MES_URL, both
    # 127.0.0.1 schemes, both localhost schemes) before giving up -- measured
    # 15s total for this one function alone. When docker_state already
    # confirms (available=True, i.e. `docker compose ps` itself succeeded)
    # that the required services are NOT running, no HTTP candidate could
    # possibly succeed either -- skipping the probe changes nothing about
    # the correct answer, only how long it takes to reach it. When Docker
    # state is unavailable/ambiguous (Windows runtime, no compose.yml, a
    # bare-process install) this still falls through to the full probe
    # exactly as before -- that's the only path able to detect a
    # non-Docker MESFlow at all.
    docker_confirmed_not_running=docker_state.get("available") and not docker_state.get("running")
    if docker_confirmed_not_running:
        offline=({"ok":False,"error":"MESFLOW_CONTAINER_NOT_RUNNING"},0)
        v,vs=offline;h,hs=offline;ready,readys=offline
    else:
        v,vs=http_json("/api/system/version");h,hs=http_json("/api/system/health")
        # /api/system/ready exposes the real applied Alembic head (migration_head).
        # Deliberately not health_payload's schema_version, an app-defined label
        # that looks like a version string -- see AGENTS.md: never infer schema
        # from the app version. Read-only, best-effort: absence must never make
        # mes_status() itself fail.
        ready,readys=http_json("/api/system/ready")
    migration_head=str(ready.get("migration_head") or "") if readys==200 else ""
    health_state=_classify_health(h,hs)
    api_online=(vs==200)
    online=api_online or bool(docker_state.get("running"))
    if online and health_state=="failed" and docker_state.get("running"):
        # Nginx/backend may intentionally not expose 8080 to the host. Do not call the server OFFLINE.
        health_state="running" if hs==0 else "warning"
    return {"online":online,"healthy":health_state in ("healthy","warning","running"),"health_state":health_state,"version":v.get("version") or current_file_version(),"deployment_id":v.get("deployment_id",""),"version_payload":v,"health_payload":h,"migration_head":migration_head,"docker":docker_state,"api_online":api_online}
def list_releases():
    out=[]
    for x in RELEASES_DIR.iterdir():
        if x.is_dir() and not x.name.startswith('.'):
            m=load_json(x/"agent_manifest.json",{});meta=load_json(x/"release.json",{});promotion=load_json(x/"PROMOTION.json",{})
            local_status=str(promotion.get("local_verification") or promotion.get("local_status") or "NOT VERIFIED").upper()
            out.append({"version":x.name,"uploaded_at":m.get("uploaded_at",""),"source_name":m.get("source_name",""),"channel":meta.get("channel","stable"),"protocol":meta.get("deployment_protocol",1),
                        "sha256":m.get("sha256",""),"source_commit":promotion.get("source_commit","NOT VERIFIED"),"local_verification":local_status})
    return sorted(out,key=lambda z:z["uploaded_at"],reverse=True)
def _mark_stale_job_interrupted(reason="Agent restarted or deployment worker is no longer active"):
    changed={"value":False}
    def f(s):
        j=s.get("job") or {}
        if j.get("status")=="running":
            j=dict(j)
            j.update(status="interrupted",finished_at=now_text(),message=reason,return_code=-2)
            for step in (j.get("steps") or {}).values():
                if step.get("status")=="running":
                    step["status"]="interrupted"
                    step["message"]=(step.get("message") or "")+" (interrupted)"
                    step["at"]=now_text()
            s["job"]=j
            history=s.setdefault("history",[])
            if not history or history[0].get("deployment_id")!=j.get("deployment_id"):
                history.insert(0,dict(j))
                s["history"]=history[:50]
            changed["value"]=True
    update_state(f)
    if changed["value"]:append_log(f"Recovered stale deployment state: {reason}")
    return changed["value"]

def job_running():
    state_running=(load_state().get("job") or {}).get("status") in MES_JOB_ACTIVE_STATES
    worker_running=_job_lock.locked()
    if state_running and not worker_running:
        _mark_stale_job_interrupted()
        return False
    return worker_running
def set_job_phase(status,message=""):
    if status not in MES_JOB_ACTIVE_STATES|{"success","failed"}: raise ValueError(f"Unknown MES job state: {status}")
    def f(s):
        j=s.get("job") or {}
        transitions=j.setdefault("transitions",[])
        if not transitions or transitions[-1].get("status")!=status:
            transitions.append({"status":status,"at":now_text(),"message":message})
        j.update(status=status,message=message or status,phase=status)
        s["job"]=j
    update_state(f)
def set_step(name,status,message=""):
    def f(s):
        j=s.get("job") or {};steps=j.setdefault("steps",{});steps[name]={"status":status,"message":message,"at":now_text()};j["message"]=message or name;s["job"]=j
    update_state(f)
def port_pids(port=8080):
    pids=set()
    if os.name != "nt":
        return pids
    try:
        result=subprocess.run(["netstat","-ano","-p","tcp"],capture_output=True,text=True,errors="replace",timeout=10)
        for line in result.stdout.splitlines():
            cols=line.split()
            if len(cols)>=5 and cols[0].upper()=="TCP" and cols[1].rsplit(":",1)[-1]==str(port) and cols[3].upper()=="LISTENING":
                if cols[-1].isdigit():pids.add(int(cols[-1]))
    except Exception:
        pass
    return pids

def port_open(host="127.0.0.1",port=8080,timeout=0.5):
    try:
        with socket.create_connection((host,port),timeout=timeout):return True
    except OSError:return False

def _windows_process_info(pid):
    if os.name != "nt":
        return {"pid": int(pid)}
    script = (
        "$p=Get-CimInstance Win32_Process -Filter \"ProcessId=%d\" -ErrorAction SilentlyContinue; "
        "if($p){$o=[ordered]@{ProcessId=$p.ProcessId;ParentProcessId=$p.ParentProcessId;"
        "Name=$p.Name;ExecutablePath=$p.ExecutablePath;CommandLine=$p.CommandLine};"
        "$owner=Invoke-CimMethod -InputObject $p -MethodName GetOwner -ErrorAction SilentlyContinue;"
        "if($owner -and $owner.ReturnValue -eq 0){$o.Owner=($owner.Domain+'\\'+$owner.User)};"
        "$o|ConvertTo-Json -Compress}"
    ) % int(pid)
    try:
        r=subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-Command",script],capture_output=True,text=True,errors="replace",timeout=15,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        if r.stdout.strip():
            return json.loads(r.stdout.strip())
        return {"pid":int(pid),"missing":True,"stderr":r.stderr.strip()}
    except Exception as e:
        return {"pid":int(pid),"info_error":str(e)}

def _terminate_windows_pid(pid, log):
    pid=int(pid)
    info=_windows_process_info(pid)
    log.write(f"[STOP] Target process: {json.dumps(info,ensure_ascii=False)}\n");log.flush()
    attempts=[]
    commands=[
        ["taskkill","/PID",str(pid),"/T","/F"],
        ["powershell","-NoProfile","-ExecutionPolicy","Bypass","-Command",f"Stop-Process -Id {pid} -Force -ErrorAction Stop"],
        ["powershell","-NoProfile","-ExecutionPolicy","Bypass","-Command",f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' -ErrorAction SilentlyContinue;if($p){{Invoke-CimMethod -InputObject $p -MethodName Terminate | ConvertTo-Json -Compress}}"],
    ]
    for cmd in commands:
        try:
            r=subprocess.run(cmd,capture_output=True,text=True,errors="replace",timeout=20,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            attempts.append({"cmd":cmd[0],"returncode":r.returncode,"stdout":r.stdout.strip(),"stderr":r.stderr.strip()})
        except Exception as e:
            attempts.append({"cmd":cmd[0],"error":str(e)})
        time.sleep(0.7)
        if pid not in port_pids(8080) and not process_alive(pid):break
    log.write(f"[STOP] Termination attempts: {json.dumps(attempts,ensure_ascii=False)}\n");log.flush()
    return attempts

def _docker_compose(log, args, check=True, timeout=600, env_extra=None):
    compose=TARGET_HOME/"compose.yml"
    if not compose.is_file():
        raise RuntimeError(f"Missing {compose}")
    cmd=["docker","compose","-f",str(compose),*args]
    log.write("RUN: "+" ".join(cmd)+"\n"); log.flush()
    env=os.environ.copy(); meta=load_json(TARGET_HOME/"release.json",{}); ref=meta.get("image_ref") or (f"{meta.get('image')}@{meta.get('image_digest')}" if meta.get("image") and meta.get("image_digest") else "")
    if ref: env["MESFLOW_IMAGE"]=ref
    env.update(env_extra or {})
    r=subprocess.run(cmd,cwd=str(TARGET_HOME),env=env,stdout=log,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    if check and r.returncode:
        raise RuntimeError(f"docker compose {' '.join(args)} failed with code {r.returncode}")
    return r.returncode

def _compose_at(root, log, args, check=True, timeout=600, env_extra=None):
    root=Path(root); compose=root/"compose.yml"
    if not compose.is_file(): raise RuntimeError(f"Missing {compose}")
    env_file=TARGET_HOME/".env"
    if not env_file.is_file() or not os.access(env_file,os.R_OK):
        try:
            stat=env_file.stat()
            detail=f"mode={stat.st_mode & 0o777:04o} uid={stat.st_uid} gid={stat.st_gid}"
        except OSError as ex:
            detail=f"stat failed: {type(ex).__name__}: {ex}"
        raise RuntimeError(f"Agent cannot read persistent environment file: {env_file} ({detail}). Check the bind mount and Agent UID/GID; do not copy or chmod the file broadly.")
    cmd=["docker","compose","--env-file",str(env_file),"-f",str(compose),*args]
    log.write("RUN: "+" ".join(cmd)+"\n"); log.flush()
    env=os.environ.copy(); env.update(env_extra or {})
    r=subprocess.run(cmd,cwd=str(root),env=env,stdout=log,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    if check and r.returncode: raise RuntimeError(f"docker compose {' '.join(args)} failed with code {r.returncode}")
    return r.returncode

def _verify_and_prepare_image_release(release, meta, log):
    image=str(meta["image"]); expected=str(meta["image_digest"])
    distribution=str(meta.get("distribution") or "registry")
    if distribution == "bundle":
        bundle=Path(release)/str(meta.get("bundle") or "")
        if not bundle.is_file(): raise RuntimeError("IMAGE_BUNDLE_MISSING")
        log.write(f"Loading image bundle {bundle.name}\n");log.flush()
        r=subprocess.run(["docker","load","-i",str(bundle)],stdout=log,stderr=subprocess.STDOUT,text=True,timeout=BUILD_TIMEOUT)
        if r.returncode: raise RuntimeError("IMAGE_LOAD_FAILED")
    else:
        r=subprocess.run(["docker","pull",f"{image}@{expected}"],stdout=log,stderr=subprocess.STDOUT,text=True,timeout=BUILD_TIMEOUT)
        if r.returncode: raise RuntimeError("IMAGE_PULL_FAILED")
    ref=image if distribution == "bundle" else f"{image}@{expected}"
    fmt="{{.Id}}" if distribution == "bundle" else "{{index .RepoDigests 0}}"
    inspect=subprocess.run(["docker","image","inspect",ref,"--format",fmt],capture_output=True,text=True,timeout=30)
    actual=inspect.stdout.strip()
    if distribution == "bundle":
        expected_id=str(meta.get("image_id") or "")
        if inspect.returncode or not expected_id or actual != expected_id: raise RuntimeError(f"IMAGE_ID_MISMATCH expected={expected_id} actual={actual}")
    elif inspect.returncode or expected not in actual:
        raise RuntimeError(f"IMAGE_DIGEST_MISMATCH expected={expected} actual={actual}")
    return ref

def stop_mes(log, timeout=120):
    set_step("restart","running","Stopping MES Docker stack")
    if os.name=="nt":
        deadline=time.time()+timeout
        while time.time()<deadline:
            for pid in sorted(port_pids(8080)):_terminate_windows_pid(pid,log)
            time.sleep(1)
            if not port_open(): return
        raise RuntimeError("MES did not stop on Windows")
    if (TARGET_HOME/"compose.yml").is_file():
        # Never destroy the Compose stack/network or stop PostgreSQL for an app cutover.
        _docker_compose(log,["stop","mesflow"],check=False,timeout=timeout)
    deadline=time.time()+timeout
    while time.time()<deadline:
        if not port_open(): return
        time.sleep(1)
    raise RuntimeError("MES did not stop; port 8080 is still open")

def process_alive(pid):
    if not pid:return False
    if os.name=="nt":
        r=subprocess.run(["tasklist","/FI",f"PID eq {pid}","/FO","CSV","/NH"],capture_output=True,text=True,errors="replace",creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        return str(pid) in r.stdout and "No tasks" not in r.stdout
    try:os.kill(int(pid),0);return True
    except OSError:return False

def start_mes(log):
    if os.name!="nt" and (TARGET_HOME/"compose.yml").is_file():
        _docker_compose(log,["up","-d","--no-build","--no-deps","mesflow"],check=True,timeout=300)
        log.write("MES application started from an existing image; PostgreSQL unchanged\n");log.flush()
        return None
    python_exe=TARGET_HOME/".venv/Scripts/python.exe"
    current=TARGET_HOME/"app/current"
    launcher=current/"launcher.py"
    entry=launcher if launcher.is_file() else current/"start_server.py"
    if not python_exe.is_file():raise RuntimeError(f"Missing MES Python: {python_exe}")
    if not entry.is_file():raise RuntimeError(f"Missing MES entry point: {entry}")
    env=os.environ.copy();env.update({"WORKSHOP_HOME":str(TARGET_HOME),"WORKSHOP_DATA_DIR":str(TARGET_HOME/"data"),"WORKSHOP_CONFIG_DIR":str(TARGET_HOME/"config"),"PYTHONUTF8":"1"})
    flags=getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0)|getattr(subprocess,"DETACHED_PROCESS",0)|getattr(subprocess,"CREATE_NO_WINDOW",0)
    mes_log=LOG_DIR/"mes_process.log"
    handle=mes_log.open("a",encoding="utf-8")
    proc=subprocess.Popen([str(python_exe),str(entry)],cwd=str(current),env=env,stdout=handle,stderr=subprocess.STDOUT,creationflags=flags,close_fds=True)
    save_json(DATA_DIR/"mes_process.json",{"pid":proc.pid,"started_at":now_text(),"entry":str(entry),"log":str(mes_log)})
    log.write(f"Started MES PID {proc.pid} using {entry}; verify timeout={MES_VERIFY_TIMEOUT}s\n");log.flush()
    return proc.pid

def wait_verify(version,deployment_id,timeout=None,require_health=True,pid=None):
    timeout=timeout or MES_VERIFY_TIMEOUT
    end=time.time()+timeout;last={};wrong_version_count=0
    mes_log=LOG_DIR/"mes_process.log"
    while time.time()<end:
        time.sleep(1.5)
        if pid and not process_alive(pid) and not port_open():
            detail=tail(mes_log,80)
            raise RuntimeError(f"MES process exited before opening port 8080. MES log:\n{detail or '[empty mes_process.log]'}")
        v,code=http_json("/api/system/version",3);last=v
        if code==200:
            actual=str(v.get("version","")).lstrip("Vv")
            expected=version.lstrip("Vv")
            if actual and actual!=expected:
                wrong_version_count += 1
                if wrong_version_count>=4:
                    raise RuntimeError(f"Wrong MES process is running: expected {version}, got {actual}. Last response: {v}")
                continue
            if actual==expected and v.get("deployment_id","")==deployment_id:
                if not require_health:
                    return v, {"ok": True, "verification": "version_and_deployment_id"}
                h,hc=http_json("/api/system/health",3)
                health_ok=bool(h.get("critical_ok",h.get("ok",h.get("status") in ("healthy","warning","UP"))))
                checks=h.get("checks") if isinstance(h.get("checks"),dict) else {}
                db_check=checks.get("database") if isinstance(checks.get("database"),dict) else {}
                disk_check=checks.get("disk") if isinstance(checks.get("disk"),dict) else {}
                critical_errors=h.get("critical_errors") or []
                # Compatibility guard: releases 62.6.44/45 returned HTTP 503 solely
                # because disk usage crossed the warning threshold. A healthy DB,
                # matching version and matching deployment id are sufficient; disk
                # pressure remains a visible warning and must never trigger rollback.
                disk_only_warning=(
                    bool(db_check.get("ok"))
                    and not critical_errors
                    and bool(disk_check)
                    and not bool(disk_check.get("ok",True))
                )
                if (hc==200 and health_ok) or disk_only_warning:
                    if disk_only_warning:
                        h=dict(h);h["agent_override"]="disk_warning_noncritical";h["ok"]=True
                    return v,h
                last={"version":v,"health":h,"health_http_status":hc}
                if hc==503 and critical_errors:
                    raise RuntimeError(f"MES critical health failure: {critical_errors}. Full response: {h}")
        elif port_open() and time.time()>end-20:
            # A process owns the port but cannot serve the system API; do not wait the full timeout.
            last={**last,"port_8080":True}
    detail=tail(mes_log,80)
    raise RuntimeError(f"MES verification timeout after {timeout}s. Last response: {last}. MES log tail:\n{detail or '[empty mes_process.log]'}")

def rollback(log,failed_version):
    set_step("rollback","running","Automatic rollback")
    current=TARGET_HOME/"app/current";old=TARGET_HOME/"app/current.old";failed=TARGET_HOME/"app"/f"failed_{failed_version}_{datetime.now():%Y%m%d_%H%M%S}"
    stop_mes(log)
    if not old.is_dir():raise RuntimeError("Rollback unavailable: current.old not found")
    if current.exists():current.replace(failed)
    old.replace(current)
    previous=(current/"VERSION.txt").read_text(encoding="utf-8-sig").strip()
    marker=TARGET_HOME/"config/deployment.json";rid="rollback-"+uuid.uuid4().hex
    save_json(marker,{"deployment_id":rid,"version":previous,"channel":"rollback","deployed_at":datetime.now().astimezone().isoformat(timespec="seconds")})
    pid=start_mes(log)
    try:
        wait_verify(previous,rid,60,require_health=False,pid=pid)
    except Exception:
        # Legacy releases before protocol v2 do not expose /api/system/version.
        # Confirm that the old process is alive and VERSION.txt matches instead.
        end=time.time()+45
        while time.time()<end:
            time.sleep(2)
            _, code=http_json("/api/health",5)
            if code==200 and current_file_version().lstrip("Vv")==previous.lstrip("Vv"):
                break
        else:
            raise
    set_step("rollback","success",f"Rolled back to {previous}");return previous
PERSISTENT_MES_NAMES={".env","certs","runtime"}
FIRST_INSTALL_BACKUP_MARKER=".mesflow_first_install_baseline"

def _validate_persistent_paths():
    TARGET_HOME.mkdir(parents=True,exist_ok=True)
    runtime=TARGET_HOME/"runtime"
    runtime.mkdir(parents=True,exist_ok=True)
    if runtime.is_symlink() or not runtime.is_dir(): raise RuntimeError(f"Unsafe persistent runtime path: {runtime}")
    env=TARGET_HOME/".env"
    if not env.is_file(): raise RuntimeError(f"Missing persistent environment file: {env}")
    postgres=(runtime/"postgres-v65")
    if postgres.exists() and (postgres.is_symlink() or not postgres.is_dir()): raise RuntimeError(f"Unsafe PostgreSQL path: {postgres}")
    return {"runtime":str(runtime),"env":str(env),"postgres":str(postgres)}

def _copy_release_tree(source, destination):
    """Copy replaceable release files only. Persistent package entries are ignored."""
    source=Path(source); destination=Path(destination); destination.mkdir(parents=True,exist_ok=True)
    for x in source.iterdir():
        if x.name=="agent_manifest.json" or x.name in PERSISTENT_MES_NAMES: continue
        dst=destination/x.name
        if x.is_dir(): shutil.copytree(x,dst,symlinks=True)
        elif x.is_file(): shutil.copy2(x,dst)

def _stage_linux_release(release, log):
    persistent=_validate_persistent_paths()
    env_stat=(TARGET_HOME/".env").stat()
    log.write(f"PERSISTENT ENV OK path={persistent['env']} mode={env_stat.st_mode & 0o777:04o} uid={env_stat.st_uid} gid={env_stat.st_gid}; secrets not logged\n")
    log.flush()
    stage=DATA_DIR/"staging"/f"mes_{uuid.uuid4().hex}"
    stage.parent.mkdir(parents=True,exist_ok=True); stage.mkdir()
    _copy_release_tree(release,stage)
    for name in PERSISTENT_MES_NAMES:
        src=TARGET_HOME/name
        if src.exists(): (stage/name).symlink_to(src,target_is_directory=src.is_dir())
    if not (stage/"compose.yml").is_file(): raise RuntimeError("Staged release has no compose.yml")
    image_meta=load_json(release/"release.json",{})
    image_mode=image_meta.get("type")==IMAGE_RELEASE_TYPE
    image_ref=None
    if image_mode:
        log.write("IMAGE RELEASE MODE: source build disabled\n");log.flush()
        image_ref=_verify_and_prepare_image_release(release,image_meta,log)
    else:
        _require_local_source_build("MESFlow")
        log.write("LEGACY LOCAL SOURCE BUILD: DEV only; promotion targets require an immutable image release\n");log.flush()
    log.write("COMPOSE VALIDATION START\n"); log.flush()
    _compose_at(stage,log,["config","--quiet"],timeout=COMPOSE_VALIDATE_TIMEOUT,env_extra={"MESFLOW_IMAGE":image_ref} if image_ref else None)
    log.write("COMPOSE VALIDATION DONE\nBUILD START\nBUILD IMAGE mesflow\n"); log.flush()
    if image_mode:
        log.write(f"IMAGE VERIFIED {image_ref}; no server-side docker build\n"); log.flush()
    else:
        started=time.monotonic(); _compose_at(stage,log,["build","mesflow"],timeout=BUILD_TIMEOUT)
        log.write(f"BUILD DONE elapsed={time.monotonic()-started:.1f}s\n"); log.flush()
    # Static migration graph validation only; never connects to or changes PostgreSQL.
    log.write("MIGRATION CHECK START (Alembic heads; no migration is run)\n"); log.flush()
    _compose_at(stage,log,["run","--rm","--no-deps","--entrypoint","alembic","mesflow","heads"],timeout=COMPOSE_VALIDATE_TIMEOUT,env_extra={"MESFLOW_IMAGE":image_ref} if image_ref else None)
    log.write("MIGRATION CHECK DONE\n"); log.flush()
    log.write(f"Staging validated at {stage}; persistent package entries excluded\n");log.flush()
    return stage

def _create_linux_backup(log):
    """Back up the current replaceable MES source.

    A brand-new server legitimately has persistent .env/runtime plus the
    bootstrap PostgreSQL compose, but no application compose.yml yet.  That
    state is recorded as a first-install baseline instead of being rejected.
    """
    backup=DATA_DIR/"mes_backups"/f"source_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:8]}"
    backup.parent.mkdir(parents=True,exist_ok=True); backup.mkdir()
    for x in TARGET_HOME.iterdir():
        if x.name in PERSISTENT_MES_NAMES: continue
        dst=backup/x.name
        if x.is_dir(): shutil.copytree(x,dst,symlinks=True)
        elif x.is_file(): shutil.copy2(x,dst)
    if not (backup/"compose.yml").is_file():
        # Valid only for first application install.  Preserve any bootstrap
        # files (notably compose.bootstrap.yml) so rollback can return to the
        # postgres-only pre-application state.
        (backup/FIRST_INSTALL_BACKUP_MARKER).write_text(
            "No application compose.yml existed before this deployment.\n",
            encoding="utf-8",
        )
        log.write(f"Backed up first-install baseline to {backup}; application compose.yml not present yet\n")
        log.flush()
        return backup
    log.write(f"Backed up exact MES source to {backup}\n");log.flush()
    return backup

def _replace_nonpersistent(source):
    source=Path(source)
    for x in list(TARGET_HOME.iterdir()):
        if x.name in PERSISTENT_MES_NAMES: continue
        if x.is_dir(): shutil.rmtree(x)
        else: x.unlink(missing_ok=True)
    _copy_release_tree(source,TARGET_HOME)
    if not (TARGET_HOME/"compose.yml").is_file(): raise RuntimeError("Cutover did not install compose.yml")

def _save_deploy_tx(**values):
    tx=load_json(DEPLOY_TX_FILE,{})
    tx.update(values); save_json(DEPLOY_TX_FILE,tx); return tx

def _stop_application_tier(log, root=None, image_ref=None):
    root=Path(root or TARGET_HOME)
    _compose_at(root,log,["stop","mesflow"],check=False,timeout=120,env_extra={"MESFLOW_IMAGE":image_ref} if image_ref else None)

def _start_stack(log, root=None, build=False, image_ref=None):
    root=Path(root or TARGET_HOME); args=["up","-d"]
    if not build: args.append("--no-build")
    # PostgreSQL is persistent infrastructure.  It must already be running
    # (bootstrap/operations owns that lifecycle); deployment never recreates
    # it just because the staged application Compose project has a new hash.
    postgres_state=(_docker_mes_state().get("service_health") or {}).get("postgres")
    if postgres_state not in {"healthy","none"}:
        raise RuntimeError(f"Persistent PostgreSQL is not healthy ({postgres_state or 'not running'}); refusing to start/recreate it during application deployment")
    # --no-deps is intentional: only the replaceable application tier is
    # started.  Gateway and PostgreSQL are neither recreated nor reset.
    args.extend(["--no-deps","mesflow"])
    _compose_at(root,log,args,check=True,timeout=300,env_extra={"MESFLOW_IMAGE":image_ref} if image_ref else None)

def _rollback_linux_source(backup, expected_version, log):
    set_step("rollback","running",f"Restoring exact source {backup}")
    backup=Path(backup)
    first_install=(backup/FIRST_INSTALL_BACKUP_MARKER).is_file()
    if (TARGET_HOME/"compose.yml").is_file():
        try:
            _stop_application_tier(log,image_ref=None)
        except Exception as ex:
            log.write(f"Rollback stop warning: {ex}\n")
            log.flush()
    elif first_install:
        log.write("FIRST INSTALL ROLLBACK: no application compose.yml to stop\n")
        log.flush()
    _replace_nonpersistent(backup)

    if first_install:
        # There was no MES application before this deployment.  Roll back to
        # the bootstrap postgres-only state, not to a nonexistent app.
        marker=TARGET_HOME/FIRST_INSTALL_BACKUP_MARKER
        marker.unlink(missing_ok=True)
        bootstrap=TARGET_HOME/"compose.bootstrap.yml"
        if bootstrap.is_file():
            _compose_at(TARGET_HOME,log,["-f","compose.bootstrap.yml","up","-d","postgres"],check=True,timeout=180)
        set_step("rollback","success","ROLLBACK SUCCESS: restored first-install postgres-only baseline")
        return

    _start_stack(log,build=False)
    deadline=time.time()+MES_VERIFY_TIMEOUT; last={}
    while time.time()<deadline:
        time.sleep(2); st=mes_status(); last=st
        if canonical_version(st.get("version"))==canonical_version(expected_version) and st.get("healthy"):
            set_step("rollback","success",f"ROLLBACK SUCCESS: {expected_version}"); return
    set_step("rollback","failed",f"ROLLBACK FAILED: {last}")
    raise RuntimeError(f"Rollback healthcheck failed for {expected_version}: {last}")

def _copy_linux_release(release, log):
    """Install Docker release into /opt/mesflow while preserving persistent runtime."""
    TARGET_HOME.mkdir(parents=True,exist_ok=True)
    backup=_create_linux_backup(log)
    _replace_nonpersistent(release)
    return backup

def _restore_linux_source(backup, log):
    backup=Path(backup)
    if (backup/FIRST_INSTALL_BACKUP_MARKER).is_file():
        _rollback_linux_source(backup,"FIRST_INSTALL",log)
        return
    _rollback_linux_source(backup,(backup/"VERSION.txt").read_text(encoding="utf-8-sig").strip(),log)

def run_job(version, dry_run=False):
    release=RELEASES_DIR/version
    release_meta=load_json(release/"release.json",{})
    image_ref=f"{release_meta.get('image')}@{release_meta.get('image_digest')}" if release_meta.get("type")==IMAGE_RELEASE_TYPE else None
    if image_ref:
        release_meta["image_ref"]=image_ref
    # The release's VERSION.txt is authoritative. Do not verify against a stale
    # route/UI label or filename-derived value.
    release_version=norm((release/"VERSION.txt").read_text(encoding="utf-8-sig")) if (release/"VERSION.txt").is_file() else norm(version)
    expected=canonical_version(release_version)
    requested=canonical_version(version)
    if requested != expected:
        raise RuntimeError(f"Release version mismatch before deploy: requested={requested!r}, VERSION.txt={expected!r}")
    deployment_id=uuid.uuid4().hex; prefix="dry_run" if dry_run else "deploy"; logpath=LOG_DIR/f"{prefix}_{release_version}_{datetime.now():%Y%m%d_%H%M%S}.log";before=mes_status().get("version",current_file_version())
    def begin(s):s["job"]={"type":prefix,"dry_run":dry_run,"version":version,"from_version":before,"deployment_id":deployment_id,"status":"queued","phase":"queued","started_at":now_text(),"finished_at":None,"log_file":str(logpath),"message":"Queued","steps":{},"transitions":[{"status":"uploading","at":now_text(),"message":"ZIP received"},{"status":"validating","at":now_text(),"message":"ZIP contract validated"},{"status":"queued","at":now_text(),"message":"Deploy worker queued"}]}
    update_state(begin);append_log(f"Deploy {before} -> {version}, id={deployment_id}")
    status="failed";message="";rc=-1;rolled="";backup=None;stage=None;cutover=False
    try:
        with logpath.open("w",encoding="utf-8") as log:
            if os.name!="nt" and (release/"compose.yml").is_file():
                set_job_phase("validating","Validating compose, package contract and migration chain")
                set_step("stage","running","Staging release; production remains online")
                set_job_phase("validating", "Verifying immutable image artifact" if release_meta.get("type")==IMAGE_RELEASE_TYPE else "Legacy DEV/LOCAL source build")
                stage=_stage_linux_release(release,log)
                set_step("stage","success",f"Validated stage: {stage}")
                if dry_run:
                    set_step("backup","skipped","Dry-run: no production backup/cutover")
                    set_step("install","skipped","Dry-run: production source unchanged")
                    set_step("restart","skipped","Dry-run: production stack not stopped")
                    set_step("health","success","Dry-run validation passed; production untouched")
                    set_step("rollback","skipped","Not required")
                    status="success";message=f"Dry-run verified: {expected}; production unchanged";rc=0
                else:
                    set_job_phase("deploying","Creating backup and updating application only; PostgreSQL stays running")
                    set_step("backup","running","Backing up exact current MES source")
                    backup=_create_linux_backup(log)
                    set_step("backup","success",f"Backup: {backup}")
                    _save_deploy_tx(status="prepared",phase="BACKUP",version=version,from_version=before,backup=str(backup),stage=str(stage),deployment_id=deployment_id)
                    set_step("restart","running","CUTOVER: stopping application only; gateway and PostgreSQL remain running")
                    cutover=True; _save_deploy_tx(status="running",phase="CUTOVER")
                    if (TARGET_HOME/"compose.yml").is_file():
                        _stop_application_tier(log,image_ref=image_ref)
                    else:
                        log.write("FIRST INSTALL: no existing application compose.yml; skip application stop\n")
                        log.flush()
                    _replace_nonpersistent(stage)
                    if image_ref:
                        save_json(TARGET_HOME/"release.json",{**release_meta,"image_ref":image_ref})
                    set_step("install","success",f"Installed staged Docker release files for {version}")
                    _save_deploy_tx(phase="START")
                    _start_stack(log,build=False,image_ref=image_ref);set_step("restart","success","MES Docker stack started; PostgreSQL data preserved")
                    set_job_phase("verifying",f"Checking container, API, database and version for up to {MES_VERIFY_TIMEOUT}s")
                    set_step("health","running",f"Waiting up to {MES_VERIFY_TIMEOUT}s for MES")
                    end=time.time()+MES_VERIFY_TIMEOUT;last={}
                    while time.time()<end:
                        time.sleep(2)
                        st=mes_status(); v=st.get("version_payload") or {}; h=st.get("health_payload") or {}; ds=st.get("docker") or {}
                        actual=canonical_version(st.get("version"))
                        last={"expected_version":expected,"resolved_version":actual,"version":v,"health":h,"docker":ds}
                        checks=h.get("checks") if isinstance(h.get("checks"),dict) else {}
                        database_ok=bool((checks.get("database") or {}).get("ok")) or h.get("database_backend")=="postgresql"
                        api_ok=bool(st.get("api_online")) and st.get("health_state") in ("healthy","warning")
                        docker_ok=bool(ds.get("running")) and ds.get("health") in ("healthy","none")
                        log.write(f"VERIFY expected={expected!r} actual={actual!r} api_ok={api_ok} docker_ok={docker_ok} database_ok={database_ok} health_state={st.get('health_state')!r} docker_health={ds.get('health')!r}\n"); log.flush()
                        if actual == expected and api_ok and docker_ok and database_ok: break
                    else: raise RuntimeError(f"MES verification timeout. expected={expected!r}, actual={last.get('resolved_version')!r}. Last response: {last}")
                    set_step("health","success",f"Version {expected} and health verified");set_step("version","success",f"Running version {expected}");set_step("rollback","skipped","Not required")
                    _save_deploy_tx(status="success",phase="SUCCESS",finished_at=now_text())
                    status="success";message=f"Deployment verified: {expected}";rc=0
            else:
                stop_mes(log)
                set_step("backup","running","Installing legacy release and backing up database")
                cmd=[sys.executable,str(release/"install/deploy_release.py"),"--home",str(TARGET_HOME),"--source",str(release),"--deployment-id",deployment_id,"--channel",load_json(release/"release.json",{}).get("channel","stable")]
                env=os.environ.copy();env["PYTHONUTF8"]="1";rc=subprocess.run(cmd,cwd=str(release),stdout=log,stderr=subprocess.STDOUT,text=True,env=env,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)).returncode
                if rc:raise RuntimeError(f"Installer exited with code {rc}")
                pid=start_mes(log);set_step("restart","success",f"MES started, PID {pid}")
                wait_verify(version,deployment_id,MES_VERIFY_TIMEOUT,pid=pid);set_step("health","success","Health verified")
                status="success";message=f"Deployment verified: {version}";rc=0
    except Exception as e:
        message=str(e);append_log(f"MES deploy failed stage={((load_state().get('job') or {}).get('phase','unknown'))} exception={type(e).__name__} error={message}")
        if os.name!="nt" and cutover and backup:
            try:
                with logpath.open("a",encoding="utf-8") as log:
                    _save_deploy_tx(status="rollback",phase="ROLLBACK")
                    _rollback_linux_source(backup,before,log);rolled=before;message += f"; ROLLBACK SUCCESS to {before}"
                    _save_deploy_tx(status="rolled_back",phase="ROLLBACK_SUCCESS",finished_at=now_text())
            except Exception as re:
                _save_deploy_tx(status="rollback_failed",phase="ROLLBACK_FAILED",error=str(re),finished_at=now_text())
                message += f"; ROLLBACK FAILED: {re}"
    if not dry_run and image_ref:
        # Image-release deploy (the Build-Once/Promote-Same-Artifact path):
        # record LOCAL_PASS/FAILED from real evidence (image id, schema,
        # smoke check), never from the job return code alone.
        try: _record_local_deploy_result(version,status=="success",message)
        except Exception as ex: append_log(f"LOCAL_PASS recording failed: {type(ex).__name__}: {ex}")
    def done(s):
        j=s.get("job") or {};j.update(status=status,phase=status,finished_at=now_text(),return_code=rc,message=message,rolled_back_to=rolled)
        j.setdefault("transitions",[]).append({"status":status,"at":now_text(),"message":message})
        s["job"]=j;s.setdefault("history",[]).insert(0,dict(j));s["history"]=s["history"][:50]
    try:
        final_job=update_state(done).get("job") or {}
        append_log(f"Deploy finished status={status}: {message}")
        try:
            # This same worker runs both DEV's own "Deploy Local" trigger and
            # a TEST/PRODUCTION target's receiving-side auto-deploy after
            # /upload -- each Agent only ever has its OWN state, so the
            # environment this deploy actually represents is this Agent's own
            # SERVER_ROLE, not a hardcoded "LOCAL" (matching the QA-side hook).
            env={"PRODUCTION_TEST":"TEST","PRODUCTION":"PRODUCTION"}.get(SERVER_ROLE,SERVER_ROLE or "LOCAL")
            _record_deployment_history("MESFLOW",env,version=final_job.get("version",""),from_version=final_job.get("from_version",""),
                status=final_job.get("status",""),message=final_job.get("message",""),started_at=final_job.get("started_at",""),
                finished_at=final_job.get("finished_at",""),deployment_id=final_job.get("deployment_id",""),
                log_file=final_job.get("log_file",""),rolled_back_to=final_job.get("rolled_back_to"),steps=final_job.get("steps"))
        except Exception as ex: append_log(f"Deployment history recording failed: {type(ex).__name__}: {ex}")
    finally:
        if stage and Path(stage).exists(): shutil.rmtree(stage,ignore_errors=True)
        DEPLOY_LOCK_FILE.unlink(missing_ok=True)
        if _job_lock.locked():_job_lock.release()

def start_deploy(v, dry_run=False):
    if not dry_run and not DEPLOY_ENABLED:
        raise RuntimeError("Production deploy is disabled for this Agent runtime. Set MESFLOW_AGENT_DEPLOY_ENABLED=1 only in a reviewed full-deploy environment.")
    if not (RELEASES_DIR/v).is_dir():raise FileNotFoundError("Release not found")
    job_running()
    if not _job_lock.acquire(False):raise RuntimeError("Another deployment is running")
    file_lock_acquired=False
    try:
        try:
            fd=os.open(str(DEPLOY_LOCK_FILE),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
            os.write(fd,f"{os.getpid()} {now_text()}\n".encode());os.close(fd)
            file_lock_acquired=True
        except FileExistsError:
            raise RuntimeError("Another deployment lock exists; inspect deploy transaction before clearing it")
        def worker():
            # Keep the durable state and locks correct even if an unexpected
            # error happens before run_job enters its own try/finally block.
            try:
                run_job(v,dry_run)
            except Exception as ex:
                message=f"Unexpected deployment worker failure: {type(ex).__name__}: {ex}"
                append_log(f"MES deploy worker failed stage=queued exception={type(ex).__name__} error={ex}")
                def failed(s):
                    j=s.get("job") or {"type":"deploy","version":v,"started_at":now_text(),"steps":{},"transitions":[]}
                    j.update(status="failed",phase="failed",finished_at=now_text(),return_code=-1,message=message)
                    j.setdefault("transitions",[]).append({"status":"failed","at":now_text(),"message":message})
                    s["job"]=j; s.setdefault("history",[]).insert(0,dict(j)); s["history"]=s["history"][:50]
                update_state(failed)
                DEPLOY_LOCK_FILE.unlink(missing_ok=True)
                if _job_lock.locked(): _job_lock.release()
        threading.Thread(target=worker,daemon=True).start()
    except Exception:
        if file_lock_acquired: DEPLOY_LOCK_FILE.unlink(missing_ok=True)
        _job_lock.release()
        raise

# Every job-tracking key in state.json represents work done by a background
# thread of a PREVIOUS process. In-memory locks (_job_lock, _tutorial_job_
# lock, ...) always reset to unlocked on a fresh process start, but only the
# MESFlow "job" key has ever self-healed its persisted status to match (see
# _mark_stale_job_interrupted(), called lazily from job_running()). Every
# other job type left in a non-terminal status by a crash/restart/redeploy
# mid-flight stays stuck showing "running"/"BUILDING"/"UPLOADING"/... in the
# UI forever -- a real incident found live: tutorial_job sat at
# status="running" for 3+ days after an earlier restart, permanently
# rendering "Đang quay, lồng tiếng và publish video hướng dẫn" on the
# Release Deploy tab with no indication anything was wrong. This runs once,
# synchronously, before the Agent serves any request.
_ORPHANABLE_JOB_KEYS=("job","qa_job","tutorial_job","esp_tutorial_job","esp_builder_job",
    "release_build_job","promote_test_job","agent_update_job","agent_package_build_job",
    "qa_release_build_job","qa_local_deploy_job","qa_promote_test_job","qa_image_deploy_job")
_JOB_TERMINAL_STATUSES={"success","SUCCESS","completed","COMPLETED","failed","FAILED","rolled_back","ROLLED_BACK",
    "interrupted","INTERRUPTED","warning","WARNING"}

def reconcile_orphaned_jobs_on_startup():
    reconciled=[]
    def f(s):
        for key in _ORPHANABLE_JOB_KEYS:
            j=s.get(key)
            if not isinstance(j,dict) or not j: continue
            old_status=j.get("status")
            if str(old_status or "") in _JOB_TERMINAL_STATUSES: continue
            j=dict(j)
            j.update(status="INTERRUPTED",
                message=f"Interrupted by Agent restart (was {old_status!r}) -- no worker thread from a previous process can still be running.",
                finished_at=now_text())
            s[key]=j
            reconciled.append((key,old_status))
    update_state(f)  # cheap no-op (one JSON read+write) when nothing is stale
    for key,old_status in reconciled:
        append_log(f"Startup reconciliation: {key} was stuck at status={old_status!r}, marked INTERRUPTED")
    return reconciled

def recover_interrupted_deploy():
    """Recover a process crash after CUTOVER using the durable transaction journal."""
    tx=load_json(DEPLOY_TX_FILE,{})
    if tx.get("status") not in {"running","rollback"} or tx.get("phase") not in {"CUTOVER","START","ROLLBACK"}:
        DEPLOY_LOCK_FILE.unlink(missing_ok=True); return False
    backup=Path(tx.get("backup","") or "/nonexistent")
    valid_backup=backup.is_dir() and (
        (backup/"compose.yml").is_file() or
        (backup/FIRST_INSTALL_BACKUP_MARKER).is_file()
    )
    if not valid_backup:
        append_log(f"ROLLBACK FAILED after Agent restart: invalid backup {backup}")
        _save_deploy_tx(status="rollback_failed",phase="ROLLBACK_FAILED",error="backup unavailable",finished_at=now_text())
        DEPLOY_LOCK_FILE.unlink(missing_ok=True); return False
    recovery_log=LOG_DIR/f"recovery_{datetime.now():%Y%m%d_%H%M%S}.log"
    try:
        with recovery_log.open("w",encoding="utf-8") as log:
            if (backup/FIRST_INSTALL_BACKUP_MARKER).is_file():
                old=tx.get("from_version") or "FIRST_INSTALL"
            else:
                old=tx.get("from_version") or (backup/"VERSION.txt").read_text(encoding="utf-8-sig").strip()
            _rollback_linux_source(backup,old,log)
        _save_deploy_tx(status="rolled_back",phase="ROLLBACK_SUCCESS",recovered_after_restart=True,finished_at=now_text())
        append_log("ROLLBACK SUCCESS after Agent restart"); return True
    except Exception as ex:
        _save_deploy_tx(status="rollback_failed",phase="ROLLBACK_FAILED",error=str(ex),finished_at=now_text())
        append_log(f"ROLLBACK FAILED after Agent restart: {ex}"); return False
    finally: DEPLOY_LOCK_FILE.unlink(missing_ok=True)

def _qa_source_dir():
    current=QA_HOME/"current"
    if (current/"agent.py").is_file() and (current/"VERSION").is_file():
        return current
    # Legacy standalone QA installer placed the app directly in QA_HOME.
    if (QA_HOME/"agent.py").is_file() and (QA_HOME/"VERSION").is_file():
        return QA_HOME
    return current

def qa_current_version():
    src=_qa_source_dir()
    p=src/"VERSION"
    return p.read_text(encoding="utf-8-sig").strip() if p.is_file() else "Chưa cài"

def qa_http_json(path, timeout=4):
    try:
        with urllib.request.urlopen(QA_URL+path, timeout=timeout) as r:
            raw=r.read().decode("utf-8",errors="replace")
            try: payload=json.loads(raw)
            except json.JSONDecodeError: payload={"ok":False,"error":"Invalid JSON response","body":raw[:1000]}
            return payload,r.status
    except urllib.error.HTTPError as e:
        raw=e.read().decode("utf-8",errors="replace")
        try: payload=json.loads(raw)
        except json.JSONDecodeError: payload={"ok":False,"error":str(e),"body":raw[:1000]}
        return payload,e.code
    except Exception as e:
        return {"ok":False,"error":str(e)},0

def _qa_service_state():
    if RUNTIME_MODE=="docker-linux":
        try:
            r=subprocess.run(["docker","inspect","mesflow-qa-center"],capture_output=True,text=True,timeout=8)
            if r.returncode!=0:
                return {"active":False,"pid":0,"runtime":"docker"}
            payload=json.loads(r.stdout)[0]
            state=payload.get("State",{})
            running=bool(state.get("Running"))
            pid=int(state.get("Pid") or 0)
            health=(state.get("Health") or {}).get("Status","")
            return {"active":running,"pid":pid,"runtime":"docker","health":health}
        except Exception:
            return {"active":False,"pid":0,"runtime":"docker"}
    if os.name=="nt": return {"active":False,"pid":0}
    try:
        a=subprocess.run(["systemctl","is-active","mesflow-qa-center.service"],capture_output=True,text=True,timeout=8)
        q=subprocess.run(["systemctl","show","-p","MainPID","--value","mesflow-qa-center.service"],capture_output=True,text=True,timeout=8)
        pid=int((q.stdout or "0").strip() or 0)
        return {"active":a.returncode==0 and (a.stdout or "").strip()=="active","pid":pid,"runtime":"systemd"}
    except Exception:
        return {"active":False,"pid":0}

def qa_status():
    # Live-verified follow-up (reports/DEPLOY_AGENT_REFRESH_PERFORMANCE_FIX.md):
    # when QA_URL's hostname doesn't resolve/connect (QA Center stopped),
    # qa_http_json() alone measured ~5s (DNS retry + connect timeout). On
    # Linux, _qa_service_state() (docker inspect / systemctl -- both local,
    # no network) gives an authoritative "is it even running" answer first;
    # skip the network probe when it says no, since nothing could be
    # listening anyway. Windows has no reliable local check here yet
    # (_qa_service_state() is a stub there, always "active":False), so that
    # path always falls through to the real probe exactly as before.
    svc=_qa_service_state()
    if os.name!="nt" and not svc.get("active"):
        v,code=({"ok":False,"error":"QA_CENTER_NOT_RUNNING"},0)
    else:
        v,code=qa_http_json("/api/version",3)
    actual=str(v.get("version") or qa_current_version())
    return {"online": code==200 and bool(v.get("ok",True)), "version":actual, "payload":v, "port":QA_PORT, "home":str(QA_HOME), "service_active":svc.get("active",False), "service_pid":svc.get("pid",0)}


def qa_job_running():
    j=(load_state().get("qa_job") or {})
    return j.get("status")=="running"


def _qa_runtime_signature(source: Path) -> str:
    manifest=source/"docker"/"runtime-manifest.json"
    if not manifest.is_file():
        # Legacy QA package: force build.
        return ""
    try:
        meta=json.loads(manifest.read_text(encoding="utf-8"))
        files=list(meta.get("signature_files") or [])
    except Exception:
        return ""
    h=hashlib.sha256()
    for rel in files:
        p=source/str(rel)
        if not p.is_file():
            return ""
        h.update(str(rel).encode("utf-8")); h.update(b"\\0"); h.update(p.read_bytes()); h.update(b"\\0")
    return h.hexdigest()


def _qa_runtime_image_exists(source: Path) -> bool:
    compose=source/"docker"/"compose.yml"
    if not compose.is_file():
        return False
    # Resolve image from compose config rather than hard-coding.
    try:
        r=subprocess.run(["docker","compose","-p","mesflow-qa","-f",str(compose),"config","--images"],
                         cwd=str(source),capture_output=True,text=True,timeout=30)
        images=[x.strip() for x in (r.stdout or "").splitlines() if x.strip()]
        if r.returncode!=0 or not images:
            return False
        for image in images:
            q=subprocess.run(["docker","image","inspect",image],capture_output=True,text=True,timeout=15)
            if q.returncode!=0:
                return False
        return True
    except Exception:
        return False


def _qa_compose_file():
    current=QA_HOME/"current"
    p=current/"docker"/"compose.yml"
    if not p.is_file():
        raise RuntimeError(f"QA Docker package missing: {p}")
    return p

def _qa_compose(args, log=None, check=True, timeout=900):
    cmd=["docker","compose","-p","mesflow-qa","-f",str(_qa_compose_file())]+list(args)
    return subprocess.run(cmd,cwd=str(QA_HOME/"current"),check=check,stdout=log or subprocess.PIPE,
                          stderr=subprocess.STDOUT if log else subprocess.PIPE,text=True,timeout=timeout)

def _qa_docker_stop(log=None):
    if not (QA_HOME/"current"/"docker"/"compose.yml").is_file():
        return
    _qa_compose(["stop","mesflow-qa-center"],log=log,check=False,timeout=60)

def _qa_docker_start(log=None, build=True):
    if build:
        _require_local_source_build("QA Center")
    args=["up","-d"]
    if build:
        args.append("--build")
    else:
        args.extend(["--no-build","--force-recreate"])
    args.append("mesflow-qa-center")
    if log:
        log.write(("QA runtime rebuild required\n" if build else "FAST QA DEPLOY: runtime unchanged; skipping Docker build\n"))
        log.flush()
    _qa_compose(args,log=log,check=True,timeout=1200 if build else 180)
    # Do not return Docker host PID. The Deploy Agent runs in its own PID
    # namespace, so process_alive(host_pid) is invalid and caused false
    # "QA Center process exited" failures even when the QA container was healthy.
    return 0

def _stop_qa(timeout=30):
    # Real bug found+fixed while wiring the new "QA Center" service card
    # (reports/RELEASE_DEPLOY_UX_CLEANUP.md): the current Build-Once image
    # release installs to QA_HOME/compose.yml (see _qa_deploy_from_staging),
    # never to the legacy QA_HOME/current/docker/compose.yml that
    # _qa_docker_stop()/_qa_docker_start() (below) target. Route the current
    # layout through _qa_release_compose (same mechanism the real deploy
    # path uses); fall back to the legacy helper only for a pre-migration
    # install that still has the old layout on disk.
    end=time.time()+timeout
    if RUNTIME_MODE=="docker-linux":
        if (QA_HOME/"compose.yml").is_file():
            log_path=LOG_DIR/f"qa_stop_{datetime.now():%Y%m%d_%H%M%S}.log"
            with log_path.open("w",encoding="utf-8") as log:
                _qa_release_compose(log,["stop","mesflow-qa-center"],check=False,timeout=60)
        else:
            _qa_docker_stop()
        return
    if os.name!="nt":
        subprocess.run(["systemctl","stop","mesflow-qa-center.service"],capture_output=True,text=True,timeout=20)
    meta=load_json(QA_HOME/"qa_process.json",{})
    pids=set(port_pids(QA_PORT))
    if str(meta.get("pid","")).isdigit(): pids.add(int(meta["pid"]))
    for pid in sorted(pids):
        if pid==os.getpid(): continue
        try:
            if os.name=="nt": subprocess.run(["taskkill","/PID",str(pid),"/T","/F"],capture_output=True,text=True,timeout=15,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            else: os.kill(pid,15)
        except Exception: pass
    while time.time()<end:
        svc=_qa_service_state()
        if not port_open(port=QA_PORT) and not svc.get("active"):
            return
        time.sleep(1)
    for pid in sorted(set(port_pids(QA_PORT))|pids):
        try:
            if os.name!="nt": os.kill(pid,9)
        except Exception: pass
    time.sleep(1)
    if port_open(port=QA_PORT): raise RuntimeError(f"QA Center did not stop; port {QA_PORT} is still open")

def _qa_python():
    return QA_HOME/(".venv/Scripts/python.exe" if os.name=="nt" else ".venv/bin/python")

def _ensure_qa_venv(release, log):
    py=_qa_python()
    if not py.is_file():
        QA_HOME.mkdir(parents=True,exist_ok=True)
        subprocess.run([sys.executable,"-m","venv",str(QA_HOME/".venv")],check=True,stdout=log,stderr=subprocess.STDOUT,text=True)
    subprocess.run([str(py),"-m","pip","install","--disable-pip-version-check","-r",str(release/"requirements.txt")],check=True,stdout=log,stderr=subprocess.STDOUT,text=True)
    return py

def _write_qa_systemd_service():
    if os.name=="nt": return
    current=QA_HOME/"current"
    py=_qa_python(); entry=current/"agent.py"
    unit=Path("/etc/systemd/system/mesflow-qa-center.service")
    text=f"""[Unit]
Description=MESFlow QA Center managed by MESFlow Deploy Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory={current}
Environment=PYTHONUNBUFFERED=1
Environment=PYTHONUTF8=1
Environment=MESFLOW_QA_HOST=0.0.0.0
Environment=MESFLOW_QA_PORT={QA_PORT}
ExecStart={py} {entry}
Restart=on-failure
RestartSec=5
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
"""
    unit.write_text(text,encoding="utf-8")
    subprocess.run(["systemctl","daemon-reload"],check=True,capture_output=True,text=True,timeout=20)
    subprocess.run(["systemctl","enable","mesflow-qa-center.service"],check=True,capture_output=True,text=True,timeout=20)

def _start_qa(log=None, build=True):
    # See _stop_qa() comment: current image-release installs never populate
    # QA_HOME/current/agent.py, so the old unconditional entry-file check
    # below (kept for the legacy pre-migration layout) must not run first.
    if RUNTIME_MODE=="docker-linux" and (QA_HOME/"compose.yml").is_file():
        log_path=LOG_DIR/f"qa_start_{datetime.now():%Y%m%d_%H%M%S}.log"
        with log_path.open("w",encoding="utf-8") as l:
            _qa_release_compose(l,["up","-d","--no-build","--force-recreate","mesflow-qa-center"])
        return 0
    current=QA_HOME/"current"; entry=current/"agent.py"
    if not entry.is_file(): raise RuntimeError(f"Missing QA entry: {entry}")
    if RUNTIME_MODE=="docker-linux":
        return _qa_docker_start(log=log,build=build)
    py=_qa_python()
    if not py.is_file(): raise RuntimeError(f"Missing QA Python: {py}")
    if os.name!="nt":
        _write_qa_systemd_service()
        r=subprocess.run(["systemctl","restart","mesflow-qa-center.service"],capture_output=True,text=True,timeout=30)
        if r.returncode!=0:
            raise RuntimeError("Cannot start mesflow-qa-center.service: "+((r.stderr or r.stdout or "").strip()))
        time.sleep(0.5)
        svc=_qa_service_state(); pid=int(svc.get("pid") or 0)
        save_json(QA_HOME/"qa_process.json",{"pid":pid,"started_at":now_text(),"version":qa_current_version(),"log":"journalctl -u mesflow-qa-center.service"})
        if log: log.write(f"Started QA Center systemd service PID {pid} on port {QA_PORT}\n"); log.flush()
        return pid
    env=os.environ.copy(); env.update({"MESFLOW_QA_HOST":"0.0.0.0","MESFLOW_QA_PORT":str(QA_PORT),"PYTHONUTF8":"1"})
    flags=getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0)|getattr(subprocess,"DETACHED_PROCESS",0)|getattr(subprocess,"CREATE_NO_WINDOW",0)
    h=QA_LOG.open("a",encoding="utf-8")
    proc=subprocess.Popen([str(py),str(entry)],cwd=str(current),env=env,stdout=h,stderr=subprocess.STDOUT,creationflags=flags,close_fds=True)
    save_json(QA_HOME/"qa_process.json",{"pid":proc.pid,"started_at":now_text(),"version":qa_current_version(),"log":str(QA_LOG)})
    if log: log.write(f"Started QA Center PID {proc.pid} on port {QA_PORT}\n"); log.flush()
    return proc.pid

def _qa_docker_log_tail(lines=80):
    try:
        r=subprocess.run(["docker","logs","--tail",str(lines),"mesflow-qa-center"],
                         capture_output=True,text=True,timeout=10)
        return ((r.stdout or "")+(r.stderr or "")).strip()
    except Exception as ex:
        return f"<docker logs unavailable: {ex}>"

def _wait_qa(version,timeout=None,pid=None):
    end=time.time()+(timeout or QA_VERIFY_TIMEOUT); last={}
    while time.time()<end:
        time.sleep(1)
        if RUNTIME_MODE=="docker-linux":
            svc=_qa_service_state()
            if not svc.get("active"):
                raise RuntimeError("QA Center container exited. Docker log tail:\n"+_qa_docker_log_tail(80))
        elif pid and not process_alive(pid) and not port_open(port=QA_PORT):
            raise RuntimeError("QA Center process exited. Log tail:\n"+tail(QA_LOG,80))
        v,code=qa_http_json("/api/version",3); last=v
        if code==200 and str(v.get("version","")).lstrip("Vv")==version.lstrip("Vv"):
            return v
    extra=_qa_docker_log_tail(80) if RUNTIME_MODE=="docker-linux" else tail(QA_LOG,80)
    raise RuntimeError(f"QA Center verify timeout. Last response: {last}. Log tail:\n{extra}")

def _password_valid(value):
    return len(value or "")>=10
def _set_password(new_password):
    if not _password_valid(new_password):raise ValueError("Mật khẩu mới tối thiểu 10 ký tự")
    c=ensure_config();c["password_hash"]=generate_password_hash(new_password);c["password_changed_at"]=now_text();save_json(CONFIG_FILE,c)
    (CONFIG_DIR/"FIRST_LOGIN.txt").unlink(missing_ok=True)
    append_log("Administrator password reset")
def _docker_bridge_gateway():
    """This container's own default-route gateway IP (Linux only). A host
    browser hitting a `docker run/compose -p 127.0.0.1:PORT:PORT`
    published port is source-NAT'd on the hairpin path -- the connection
    arrives here appearing to come FROM that gateway address, never from
    literal 127.0.0.1. Read live from /proc/net/route (never hardcoded,
    varies per Docker network); returns "" if undeterminable."""
    try:
        with open("/proc/net/route",encoding="ascii") as f:
            next(f)  # header line
            for line in f:
                fields=line.split()
                if len(fields)>=3 and fields[1]=="00000000":  # destination 0.0.0.0 = default route
                    hex_gw=fields[2]
                    return ".".join(str(int(hex_gw[i:i+2],16)) for i in (6,4,2,0))
    except (OSError,ValueError,StopIteration):
        pass
    return ""
def _is_local_reset_request():
    host=(request.host or "").split(":",1)[0].strip("[]").lower()
    if host not in {"127.0.0.1","localhost","::1"}:return False
    remote=request.remote_addr
    if remote in {"127.0.0.1","::1"}:return True
    # Docker NAT hairpin (see _docker_bridge_gateway docstring) -- only
    # trust this when it matches THIS container's own live-read gateway,
    # so it can't be spoofed by guessing a common private IP.
    if RUNTIME_MODE=="docker-linux":
        gateway=_docker_bridge_gateway()
        if gateway and remote==gateway:return True
    return False
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=ensure_config()
        if hmac.compare_digest(request.form.get("username",""),"admin") and check_password_hash(c["password_hash"],request.form.get("password","")):
            session.clear();session["authenticated"]=True;session["csrf"]=secrets.token_urlsafe(24);return redirect(url_for("index"))
        flash("Sai tài khoản hoặc mật khẩu","error")
    return render_template("login.html")
@app.route("/forgot-password",methods=["GET","POST"])
def forgot_password():
    if request.method=="POST":
        c=ensure_config();code=_normalize_recovery_code(request.form.get("recovery_code",""));new=request.form.get("new_password","");confirm=request.form.get("confirm_password","")
        if not code or not check_password_hash(c.get("recovery_code_hash",""),code):flash("Recovery Code không đúng","error")
        elif new!=confirm:flash("Xác nhận mật khẩu không khớp","error")
        else:
            try:_set_password(new);flash("Đã đặt lại mật khẩu. Hãy đăng nhập lại.","success");return redirect(url_for("login"))
            except ValueError as ex:flash(str(ex),"error")
    return render_template("forgot_password.html",local_reset_url=f"http://localhost:{PORT}{URL_PREFIX}/local-reset")
@app.route("/local-reset",methods=["GET","POST"])
def local_reset():
    if not _is_local_reset_request():abort(403)
    if request.method=="POST":
        new=request.form.get("new_password","");confirm=request.form.get("confirm_password","")
        if new!=confirm:flash("Xác nhận mật khẩu không khớp","error")
        else:
            try:_set_password(new);flash("Đã đặt lại mật khẩu từ máy chủ. Hãy đăng nhập.","success");return redirect(url_for("login"))
            except ValueError as ex:flash(str(ex),"error")
    return render_template("local_reset.html")
@app.post("/logout")
def logout():verify_csrf();session.clear();return redirect(url_for("login"))

def tutorial_job_running():
    return _tutorial_job_lock.locked()

TUTORIAL_TOTAL_VIDEOS=14
TUTORIAL_ACTIVE_STATUSES={"queued","running"}
TUTORIAL_TERMINAL_STATUSES={"completed","failed","warning","cancelled","interrupted","INTERRUPTED"}

class TutorialAuthError(RuntimeError):
    def __init__(self,status=401,message="Sai username/password"):
        super().__init__(message);self.status=int(status)

def _tutorial_job_is_current(job):
    return bool(isinstance(job,dict) and job.get("agent_version")==AGENT_VERSION)

def _tutorial_error_details(ex):
    text=str(ex) or type(ex).__name__
    if isinstance(ex,TutorialAuthError):
        return "TUTORIAL_AUTH_FAILED",text,"Nhập lại username/password rồi bấm Kiểm tra đăng nhập."
    known=("TUTORIAL_SOURCE_SCRIPT_NOT_FOUND","TUTORIAL_NESTED_READONLY_MOUNT","SERVER_VIDEO_GENERATION_DEV_ONLY")
    code=next((x for x in known if x in text),"TUTORIAL_EXPORT_FAILED")
    return code,text,"Mở màn hình theo dõi, xem log gần nhất và thử lại sau khi xử lý nguyên nhân."

def _tutorial_public_job(job,include_log=True):
    """Return the safe status contract. Credentials never enter durable state."""
    if not isinstance(job,dict) or not job:
        return {
            "status":"needs_authentication","stage":"needs_authentication","progress":0,
            "message":"Chưa xác minh tài khoản MESFlow","next_action":"Nhập username/password → Kiểm tra đăng nhập",
            "agent_version":AGENT_VERSION,
        }
    allowed=("job_id","created_at","started_at","finished_at","updated_at","status","stage",
        "progress","current","total","current_item","message","error_code","error_reason",
        "reason","next_action","username","seed_data","agent_version","source_version",
        "published_count","manifest_status","publish_dir","step_id","step_number","focus_selector",
        "current_action","expected_result","bug_report_path","screenshot_path")
    allowed=allowed+("coverage","coverage_report_path","coverage_status","bug_count","selector_preflight",)
    public={k:job.get(k) for k in allowed if job.get(k) is not None}
    public["historical"]=not _tutorial_job_is_current(job)
    started=job.get("started_at")
    try:
        start_dt=datetime.strptime(str(started),"%Y-%m-%d %H:%M:%S")
        end_dt=datetime.strptime(str(job.get("finished_at")),"%Y-%m-%d %H:%M:%S") if job.get("finished_at") else datetime.now()
        public["elapsed_seconds"]=max(0,int((end_dt-start_dt).total_seconds()))
    except (TypeError,ValueError):
        public["elapsed_seconds"]=0
    log_path=_tutorial_safe_log_path(job.get("log_file"))
    if log_path:
        public["log_path"]=str(log_path)
        if include_log: public["log_tail"]=_tutorial_log_tail(str(log_path))
    return public

def _tutorial_find_job(job_id):
    state=load_state();current=state.get("tutorial_job") or {}
    # "current" remains version-scoped for the live monitor, but an explicit
    # immutable job id must stay addressable after an Agent upgrade so its
    # already-built artifact can still be verified and promoted.
    if str(job_id)==str(current.get("job_id") or ""): return current
    if job_id=="current": return current if _tutorial_job_is_current(current) else {}
    for job in state.get("tutorial_history") or []:
        if str(job.get("job_id") or "")==str(job_id): return job
    return None

def _tutorial_safe_log_path(raw):
    """Return a tutorial log path only when it is inside LOG_DIR.

    The monitor never accepts an arbitrary filesystem path from the browser; it
    only follows the path already persisted by the Agent job state.
    """
    if not raw: return None
    try:
        path=Path(str(raw)).resolve()
        root=LOG_DIR.resolve()
        if path.parent!=root or not path.name.startswith("tutorial_") or path.suffix!=".log": return None
        return path
    except (OSError,ValueError):
        return None

def _tutorial_log_tail(raw,max_bytes=65536):
    path=_tutorial_safe_log_path(raw)
    if not path or not path.is_file(): return ""
    try:
        size=path.stat().st_size
        with path.open("rb") as f:
            if size>max_bytes: f.seek(size-max_bytes)
            data=f.read(max_bytes)
        text=data.decode("utf-8","replace")
        if size>max_bytes:
            # Drop the possibly-partial first line after seeking into the file.
            text=text.split("\n",1)[1] if "\n" in text else text
            text="… log trước đó đã được rút gọn …\n"+text
        return text
    except OSError:
        return ""

def _tutorial_error_hint(log_path,max_chars=320):
    text=_tutorial_log_tail(log_path,16384)
    if not text: return ""
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    # Docker exit 125 normally prints the useful daemon/CLI reason at the end.
    interesting=[x for x in lines[-12:] if not x.startswith("RUN: docker run")]
    if not interesting: return ""
    hint=" | ".join(interesting[-3:])
    hint=re.sub(r'(?i)(password|token|secret)([=:]\s*)[^\s]+',r'\1\2***',hint)
    return hint[-max_chars:]

def _tutorial_update(job_id=None,**values):
    values.setdefault("updated_at",now_text())
    def f(st):
        job=dict(st.get("tutorial_job") or {})
        if job_id and job.get("job_id")!=job_id:return
        job.update(values)
        st["tutorial_job"]=job
    update_state(f)

def _tutorial_finish(status,message,job_id=None,**values):
    def f(st):
        job=dict(st.get("tutorial_job") or {})
        if job_id and job.get("job_id")!=job_id:return
        job.update({"status":status,"message":message,"finished_at":now_text(),"updated_at":now_text(),**values})
        st["tutorial_job"]=job
        hist=st.setdefault("tutorial_history",[])
        hist.insert(0,dict(job))
        st["tutorial_history"]=hist[:20]
    update_state(f)

def _tutorial_refresh_progress_from_log(log_path,job_id):
    text=_tutorial_log_tail(str(log_path),32768)
    matches=list(re.finditer(r"TUTORIAL_PROGRESS\s+stage=([a-z_]+)(?:\s+current=(\d+)\s+total=(\d+)\s+item=([^\s]+))?",text))
    if not matches:return
    match=matches[-1];stage=match.group(1);values={"stage":stage}
    if match.group(2):
        current=int(match.group(2));total=max(1,int(match.group(3)))
        values.update(current=current,total=total,current_item=match.group(4),
            progress=min(99,int(current*100/total)),message=f"Đang quay {current}/{total}: {match.group(4)}")
    elif stage=="publishing":values.update(progress=92,message="Đang publish video vào MESFlow")
    elif stage=="verifying":values.update(progress=97,message="Đang xác minh manifest và video đã publish")
    step_matches=list(re.finditer(r"TUTORIAL_STEP\s+step_id=([^\s]+)\s+number=(\d+)\s+selector=([^\s]+)\s+action=([^\s]+)\s+expected=([^\s]+)",text))
    if step_matches:
        from urllib.parse import unquote
        step=step_matches[-1]
        values.update(step_id=step.group(1),step_number=int(step.group(2)),focus_selector=unquote(step.group(3)),
            current_action=unquote(step.group(4)),expected_result=unquote(step.group(5)))
    bug_matches=list(re.finditer(r"TUTORIAL_BUG_REPORT\s+path=([^\s]+)\s+step_id=([^\s]+)\s+selector=([^\s]*)\s+action=([^\s]*)",text))
    if bug_matches:
        from urllib.parse import unquote
        bug=bug_matches[-1]
        values.update(bug_report_path=bug.group(1),step_id=bug.group(2),focus_selector=unquote(bug.group(3)),current_action=unquote(bug.group(4)))
    coverage_matches=list(re.finditer(r"TUTORIAL_COVERAGE\s+payload=([^\s]+)",text))
    if coverage_matches:
        from urllib.parse import unquote
        try:
            coverage=json.loads(unquote(coverage_matches[-1].group(1)))
            summary=coverage.get("summary") or {}
            values.update(coverage=summary,coverage_status=coverage.get("status"),
                coverage_report_path=coverage.get("report_path"),selector_preflight=coverage.get("gate",{}).get("selectors"))
        except (ValueError,TypeError,json.JSONDecodeError):
            values.update(coverage_status="invalid",message="Coverage report không hợp lệ")
    qa_bug_matches=list(re.finditer(r"TUTORIAL_QA_REPORT\s+path=([^\s]+)\s+status=([^\s]+)\s+steps=(\d+)\s+bugs=(\d+)",text))
    if qa_bug_matches:
        values["bug_count"]=sum(int(item.group(4)) for item in qa_bug_matches)
    _tutorial_update(job_id,**values)

def _tutorial_builder_dockerfile():
    return """FROM mcr.microsoft.com/playwright:v1.62.1-noble
ENV DEBIAN_FRONTEND=noninteractive
RUN apt-get update \\
 && apt-get install -y --no-install-recommends ffmpeg python3 python3-venv ca-certificates curl \\
 && rm -rf /var/lib/apt/lists/* \\
 && python3 -m venv /opt/tts \\
 && /opt/tts/bin/pip install --no-cache-dir edge-tts
ENV PATH="/opt/tts/bin:${PATH}"
WORKDIR /opt/mesflow
"""

def _tutorial_login_preflight(username,password,log):
    payload=json.dumps({"username":username or "admin","password":password}).encode("utf-8")
    req=urllib.request.Request(
        "http://mesflow-app:8080/api/auth/login",
        data=payload,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST",
    )
    last=""
    for attempt in range(1,4):
        try:
            with urllib.request.urlopen(req,timeout=10) as resp:
                body=resp.read(2000).decode("utf-8","replace")
                if 200 <= resp.status < 300:
                    try:
                        data=json.loads(body or "{}")
                    except Exception:
                        data={}
                    if data.get("ok"):
                        log.write("[AUTH] Tài khoản MESFlow hợp lệ.\n"); log.flush()
                        return True
                last=f"HTTP {resp.status}"
        except urllib.error.HTTPError as ex:
            # Never include response bodies here: an auth failure only needs status,
            # and this avoids accidentally persisting sensitive payload details.
            last=f"HTTP {ex.code}"
            if ex.code==429:
                wait=5*attempt
                log.write(f"[AUTH] Đang bị giới hạn đăng nhập; chờ {wait}s rồi thử lại.\n"); log.flush()
                time.sleep(wait)
                continue
            if ex.code in (401,403):
                raise TutorialAuthError(ex.code,"Sai username/password")
            raise RuntimeError(f"Không xác minh được đăng nhập MESFlow: {last}")
        except Exception as ex:
            last=type(ex).__name__
            time.sleep(2)
    raise RuntimeError(f"Không xác minh được đăng nhập MESFlow: {last}")

def _tutorial_seed(log,action):
    cmd=["docker","exec","-e","MESFLOW_TUTORIAL_DATA_ALLOW_PRODUCTION=1",
         "mesflow-app","python","-m","mesflow.tutorial_data",action]
    log.write(f"RUN: docker exec mesflow-app ... tutorial_data {action}\n");log.flush()
    r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,text=True,timeout=240)
    if r.returncode:
        raise RuntimeError(f"Tutorial data {action} failed with code {r.returncode}")

def _docker_host_bind_path(container_path):
    """Translate a path visible in this Agent container to its Docker-host source.

    The Agent talks to the host Docker daemon through docker.sock.  Passing a
    container-only path (for example /workspace/mesflow/mesflow) to ``-v``
    makes the daemon bind an unrelated/empty host path.  Resolve the longest
    matching mount from this container's own inspect metadata instead.
    """
    path=Path(container_path).resolve()
    container_id=os.environ.get("HOSTNAME","").strip()
    if not container_id:
        return path
    try:
        result=subprocess.run(
            ["docker","inspect",container_id,"--format","{{json .Mounts}}"],
            capture_output=True,text=True,timeout=15,check=False,
        )
        if result.returncode:
            return path
        mounts=json.loads(result.stdout or "[]")
        matches=[]
        for mount in mounts:
            destination=Path(str(mount.get("Destination") or "")).resolve()
            try:
                relative=path.relative_to(destination)
            except ValueError:
                continue
            source=mount.get("Source")
            if source:
                matches.append((len(destination.parts),Path(str(source))/relative))
        if matches:
            return max(matches,key=lambda item:item[0])[1]
    except (OSError,ValueError,TypeError,json.JSONDecodeError,subprocess.SubprocessError):
        pass
    return path

def _tutorial_validate_tree(root,source_job_id=""):
    root=Path(root).resolve(); manifest=root/"manifest.json"
    if not manifest.is_file(): raise ValueError("TUTORIAL_MANIFEST_MISSING")
    data=json.loads(manifest.read_text(encoding="utf-8")); raw=data.get("videos") or data.get("items") or []
    if not isinstance(raw,list) or not raw: raise ValueError("TUTORIAL_MANIFEST_EMPTY")
    videos=[]
    for index,item in enumerate(raw,1):
        rel=str(item.get("file") or "").replace("\\","/").lstrip("/")
        if rel.startswith("../") or ".." in Path(rel).parts: raise ValueError("TUTORIAL_PATH_TRAVERSAL")
        src=(root/rel).resolve(); src.relative_to(root)
        if not src.is_file() or src.suffix.lower() not in {".mp4",".webm"}: raise ValueError(f"TUTORIAL_VIDEO_MISSING: {rel}")
        dest=f"videos/{Path(rel).name}"
        videos.append({"id":str(item.get("id") or Path(rel).stem),"title":str(item.get("title") or Path(rel).stem),
            "description":str(item.get("description") or ""),"category":str(item.get("category") or "Hướng dẫn"),
            "file":dest,"duration_seconds":int(item.get("duration_seconds") or 0),"duration":str(item.get("duration") or ""),
            "order":int(str(item.get("order") or index).lstrip("0") or 0),"_source":src})
    videos.sort(key=lambda x:x["order"])
    manifest_out={"schema_version":1,"generated_at":now_text(),"source_job_id":source_job_id,
        "mesflow_version":current_file_version(),"qa_center_version":qa_current_version(),"video_count":len(videos),
        "title":str(data.get("title") or "Hướng dẫn sử dụng MESFlow"),
        "videos":[{k:v for k,v in item.items() if k!="_source"} for item in videos]}
    manifest_out["items"]=manifest_out["videos"]
    return manifest_out,videos

def _tutorial_build_publish_tree(source,destination,source_job_id=""):
    manifest,videos=_tutorial_validate_tree(source,source_job_id); destination=Path(destination)
    if destination.exists(): shutil.rmtree(destination)
    (destination/"videos").mkdir(parents=True)
    for item in videos: shutil.copy2(item["_source"],destination/item["file"])
    save_json(destination/"manifest.json",manifest)
    _tutorial_validate_tree(destination,source_job_id)
    return manifest

def _tutorial_atomic_publish(staged,target=None):
    staged=Path(staged); target=Path(target or (TARGET_HOME/"runtime/tutorials")); parent=target.parent
    parent.mkdir(parents=True,exist_ok=True); incoming=parent/f".{target.name}.incoming-{secrets.token_hex(6)}"
    backup=parent/f".{target.name}.previous"; shutil.copytree(staged,incoming); _tutorial_validate_tree(incoming)
    # Do not rename the bind-mounted target directory itself: Docker keeps the
    # old directory inode mounted and the running MESFlow container would never
    # observe the new tutorial release.  Instead, stage and verify every video,
    # then atomically replace manifest.json last.  The manifest is the release
    # commit point, so readers can only discover a fully materialized release.
    had_target=target.exists()
    try:
        if backup.exists(): shutil.rmtree(backup)
        if had_target: shutil.copytree(target,backup)
        target.mkdir(parents=True,exist_ok=True); (target/"videos").mkdir(parents=True,exist_ok=True)
        for source in sorted((incoming/"videos").iterdir()):
            temp=target/"videos"/(f".{source.name}.incoming-{secrets.token_hex(4)}")
            shutil.copy2(source,temp); temp.replace(target/"videos"/source.name)
        manifest_temp=target/f".manifest.incoming-{secrets.token_hex(4)}.json"
        shutil.copy2(incoming/"manifest.json",manifest_temp)
        _tutorial_validate_tree(incoming)
        manifest_temp.replace(target/"manifest.json")
        wanted={p.name for p in (incoming/"videos").iterdir()}
        for old in (target/"videos").iterdir():
            if old.is_file() and old.name not in wanted: old.unlink()
        _tutorial_validate_tree(target)
    except Exception:
        if backup.exists():
            shutil.rmtree(target,ignore_errors=True); shutil.copytree(backup,target)
        elif not had_target:
            shutil.rmtree(target,ignore_errors=True)
        raise
    finally: shutil.rmtree(incoming,ignore_errors=True)
    return _tutorial_validate_tree(target)[0]

def _tutorial_create_artifact(source,job_id):
    artifact_name=f"MESFlow_Tutorials_{datetime.now():%Y%m%d_%H%M%S}.tar.zst"
    final=TUTORIAL_ARTIFACT_DIR/artifact_name; temp=final.with_suffix(final.suffix+".tmp")
    if final.exists(): raise FileExistsError("TUTORIAL_ARTIFACT_IMMUTABLE")
    with temp.open("wb") as raw, zstandard.ZstdCompressor(level=10).stream_writer(raw) as compressed:
        with tarfile.open(fileobj=compressed,mode="w|") as archive:
            archive.add(Path(source)/"manifest.json",arcname="manifest.json",recursive=False)
            for video in sorted((Path(source)/"videos").iterdir()): archive.add(video,arcname=f"videos/{video.name}",recursive=False)
    temp.replace(final); digest=sha(final)
    meta={"artifact_name":artifact_name,"artifact_path":str(final),"artifact_size":final.stat().st_size,"sha256":digest,"job_id":job_id,"created_at":now_text()}
    save_json(final.with_suffix(final.suffix+".json"),meta); return meta

def _run_tutorial_job(job_id,username,password,seed_data=True):
    log_path=LOG_DIR/f"tutorial_{datetime.now():%Y%m%d_%H%M%S}.log"
    _tutorial_update(
        job_id=job_id,status="running",stage="preparing",progress=1,message="Đang chuẩn bị xuất video hướng dẫn",
        started_at=now_text(),finished_at="",log_file=str(log_path),
        username=username,seed_data=bool(seed_data),agent_version=AGENT_VERSION,source_version=current_file_version()
    )
    seeded=False
    final_status="failed"
    final_message="Job xuất video bị dừng"
    final_stage="preparing"
    final_values={}
    try:
        if job_running():
            raise RuntimeError("MESFlow đang deploy; chờ deploy hoàn tất rồi xuất video")
        if qa_job_running():
            raise RuntimeError("QA Center đang deploy; chờ deploy hoàn tất rồi xuất video")
        if not MESFLOW_BUILD_ENABLED:
            raise RuntimeError("SERVER_VIDEO_GENERATION_DEV_ONLY: Agent này không có quyền build source")
        tutorial_source=MESFLOW_SOURCE_DIR
        if not tutorial_source.is_dir():
            raise RuntimeError(f"Không tìm thấy MESFlow source workspace: {tutorial_source}")
        if not (tutorial_source/"scripts/make-user-guide-video.sh").is_file():
            raise RuntimeError("MESFlow source chưa có scripts/make-user-guide-video.sh")
        if not (tutorial_source/"tutorial/narration").is_dir():
            raise RuntimeError("MESFlow source chưa có bộ lời thuyết minh tutorial")
        if not password:
            raise RuntimeError("Cần nhập mật khẩu tài khoản MESFlow để quay video")

        with log_path.open("w",encoding="utf-8") as log:
            log.write(f"[{now_text()}] Tutorial export requested user={username or 'admin'} seed={bool(seed_data)}\n")
            log.flush()

            _tutorial_update(job_id,stage="authenticating",progress=4,message="Đang xác minh tài khoản MESFlow")
            _tutorial_login_preflight(username,password,log)

            if seed_data:
                _tutorial_update(job_id,stage="preparing_data",progress=7,message="Đang tạo dữ liệu tutorial tạm thời")
                _tutorial_seed(log,"seed")
                seeded=True

            image="mesflow-tutorial-builder:1.62.1-v1"
            if subprocess.run(["docker","image","inspect",image],
                              stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
                _tutorial_update(job_id,stage="preparing_builder",progress=10,message="Đang chuẩn bị môi trường quay video lần đầu")
                log.write("BUILD tutorial builder image (first run only)\n");log.flush()
                r=subprocess.run(
                    ["docker","build","-t",image,"-"],
                    input=_tutorial_builder_dockerfile(),
                    text=True,stdout=log,stderr=subprocess.STDOUT,timeout=1800
                )
                if r.returncode:
                    raise RuntimeError(f"Build tutorial builder failed with code {r.returncode}")

            tutorial_candidates=[
                Path(tutorial_source),
                Path("/workspace/mesflow"),
                Path("/workspace/mesflow/mesflow"),
            ]
            tutorial_source=next(
                (p for p in tutorial_candidates if (p/"scripts/make-user-guide-video.sh").is_file()),
                None,
            )
            if tutorial_source is None:
                checked=", ".join(str(p) for p in tutorial_candidates)
                raise RuntimeError(
                    "TUTORIAL_SOURCE_SCRIPT_NOT_FOUND: scripts/make-user-guide-video.sh "
                    f"không tồn tại trong các source root đã kiểm tra: {checked}"
                )
            tutorial_host_source=_docker_host_bind_path(tutorial_source)

            tutorial_runtime=TARGET_HOME/"runtime/tutorial-builder"
            output_dir=tutorial_runtime/"output"
            workspace_dir=tutorial_runtime/"workspace"
            publish_dir=TARGET_HOME/"runtime/tutorials"
            builder_publish=TARGET_HOME/f"runtime/tutorial-staging/{job_id}/builder"
            normalized_publish=TARGET_HOME/f"runtime/tutorial-staging/{job_id}/normalized"
            for d in (tutorial_runtime,output_dir,workspace_dir,builder_publish):
                d.mkdir(parents=True,exist_ok=True)

            _tutorial_update(job_id,stage="recording",progress=12,current=0,total=TUTORIAL_TOTAL_VIDEOS,
                current_item="",message=f"Đang chuẩn bị quay {TUTORIAL_TOTAL_VIDEOS} video")
            cmd=[
                "docker","run","--rm","--name","mesflow-tutorial-builder",
                "--network","mesflow-edge",
                "-e",f"MESFLOW_TUTORIAL_USERNAME={username or 'admin'}",
                "-e","MESFLOW_TUTORIAL_PASSWORD",
                "-e","MESFLOW_TUTORIAL_SEED_DATA=0",
                "-e","MESFLOW_TUTORIAL_DATA_ALLOW_PRODUCTION=0",
                "-e","MESFLOW_TUTORIAL_WITH_VOICE=1",
                "-e","MESFLOW_TUTORIAL_AUTO_PUBLISH=1",
                "-e","MESFLOW_TUTORIAL_PUBLISH_DIR=/publish",
                "-e","MESFLOW_VIDEO_WORKSPACE=/work/workspace",
                "-e","MESFLOW_VIDEO_OUTPUT=/work/output",
                "-v",f"{tutorial_host_source}:/src/mesflow:ro",
                "-v",f"{tutorial_runtime}:/work",
                "-v",f"{builder_publish}:/publish",
                "-w","/src/mesflow",
                image,
                "bash","-lc",
                "exec bash scripts/make-user-guide-video.sh http://mesflow-app:8080"
            ]
            child_env=os.environ.copy()
            child_env["MESFLOW_TUTORIAL_PASSWORD"]=password
            log.write("RUN: docker run ... mesflow-tutorial-builder (MESFlow password hidden)\n");log.flush()
            process=subprocess.Popen(cmd,env=child_env,stdout=log,stderr=subprocess.STDOUT,text=True)
            deadline=time.time()+7200
            while process.poll() is None:
                if time.time()>deadline:
                    process.terminate();raise RuntimeError("TUTORIAL_EXPORT_TIMEOUT: builder exceeded 7200 seconds")
                log.flush();_tutorial_refresh_progress_from_log(log_path,job_id);time.sleep(1)
            return_code=process.returncode
            log.flush();_tutorial_refresh_progress_from_log(log_path,job_id)
            if return_code not in (0,3):
                hint=_tutorial_error_hint(log_path)
                detail=f": {hint}" if hint else ""
                if return_code==125 and hint and "read-only file system" in hint.lower():
                    raise RuntimeError(
                        "TUTORIAL_NESTED_READONLY_MOUNT: Docker không tạo được writable tutorial publish mount; "
                        "publish phải mount độc lập ở /publish; không bind trực tiếp vào /opt/mesflow/runtime/tutorials"
                        + detail
                    )
                raise RuntimeError(f"Tutorial builder exited with code {return_code}{detail}")
            if return_code==3:
                log.write("[WARN] Một số video thất bại sau retry; các video tạo được vẫn đã publish.\n")

            _tutorial_update(job_id,stage="verifying",progress=97,message="Đang xác minh manifest và video đã publish")
            manifest=builder_publish/"manifest.json"
            if not manifest.is_file():
                raise RuntimeError("Không tìm thấy runtime/tutorials/manifest.json sau khi quay")
            manifest_data=_tutorial_build_publish_tree(builder_publish,normalized_publish,job_id)
            _tutorial_atomic_publish(normalized_publish,publish_dir)
            artifact=_tutorial_create_artifact(normalized_publish,job_id)
            count=int(manifest_data.get("video_count") or 0)
            if count<1:
                raise RuntimeError("manifest.json chưa có video")

            final_status="completed"
            final_message=(f"Đã xuất và publish {count} video hướng dẫn"
                           if return_code==0 else
                           f"Đã publish {count} video; một số video cần xem lại log")
            final_stage="completed"
            final_values={"progress":100,"current":count,"total":count,"published_count":count,
                "manifest_status":"PASS","publish_dir":str(publish_dir),"partial_warning":return_code==3,**artifact}
    except Exception as ex:
        final_status="failed"
        final_message=str(ex)
        current=load_state().get("tutorial_job") or {};final_stage=current.get("stage") or "failed"
        code,reason,next_action=_tutorial_error_details(ex)
        final_values={"error_code":code,"error_reason":reason,"reason":reason,"next_action":next_action}
        append_log(f"Tutorial video export failed: {ex}")
    finally:
        if seeded:
            try:
                _tutorial_update(job_id,stage="cleanup",progress=99,message="Đang dọn dữ liệu tutorial tạm thời")
                with log_path.open("a",encoding="utf-8") as log:
                    _tutorial_seed(log,"cleanup")
            except Exception as cleanup_ex:
                append_log(f"Tutorial cleanup warning: {cleanup_ex}")
                if final_status=="completed":
                    final_message += f"; cảnh báo cleanup: {cleanup_ex}"
                    final_values["cleanup_warning"]=str(cleanup_ex)
        _tutorial_finish(final_status,final_message,job_id=job_id,stage=final_stage,**final_values)
        append_log(f"Tutorial video export finished: {final_status}: {final_message}")
        _tutorial_job_lock.release()

def start_tutorial_job(username,password,seed_data=True):
    if not _tutorial_job_lock.acquire(False):
        raise RuntimeError("TUTORIAL_JOB_ALREADY_RUNNING")
    job_id=f"tutorial-{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:8]}"
    created=now_text()
    def queued(state):
        state["tutorial_job"]={"job_id":job_id,"created_at":created,"started_at":"","finished_at":"",
            "updated_at":created,"status":"queued","stage":"queued","progress":0,"current":0,
            "total":TUTORIAL_TOTAL_VIDEOS,"current_item":"","message":"Đã xếp hàng xuất video",
            "username":username,"seed_data":bool(seed_data),"agent_version":AGENT_VERSION,
            "source_version":current_file_version()}
    update_state(queued)
    try:
        threading.Thread(target=_run_tutorial_job,args=(job_id,username,password,bool(seed_data)),daemon=True).start()
    except Exception:
        _tutorial_job_lock.release()
        raise
    return _tutorial_find_job(job_id)

def _tutorial_request_credentials():
    data=request.get_json(silent=True) if request.is_json else request.form
    data=data or {};username=(data.get("username") or data.get("tutorial_username") or "admin").strip() or "admin"
    return username,data.get("password") or data.get("tutorial_password") or "",bool(data.get("seed_data",data.get("tutorial_seed_data")=="1"))

@app.post("/api/tutorial/check-login")
def api_tutorial_check_login():
    verify_csrf()
    if not MESFLOW_BUILD_ENABLED:
        return jsonify(ok=False,authenticated=False,code="SERVER_VIDEO_GENERATION_DEV_ONLY",status=403,
            reason="Chỉ DEV Agent có source-build capability mới được tạo video",next_action="Mở DEV Agent để xuất video"),403
    username,password,_seed_data=_tutorial_request_credentials()
    if not password:
        return jsonify(ok=False,authenticated=False,code="TUTORIAL_AUTH_REQUIRED",status=400,
            reason="Chưa nhập mật khẩu",next_action="Nhập username/password"),400
    try:
        # Memory-only buffer: login checks never create a persistent credential log.
        _tutorial_login_preflight(username,password,io.StringIO())
        return jsonify(ok=True,authenticated=True,username=username,status=200,
            message="Đăng nhập MESFlow thành công")
    except TutorialAuthError as ex:
        return jsonify(ok=False,authenticated=False,code="TUTORIAL_AUTH_FAILED",status=ex.status,
            reason="Sai username/password",next_action="Kiểm tra username/password"),ex.status
    except Exception as ex:
        return jsonify(ok=False,authenticated=False,code="TUTORIAL_AUTH_CHECK_FAILED",status=502,
            reason=str(ex),next_action="Kiểm tra kết nối MESFlow rồi thử lại"),502

@app.post("/tutorial/check-login")
def tutorial_check_login():
    return api_tutorial_check_login()

@app.post("/api/tutorial/export")
def api_tutorial_export():
    verify_csrf()
    if not MESFLOW_BUILD_ENABLED:
        return jsonify(ok=False,code="SERVER_VIDEO_GENERATION_DEV_ONLY"),403
    username,password,seed_data=_tutorial_request_credentials()
    if not password:
        return jsonify(ok=False,code="TUTORIAL_AUTH_REQUIRED",reason="Chưa nhập mật khẩu",
            next_action="Nhập username/password và kiểm tra đăng nhập"),400
    if tutorial_job_running():
        existing=_tutorial_find_job("current") or {}
        return jsonify(ok=False,code="TUTORIAL_JOB_ALREADY_RUNNING",reason="Đang có job xuất video",
            existing_job_id=existing.get("job_id"),job=_tutorial_public_job(existing,False)),409
    try:
        job=start_tutorial_job(username,password,seed_data)
        return jsonify(ok=True,job_id=job.get("job_id"),status="queued",job=_tutorial_public_job(job,False)),202
    except RuntimeError as ex:
        if str(ex)=="TUTORIAL_JOB_ALREADY_RUNNING":
            existing=_tutorial_find_job("current") or {}
            return jsonify(ok=False,code=str(ex),existing_job_id=existing.get("job_id"),
                job=_tutorial_public_job(existing,False)),409
        return jsonify(ok=False,code="TUTORIAL_START_FAILED",reason=str(ex)),409

@app.post("/tutorial/rebuild")
def tutorial_rebuild():
    verify_csrf()
    if not MESFLOW_BUILD_ENABLED:
        return jsonify(ok=False,error="SERVER_VIDEO_GENERATION_DEV_ONLY",message="Chỉ DEV Agent có source-build capability mới được tạo video"),403
    try:
        username=(request.form.get("tutorial_username") or "admin").strip() or "admin"
        password=request.form.get("tutorial_password") or ""
        seed_data=request.form.get("tutorial_seed_data")=="1"
        start_tutorial_job(username,password,seed_data)
        flash("Đã bắt đầu xuất lại video hướng dẫn. Màn hình theo dõi sẽ hiển thị tiến độ và log trực tiếp.","success")
        return redirect(url_for("tutorial_monitor"))
    except Exception as ex:
        flash(f"Không thể xuất video hướng dẫn: {ex}","error")
    return redirect(url_for("tutorial_monitor"))

@app.get("/api/tutorial/job/<job_id>")
def api_tutorial_job(job_id):
    job=_tutorial_find_job(job_id)
    if job is None:return jsonify(ok=False,code="TUTORIAL_JOB_NOT_FOUND"),404
    return jsonify(ok=True,job=_tutorial_public_job(job,True))

@app.get("/api/tutorial/artifact/<job_id>")
def api_tutorial_artifact(job_id):
    job=_tutorial_find_job(job_id)
    if not job: return jsonify(ok=False,error="TUTORIAL_JOB_NOT_FOUND"),404
    path=Path(str(job.get("artifact_path") or "")); valid=path.is_file() and bool(job.get("sha256")) and sha(path)==job.get("sha256")
    return jsonify(ok=True,artifact={k:job.get(k) for k in ("artifact_name","artifact_size","sha256","publish_dir")},valid=valid,status=job.get("status"))

def _run_tutorial_promote(job_id):
    stage="PRECHECK"; started=time.time()
    def update(status,message,**extra):
        def mutate(state): state["tutorial_promote"]={**(state.get("tutorial_promote") or {}),"job_id":job_id,"status":status,"stage":extra.pop("stage",stage),"message":message,"updated_at":now_text(),"elapsed_seconds":int(time.time()-started),**extra}
        return update_state(mutate).get("tutorial_promote")
    try:
        source=_tutorial_find_job(job_id)
        if not source or source.get("status")!="completed": raise _RemoteAgentError("TUTORIAL_JOB_NOT_COMPLETED")
        artifact=Path(str(source.get("artifact_path") or ""))
        if not artifact.is_file() or sha(artifact)!=source.get("sha256"): raise _RemoteAgentError("TUTORIAL_ARTIFACT_DIGEST_INVALID")
        url,user,password=_production_test_target()
        if not url or not password: raise _RemoteAgentError("PRODUCTION_TEST_AGENT_NOT_CONFIGURED")
        stage="AUTHENTICATING"; update("VERIFYING","Đang xác thực Production Test",stage=stage,artifact_name=artifact.name,sha256=source["sha256"])
        opener,base,csrf=_remote_agent_client(url,user,password,timeout=45); target=_remote_agent_status(opener,base)
        compat=_agent_compatibility(target,TUTORIAL_REQUIRED_CAPABILITIES)
        if compat["status"]=="INCOMPATIBLE": raise _RemoteAgentError(f"TARGET_AGENT_INCOMPATIBLE: {compat['reason']}")
        if target.get("server_role")!="PRODUCTION_TEST": raise _RemoteAgentError("TUTORIAL_TARGET_ROLE_BLOCKED")
        stage="UPLOADING"
        def progress(sent,total,chunks): update("UPLOADING",f"Đã upload {chunks} chunks",stage=stage,uploaded_chunks=chunks,uploaded_bytes=sent,total_bytes=total,total_chunks=(total+QA_CHUNK_BYTES-1)//QA_CHUNK_BYTES,last_activity=now_text(),target_capabilities=target.get("capabilities") or [])
        result=_remote_agent_tutorial_upload(opener,base,csrf,artifact,progress)
        if not result.get("ok") or result.get("sha256")!=source["sha256"]: raise _RemoteAgentError(f"TUTORIAL_REMOTE_VERIFY_FAILED: {result}")
        stage="VERIFYING"; remote=_remote_agent_get_json(opener,base,"/api/tutorial-release/status")
        if (remote.get("tutorial") or {}).get("sha256")!=source["sha256"]: raise _RemoteAgentError("TUTORIAL_REMOTE_STATUS_DIGEST_MISMATCH")
        update("DEPLOYED","Tutorial đã deploy và verify trên Production Test",stage="DEPLOYED",finished_at=now_text(),sha256=source["sha256"],target_url=url)
    except Exception as ex:
        update("FAILED",str(ex),stage=stage,finished_at=now_text(),exact_exception=f"{type(ex).__name__}: {ex}")

@app.post("/api/tutorial/promote-test/<job_id>")
def api_tutorial_promote_test(job_id):
    verify_csrf()
    if SERVER_ROLE=="PRODUCTION": return jsonify(ok=False,error="TUTORIAL_PRODUCTION_DEPLOY_BLOCKED"),403
    current=load_state().get("tutorial_promote") or {}
    if current.get("status") in {"UPLOADING","VERIFYING","PUBLISHING"}: return jsonify(ok=False,error="TUTORIAL_PROMOTION_ALREADY_RUNNING"),409
    threading.Thread(target=_run_tutorial_promote,args=(job_id,),daemon=True).start()
    return jsonify(ok=True,status="QUEUED",job_id=job_id),202

@app.get("/api/tutorial/promote-status")
def api_tutorial_promote_status(): return jsonify(ok=True,promotion=load_state().get("tutorial_promote") or {"status":"NOT_DEPLOYED"})

@app.get("/tutorial/monitor")
def tutorial_monitor():
    st=load_state();raw=st.get("tutorial_job") or {};job=raw if _tutorial_job_is_current(raw) else {}
    return render_template("tutorial_monitor.html",page_key="releases",csrf=session.get("csrf",""),
        agent_version=AGENT_VERSION,server_role=SERVER_ROLE,tutorial_job=job,
        tutorial_history=(st.get("tutorial_history") or [])[:10],
        tutorial_log=_tutorial_log_tail(job.get("log_file")),
        tutorial_publish_dir=str(TARGET_HOME/"runtime/tutorials"))

@app.get("/tutorial/events")
def tutorial_events():
    """One lightweight SSE stream for the dedicated tutorial monitor.

    The Release page does not poll this route.  The monitor opens one HTTP
    stream and incrementally follows only the current tutorial log/state, so it
    cannot trigger Docker/health/release-summary work on the Agent.  The stream
    closes automatically when the job leaves RUNNING.
    """
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    @stream_with_context
    def generate():
        last_status_sig="";last_size=-1;idle=0
        yield "retry: 3000\n\n"
        while idle<14400:
            st=load_state();job=st.get("tutorial_job") or {}
            path=_tutorial_safe_log_path(job.get("log_file"))
            try:size=path.stat().st_size if path and path.is_file() else 0
            except OSError:size=0
            status_payload=_tutorial_public_job(job,False)
            sig=json.dumps(status_payload,sort_keys=True,ensure_ascii=False)
            changed=sig!=last_status_sig or size!=last_size
            if changed:
                payload=dict(status_payload,log=_tutorial_log_tail(job.get("log_file")))
                yield "event: tutorial\ndata: "+json.dumps(payload,ensure_ascii=False)+"\n\n"
                last_status_sig=sig;last_size=size;idle=0
            else:
                idle+=1
                if idle%15==0: yield ": keepalive\n\n"
            if job and job.get("status") not in TUTORIAL_ACTIVE_STATUSES: break
            time.sleep(1)
    return Response(generate(),mimetype="text/event-stream",headers={
        "Cache-Control":"no-cache, no-transform","X-Accel-Buffering":"no","Connection":"keep-alive"})

ESP_TUTORIAL_STAGES=("uploading","validating","validating_manifest","staging","backing_up","publishing","verifying","success","failed")

def esp_tutorial_status():
    manifest=load_json(ESP_TUTORIAL_HOME/"manifest.json",{})
    version="Chưa publish"
    try:
        if (ESP_TUTORIAL_HOME/"VERSION.txt").is_file():
            version=(ESP_TUTORIAL_HOME/"VERSION.txt").read_text(encoding="utf-8-sig").strip()
    except OSError: pass
    videos=manifest.get("videos") if isinstance(manifest,dict) else []
    valid=(version!="Chưa publish" and isinstance(manifest,dict) and manifest.get("type")=="esp-kiosk-tutorial" and manifest.get("tutorial_version")==version and isinstance(videos,list) and bool(videos))
    previous=""
    backups=ESP_TUTORIAL_HOME.parent/"backups"
    if backups.is_dir():
        candidates=sorted((p for p in backups.glob("esp-kiosk-*") if p.is_dir()),key=lambda p:p.stat().st_mtime,reverse=True)
        if candidates:
            try: previous=(candidates[0]/"VERSION.txt").read_text(encoding="utf-8-sig").strip()
            except OSError: pass
    publish=load_state().get("esp_tutorial_publish") or {}
    return {"published":version!="Chưa publish","tutorial_version":version,
            "firmware_version":manifest.get("firmware_version","") if isinstance(manifest,dict) else "",
            "video_count":len(videos) if isinstance(videos,list) else 0,
            "generated_at":manifest.get("generated_at","") if isinstance(manifest,dict) else "",
            "published_at":display_datetime((publish.get("published_at","") or manifest.get("generated_at","")) if isinstance(manifest,dict) else ""),
            "audio":manifest.get("audio") if isinstance(manifest,dict) else None,
            "package_status":"ready" if valid else "invalid" if version!="Chưa publish" else "missing",
            "previous_version":previous,
            "path":str(ESP_TUTORIAL_HOME)}

def _esp_tutorial_job(status,message,**extra):
    def mutate(state):
        job=dict(state.get("esp_tutorial_job") or {})
        job.update(status=status,message=message,updated_at=now_text(),**extra)
        transitions=list(job.get("transitions") or [])
        if not transitions or transitions[-1].get("status")!=status:
            transitions.append({"status":status,"at":now_text(),"message":message})
        job["transitions"]=transitions;state["esp_tutorial_job"]=job
    return update_state(mutate).get("esp_tutorial_job")

def validate_esp_tutorial_zip(zip_path,extract_dir):
    zip_path=Path(zip_path);extract_dir=Path(extract_dir)
    if zip_path.stat().st_size>ESP_TUTORIAL_MAX_MB*1024*1024:
        raise ValueError(f"ZIP vượt giới hạn {ESP_TUTORIAL_MAX_MB} MB")
    with zipfile.ZipFile(zip_path) as archive:
        entries=archive.infolist()
        if not entries: raise ValueError("ZIP rỗng")
        total=sum(max(0,item.file_size) for item in entries)
        if total>ESP_TUTORIAL_MAX_MB*1024*1024: raise ValueError("ZIP giải nén vượt giới hạn")
        roots=set()
        for item in entries:
            name=item.filename.replace("\\","/")
            if not name or name.startswith("/") or ".." in Path(name).parts:
                raise ValueError("ZIP chứa đường dẫn không an toàn")
            roots.add(name.split("/",1)[0])
            mode=(item.external_attr>>16)&0o170000
            if not item.is_dir() and mode and mode!=0o100000:
                raise ValueError("ZIP chứa symlink hoặc file đặc biệt")
            target=(extract_dir/name).resolve()
            if extract_dir.resolve() not in target.parents and target!=extract_dir.resolve():
                raise ValueError("ZIP chứa path traversal")
        if roots!={"esp-kiosk-tutorial"}: raise ValueError("ZIP phải có đúng một root esp-kiosk-tutorial")
        archive.extractall(extract_dir)
    root=extract_dir/"esp-kiosk-tutorial"
    version_path=root/"VERSION.txt";manifest_path=root/"manifest.json"
    if not version_path.is_file() or not manifest_path.is_file():
        raise ValueError("Package thiếu VERSION.txt hoặc manifest.json")
    version=norm(version_path.read_text(encoding="utf-8-sig"))
    try: manifest=json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as ex: raise ValueError(f"manifest.json không hợp lệ: {ex.msg}") from ex
    if not isinstance(manifest,dict) or manifest.get("type")!="esp-kiosk-tutorial":
        raise ValueError("manifest.type phải là esp-kiosk-tutorial")
    if str(manifest.get("tutorial_version","")).strip()!=version:
        raise ValueError("tutorial_version không khớp VERSION.txt")
    videos=manifest.get("videos")
    if not isinstance(videos,list) or not videos: raise ValueError("manifest không có video")
    filenames=[]
    for video in videos:
        if not isinstance(video,dict): raise ValueError("Video manifest không hợp lệ")
        required={"id","filename","title","description","order","cases"}
        if not required.issubset(video):
            raise ValueError("Video manifest thiếu id/title/description/order/cases")
        if not str(video.get("id","")).strip() or not str(video.get("title","")).strip():
            raise ValueError("Video manifest có id hoặc title rỗng")
        if not isinstance(video.get("order"),int) or not isinstance(video.get("cases"),list):
            raise ValueError("Video manifest có order hoặc cases không hợp lệ")
        filename=str(video.get("filename","")).strip()
        if not filename or Path(filename).name!=filename or not filename.lower().endswith(".mp4"):
            raise ValueError("Tên video không hợp lệ")
        if filename in filenames: raise ValueError("Tên video bị trùng")
        filenames.append(filename)
        path=root/"videos"/filename
        if not path.is_file() or path.stat().st_size<=0: raise ValueError(f"Video thiếu hoặc rỗng: {filename}")
    root_files={p.name for p in root.iterdir() if p.is_file()}
    video_dir=root/"videos"
    actual={p.name for p in video_dir.iterdir() if p.is_file()} if video_dir.is_dir() else set()
    if root_files!={"VERSION.txt","manifest.json"} or {p.name for p in root.iterdir() if p.is_dir()}!={"videos"} or actual!=set(filenames) or any(p.is_dir() for p in video_dir.iterdir()):
        raise ValueError("Package chứa file hoặc thư mục ngoài contract")
    return root,version,manifest

def publish_esp_tutorial(zip_path,source_name):
    if not _esp_tutorial_job_lock.acquire(False): raise RuntimeError("Đang publish video ESP Kiosk")
    package_hash=sha(Path(zip_path));started=now_text();backup_path=None;publish_temp=None
    try:
        _esp_tutorial_job("uploading","Đã nhận ZIP",source_name=source_name,package_sha256=package_hash,started_at=started)
        with tempfile.TemporaryDirectory(prefix="esp-kiosk-tutorial-") as temp:
            extract=Path(temp)/"extract";extract.mkdir()
            _esp_tutorial_job("validating","Đang kiểm tra package")
            root,version,manifest=validate_esp_tutorial_zip(zip_path,extract)
            _esp_tutorial_job("validating_manifest","Manifest hợp lệ",tutorial_version=version)
            previous=load_state().get("esp_tutorial_publish") or {}
            current_version=(ESP_TUTORIAL_HOME/"VERSION.txt").read_text(encoding="utf-8-sig").strip() if (ESP_TUTORIAL_HOME/"VERSION.txt").is_file() else ""
            if current_version==version:
                same=(ESP_TUTORIAL_HOME/"manifest.json").is_file() and (ESP_TUTORIAL_HOME/"manifest.json").read_bytes()==(root/"manifest.json").read_bytes()
                same=same and all((ESP_TUTORIAL_HOME/"videos"/video["filename"]).is_file() and (ESP_TUTORIAL_HOME/"videos"/video["filename"]).read_bytes()==(root/"videos"/video["filename"]).read_bytes() for video in manifest["videos"])
                if not same: raise ValueError(f"Tutorial {version} đã tồn tại với nội dung khác; hãy tăng version")
                _esp_tutorial_job("success",f"Tutorial {version} đã publish với cùng nội dung")
                return version
            _esp_tutorial_job("staging","Đang chuẩn bị cấu trúc publish",tutorial_version=version)
            parent=ESP_TUTORIAL_HOME.parent;parent.mkdir(parents=True,exist_ok=True)
            publish_temp=parent/f".esp-kiosk-publish-{uuid.uuid4().hex}"
            (publish_temp/"videos").mkdir(parents=True)
            shutil.copy2(root/"VERSION.txt",publish_temp/"VERSION.txt")
            shutil.copy2(root/"manifest.json",publish_temp/"manifest.json")
            for video in manifest["videos"]: shutil.copy2(root/"videos"/video["filename"],publish_temp/"videos"/video["filename"])
            _esp_tutorial_job("backing_up","Đang backup tutorial hiện tại")
            if ESP_TUTORIAL_HOME.exists():
                old_version=(ESP_TUTORIAL_HOME/"VERSION.txt").read_text(encoding="utf-8-sig").strip() if (ESP_TUTORIAL_HOME/"VERSION.txt").is_file() else "unknown"
                backups=parent/"backups";backups.mkdir(exist_ok=True)
                backup_path=backups/f"esp-kiosk-{old_version}"
                if backup_path.exists(): shutil.rmtree(backup_path)
                ESP_TUTORIAL_HOME.replace(backup_path)
            _esp_tutorial_job("publishing","Đang chuyển bộ tutorial mới vào runtime")
            publish_temp.replace(ESP_TUTORIAL_HOME);publish_temp=None
            _esp_tutorial_job("verifying","Đang xác minh manifest và video")
            published=load_json(ESP_TUTORIAL_HOME/"manifest.json",{})
            if published.get("tutorial_version")!=version: raise RuntimeError("Version verify thất bại")
            for video in manifest["videos"]:
                if not (ESP_TUTORIAL_HOME/"videos"/video["filename"]).is_file(): raise RuntimeError("Video verify thất bại")
            backups_dir=parent/"backups"
            if backups_dir.is_dir():
                old=sorted((p for p in backups_dir.glob("esp-kiosk-*") if p.is_dir()),key=lambda p:p.stat().st_mtime,reverse=True)
                for stale in old[1:]: shutil.rmtree(stale)
            def done(state):
                state["esp_tutorial_publish"]={"tutorial_version":version,"package_sha256":package_hash,"published_at":now_text()}
                history=list(state.get("esp_tutorial_history") or []);history.insert(0,{"version":version,"status":"success","published_at":now_text()});state["esp_tutorial_history"]=history[:20]
            update_state(done);_esp_tutorial_job("success",f"Đã publish tutorial {version}")
            append_log(f"ESP tutorial publish success version={version} videos={len(manifest['videos'])}")
            return version
    except Exception as ex:
        if backup_path and backup_path.exists():
            if ESP_TUTORIAL_HOME.exists(): shutil.rmtree(ESP_TUTORIAL_HOME)
            backup_path.replace(ESP_TUTORIAL_HOME)
        if publish_temp and publish_temp.exists(): shutil.rmtree(publish_temp)
        _esp_tutorial_job("failed",f"{type(ex).__name__}: {ex}")
        append_log(f"ESP tutorial publish failed stage={load_state().get('esp_tutorial_job',{}).get('status')} exception={type(ex).__name__} error={ex}")
        raise
    finally:_esp_tutorial_job_lock.release()

@app.post("/esp-kiosk-tutorial/upload")
def esp_tutorial_upload():
    # Redirect target moved from the Release page's #espTutorialCard anchor
    # to the dedicated ESP Kiosk Tutorial page (task: ESP_KIOSK_UI_SEPARATION).
    verify_csrf();upload=request.files.get("tutorial_zip")
    if not upload or not upload.filename: flash("Hãy chọn ZIP tutorial ESP Kiosk","error");return redirect(url_for("kiosk_tutorial_page"))
    if not upload.filename.lower().endswith(".zip"): flash("Chỉ chấp nhận file ZIP","error");return redirect(url_for("kiosk_tutorial_page"))
    saved=ESP_TUTORIAL_UPLOAD_DIR/f"{uuid.uuid4().hex}_{secure_filename(upload.filename)}"
    try:
        upload.save(saved);version=publish_esp_tutorial(saved,upload.filename);flash(f"Đã publish video ESP Kiosk {version}","success")
    except Exception as ex: flash(f"Publish video ESP Kiosk thất bại: {ex}","error")
    finally:
        try:saved.unlink(missing_ok=True)
        except OSError:pass
    return redirect(url_for("kiosk_tutorial_page"))

def _console_context():
    """Overview (dashboard.html) only -- trimmed to exactly what that
    template uses (task section 51: don't pay for release_summary/
    qa_release_summary/deployment_platform/target_agents lookups on a page
    that never renders them; those now live only in their own tab context
    builders). Previously this computed the full Release & Deploy page's
    entire dataset on every Overview load too."""
    st=load_state()
    return dict(mes=mes_status(),qa=qa_status(),history=st.get("history",[]),
        server_role=SERVER_ROLE,csrf=session.get("csrf",""),agent_version=AGENT_VERSION)

@app.get("/")
def index():
    return render_template("dashboard.html",page_key="overview",**_console_context())

def _release_deploy_tab_context():
    """Release Deploy tab: current release + pipeline + next action only --
    never the full deployment history (that is its own tab, loaded lazily
    client-side) and never Agent Update's target list (also its own tab)."""
    st=load_state();j=st.get("job")
    # Release page must stay cheap. Do not tail deployment/build log files on
    # every page render; long-running jobs are monitored through the lightweight
    # live-status endpoint below, and logs are read only when the operator
    # explicitly opens a log viewer. The job may still contain a persisted
    # log_tail captured at completion, which is safe to render without I/O.
    qldj=st.get("qa_local_deploy_job")
    ptj=st.get("promote_test_job"); qptj=st.get("qa_promote_test_job")
    host=(request.host or "localhost").split(":",1)[0]
    # Release Tab Performance Fix follow-up (reports/
    # DEPLOY_AGENT_REFRESH_PERFORMANCE_FIX.md): compute each of these
    # exactly ONCE per page load and pass them into
    # _deployment_platform_summary() -- it used to silently recompute all
    # four itself (a second Docker inspect round for MESFlow/QA, a second
    # QA network probe, and a second SHA256 hash of both release ZIPs,
    # which are real 70-500+MB artifacts), doubling the cost of every
    # single Release & Deploy page load for no reason.
    mes=mes_status();qa=qa_status()
    release_summary=_release_summary();qa_release_summary=_qa_release_summary()
    # ESP Firmware Builder / ESP Tutorial moved to their own pages under
    # /kiosk/* (task: ESP_KIOSK_UI_SEPARATION) -- this tab must never again
    # pay for esp_tutorial_status()'s file I/O (manifest.json/VERSION.txt
    # reads + a backups directory scan) just to render the Release page.
    tutorial_raw=st.get("tutorial_job") or {}
    tutorial_current=tutorial_raw if _tutorial_job_is_current(tutorial_raw) else {}
    return dict(job=j,qa_local_deploy_job=qldj,promote_test_job=ptj,qa_promote_test_job=qptj,
        release_build_job=st.get("release_build_job"),version_bump=st.get("version_bump"),
        qa_release_build_job=st.get("qa_release_build_job"),qa_version_bump=st.get("qa_version_bump"),
        release_summary=release_summary,qa_release_summary=qa_release_summary,
        deployment_platform=_deployment_platform_summary(mes=mes,qa=qa,mes_release=release_summary,qa_release=qa_release_summary),
        mes=mes,qa=qa,
        qa_open_url=f"http://{host}:{QA_PORT}/",qa_log="",
        tutorial_job=tutorial_current,tutorial_history=(st.get("tutorial_history") or [])[:10],
        tutorial_publish_dir=str(TARGET_HOME/"runtime/tutorials"),
        qa_promote_preflight=st.get("qa_promote_test_preflight"),system_issues=_release_system_issues(st),
        mes_build_enabled=MESFLOW_BUILD_ENABLED)

def _deployment_history_tab_context():
    """Deployment History tab: no server-rendered data at all -- the table
    is populated by the client from /api/release-manager/history (paginated,
    filterable), so opening this tab never pays for release_summary/
    deployment_platform/target_agents lookups it doesn't need."""
    return dict()

def _agent_update_tab_context():
    """Agent Update tab: target Agents + this tab's own job/history only.
    Keep the package destination explicit so the operator always knows which
    immutable ZIP Bootstrap should install.
    """
    version_file=DEPLOY_AGENT_SOURCE_DIR/"VERSION.txt"
    source_version=version_file.read_text(encoding="utf-8-sig").strip() if version_file.is_file() else ""
    host=(request.host or "localhost").split(":",1)[0]
    return dict(target_agents=load_json(CONFIG_DIR/"target-agents.json",{}),
        agent_update_job=load_state().get("agent_update_job"),mes_build_enabled=MESFLOW_BUILD_ENABLED,
        latest_agent_release=_latest_agent_release(),
        agent_package_build_job=load_state().get("agent_package_build_job"),
        agent_version_bump=load_state().get("agent_version_bump"),
        agent_source_version=source_version,
        bootstrap_open_url=f"http://{host}:8098/")

# ---------------- ESP Kiosk (task: ESP_KIOSK_UI_SEPARATION) ----------------
# Firmware Builder and Tutorial used to live inside the Release & Deploy
# page as collapsed <details> cards. They are their own module now, mirroring
# the RELEASE_TABS pattern above -- each tab's context builder reuses the
# existing esp_tutorial_status()/ESP_BUILD_ENABLED/ota.* backend helpers
# (nothing duplicated), and none of them touch MESFlow/QA release data.
def _kiosk_overview_context():
    """Overview tab: cheap summary only. Device counts are fetched
    client-side from the existing /api/esp-ota/devices endpoint (which
    already reaches out to MESFlow) -- never computed here on page load."""
    return dict(esp_tutorial=esp_tutorial_status(),esp_builder_job=load_state().get("esp_builder_job"),
        esp_build_enabled=ESP_BUILD_ENABLED)

def _kiosk_ota_context():
    """OTA tab: device fleet + jobs are loaded client-side via the existing
    /api/esp-ota/* endpoints (unchanged) -- no server-rendered data here."""
    return dict()

def _kiosk_firmware_context():
    """Firmware tab: build job + recently registered artifacts only -- never
    MESFlow/QA release summaries, deployment_platform, or promotion checks
    (those stay on the Release & Deploy page)."""
    items=ota.list_firmware(limit=10)
    for item in items:
        try:item["created_at_display"]=datetime.fromtimestamp(float(item.get("created_at") or 0)).strftime("%d/%m/%Y %H:%M")
        except (TypeError,ValueError,OSError):item["created_at_display"]=""
    return dict(esp_builder_job=load_state().get("esp_builder_job"),esp_build_enabled=ESP_BUILD_ENABLED,
        esp_kiosk_source=str(ESP_KIOSK_SOURCE_DIR),firmware_items=items)

def _kiosk_tutorial_context():
    """Tutorial tab: ESP Kiosk tutorial package status + upload job only --
    no MESFlow release data, no release polling, no Docker/log reads."""
    st=load_state()
    return dict(esp_tutorial=esp_tutorial_status(),esp_tutorial_job=st.get("esp_tutorial_job"),
        tutorial_job=st.get("tutorial_job"),tutorial_history=(st.get("tutorial_history") or [])[:5],
        esp_tutorial_view_url=(os.environ.get("WORKSHOP_MES_PUBLIC_URL") or "").rstrip("/")+"/app?guide=esp-kiosk" if os.environ.get("WORKSHOP_MES_PUBLIC_URL") else "/app?guide=esp-kiosk")

KIOSK_TABS={"overview":("kiosk/_overview_tab.html",_kiosk_overview_context),
            "ota":("kiosk/_ota_tab.html",_kiosk_ota_context),
            "firmware":("kiosk/_firmware_tab.html",_kiosk_firmware_context),
            "tutorial":("kiosk/_tutorial_tab.html",_kiosk_tutorial_context)}

def _kiosk_render(tab):
    partial,build_ctx=KIOSK_TABS[tab]
    return render_template("kiosk/index.html",page_key="kiosk",active_tab=tab,tab_partial=partial,
        csrf=session.get("csrf",""),agent_version=AGENT_VERSION,server_role=SERVER_ROLE,**build_ctx())

@app.get("/kiosk")
def kiosk_overview_page():
    return _kiosk_render("overview")

@app.get("/kiosk/ota")
def kiosk_ota_page():
    # Same auth convention as the old /ota page it replaces: a normal login
    # session OR the OTA admin bearer token (automated dashboards), not a
    # plain redirect-to-login -- see _ota_admin_required().
    gate=_ota_admin_required()
    if gate:return gate
    return _kiosk_render("ota")

@app.get("/kiosk/firmware")
def kiosk_firmware_page():
    return _kiosk_render("firmware")

@app.get("/kiosk/tutorial")
def kiosk_tutorial_page():
    return _kiosk_render("tutorial")

def _release_guide_tab_context():
    """Hướng dẫn (Guide) tab: static runbook content plus a handful of
    cheap, already-in-process facts (env var presence only -- no Docker/
    network calls, unlike the Deploy tab's summaries) so the guide can show
    real "configured / not configured" status next to each instruction
    instead of generic prose that goes stale the moment the operator reads
    it. Mirrors docs/operations/DEPLOY_RUNBOOK.html in the workspace, kept
    intentionally shorter -- this tab covers only what this Agent instance
    itself needs answered, the full runbook covers every project."""
    def configured(*names):
        return all((os.environ.get(n) or "").strip() for n in names)
    return dict(
        guide_test_target_configured=configured("MESFLOW_PRODUCTION_TEST_AGENT_URL","MESFLOW_PRODUCTION_TEST_AGENT_USER","MESFLOW_PRODUCTION_TEST_AGENT_PASSWORD"),
        guide_test_target_url=(os.environ.get("MESFLOW_PRODUCTION_TEST_AGENT_URL") or "").strip(),
        guide_prod_target_configured=configured("MESFLOW_PRODUCTION_AGENT_URL","MESFLOW_PRODUCTION_AGENT_USER","MESFLOW_PRODUCTION_AGENT_PASSWORD"),
        guide_prod_target_url=(os.environ.get("MESFLOW_PRODUCTION_AGENT_URL") or "").strip(),
        guide_prod_promote_enabled=os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() in {"1","true","yes","on"},
    )

RELEASE_TABS={"deploy":("release/_deploy_tab.html",_release_deploy_tab_context),
              "history":("release/_history_tab.html",_deployment_history_tab_context),
              "agent-update":("release/_agent_update_tab.html",_agent_update_tab_context),
              "guide":("release/_guide_tab.html",_release_guide_tab_context)}

@app.get("/releases")
def release_manager_page():
    tab=request.args.get("tab","deploy")
    # Back-compat: the old ESP Kiosk sidebar links ("ESP Kiosk · Firmware" /
    # "· Hướng dẫn") used to point here with tab=deploy plus a `section=`
    # param that pre-opened a <details> card on this same page. Both cards
    # moved to their own pages (task: ESP_KIOSK_UI_SEPARATION) -- redirect
    # any old bookmark/link there instead of rendering a page that no
    # longer has that section.
    section=request.args.get("section")
    if tab=="deploy" and section=="esp-builder": return redirect(url_for("kiosk_firmware_page"))
    if tab=="deploy" and section=="esp-tutorial": return redirect(url_for("kiosk_tutorial_page"))
    if tab not in RELEASE_TABS: tab="deploy"
    partial,build_ctx=RELEASE_TABS[tab]
    return render_template("release/index.html",page_key="releases",active_tab=tab,tab_partial=partial,
        csrf=session.get("csrf",""),agent_version=AGENT_VERSION,server_role=SERVER_ROLE,**build_ctx())
def _release_live_status_payload():
    """Cheap Release tab polling payload.

    Deliberately reads only the small persisted state file. It must not call
    release summaries, Docker/health probes, deployment-platform scans, or
    tail any log file. This keeps the Release tab responsive while a job runs.
    """
    st=load_state()
    keys=(
        "job", "qa_local_deploy_job", "promote_test_job",
        "qa_promote_test_job", "release_build_job", "qa_release_build_job",
        "esp_builder_job", "esp_tutorial_job", "tutorial_job",
        # Agent Update tab follow-up (reports/
        # DEPLOY_AGENT_REFRESH_PERFORMANCE_FIX.md): tracked here too so
        # that tab can reuse this SAME lightweight endpoint instead of its
        # previous unconditional full-page-reload-every-3-seconds loop.
        "agent_update_job",
        # Build Agent Package (task: AGENT_PACKAGE_BUILD_PUSH): same
        # lightweight endpoint, same convention -- no second poller.
        "agent_package_build_job",
    )
    jobs={}
    for key in keys:
        raw=st.get(key) or {}
        jobs[key]={
            "status":raw.get("status",""),
            "message":raw.get("message",""),
            "updated_at":raw.get("updated_at",raw.get("finished_at","")),
        } if raw else {}
    active_statuses={"queued","uploading","validating","building","deploying","verifying","QUEUED","UPLOADING","VALIDATING","BUILDING","DEPLOYING","VERIFYING",
        # Agent Update's own status vocabulary (see release_manager_update_agent).
        "UPDATING","PUSHING"}
    active=any((job.get("status") in active_statuses) for job in jobs.values() if job)
    return {"ok":True,"active":active,"jobs":jobs,"server_time":now_text()}

@app.get("/api/release-manager/live-status")
def release_manager_live_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(_release_live_status_payload())

@app.get("/api/status")
def api_status():return jsonify({"agent_id":_agent_instance_id(),"agent_version":AGENT_VERSION,"frontend_build_id":FRONTEND_BUILD_ID,"api_protocol_version":API_PROTOCOL_VERSION,"capabilities":AGENT_CAPABILITIES,"runtime_mode":RUNTIME_MODE,"server_role":SERVER_ROLE,"build_enabled":MESFLOW_BUILD_ENABLED,"source_dir":str(MESFLOW_SOURCE_DIR),"deploy_enabled":DEPLOY_ENABLED,"host_ops_enabled":HOST_OPS_ENABLED,"mes":mes_status(),"qa":qa_status(),"job":load_state().get("job"),"qa_job":load_state().get("qa_job"),"qa_image_deploy_job":load_state().get("qa_image_deploy_job"),"tutorial_job":load_state().get("tutorial_job"),"esp_tutorial":esp_tutorial_status(),"esp_tutorial_job":load_state().get("esp_tutorial_job"),"release_build":load_state().get("release_build_job"),"promote_test_job":load_state().get("promote_test_job"),"qa_release_build_job":load_state().get("qa_release_build_job"),"qa_local_deploy_job":load_state().get("qa_local_deploy_job"),"qa_promote_test_job":load_state().get("qa_promote_test_job"),"agent_update_job":load_state().get("agent_update_job"),"release_summary":_release_summary()})

@app.get("/api/release-manager")
def release_manager():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,enabled=MESFLOW_BUILD_ENABLED,summary=_release_summary(),job=load_state().get("release_build_job"))

@app.get("/api/deployment-platform")
def deployment_platform_api():
    if not logged_in():return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,**_deployment_platform_summary())

@app.get("/api/deployment-platform/deployments")
def deployment_platform_history_api():
    if not logged_in():return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,items=_deployment_platform_store().list(request.args.get("limit",100,type=int)))

@app.post("/api/deployment-platform/retention/preview")
def deployment_platform_retention_preview_api():
    if not logged_in():return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf();payload=request.get_json(silent=True) or {}
    try:return jsonify(ok=True,component=str(payload.get("component") or ""),preview=_platform_retention_preview(str(payload.get("component") or "")))
    except (ValueError,OSError) as exc:return jsonify(ok=False,error=str(exc)),400

@app.get("/api/release-manager/evidence/<version>")
def release_manager_evidence(version):
    if not logged_in():return jsonify(ok=False,error="AUTH_REQUIRED"),401
    try:return jsonify(ok=True,evidence=_gate_evidence(norm(version),write=False))
    except (ValueError,FileNotFoundError) as exc:return jsonify(ok=False,error=str(exc)),404

@app.post("/api/release-manager/evidence/<version>/runs")
def release_manager_record_gate_run(version):
    """Structured QA callback/import. Never accepts a manual boolean PASS:
    the run must contain identity, profile, counts and required checks."""
    if not logged_in():return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf();payload=request.get_json(force=True) or {}
    try:return jsonify(ok=True,evidence=_record_gate_run(norm(version),payload)),201
    except FileExistsError as exc:return jsonify(ok=False,error=str(exc)),409
    except ValueError as exc:return jsonify(ok=False,error=str(exc)),409

@app.get("/api/release-manager/cleanup-releases")
def release_manager_cleanup_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,retention=MESFLOW_RELEASE_RETENTION,last_report=load_state().get("release_cleanup_report"))

@app.post("/api/release-manager/cleanup-releases")
def release_manager_cleanup_run():
    """Manual trigger (e.g. to re-run after lowering MESFLOW_RELEASE_RETENTION,
    or to inspect what the automatic policy would do right now). The
    automatic path -- the one the policy actually relies on -- fires only
    after a verified LOCAL_PASS or TEST_PASS; see _cleanup_old_releases()."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    try: return jsonify(ok=True,report=_cleanup_old_releases("MANUAL"))
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500

@app.post("/api/release-manager/build")
def release_manager_build():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    try: start_release_build(); return jsonify(ok=True,job=load_state().get("release_build_job")),202
    except RuntimeError as exc: return jsonify(ok=False,error=str(exc)),409

@app.get("/api/release-manager/bump-version")
def release_manager_bump_version_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,enabled=MESFLOW_BUILD_ENABLED,current_version=_release_summary().get("source_version",""),last=load_state().get("version_bump"))

@app.post("/api/release-manager/bump-version")
def release_manager_bump_version():
    """Runs scripts/bump-version.sh -- updates VERSION.txt/__init__.py/
    release.json/compose.yml consistently. Fast, synchronous, source-only;
    never builds. Optional {"target_version":"X.Y.Z.W"}; omitted/blank
    increments the last segment by 1."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    body=request.get_json(silent=True) or {}
    try: return jsonify(ok=True,**_run_version_bump(body.get("target_version") or ""))
    except (ValueError,RuntimeError) as exc: return jsonify(ok=False,error=str(exc)),409
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500

@app.post("/api/release-manager/deploy-local")
def release_manager_deploy_local():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    # Resolve the artifact to deploy straight from disk (release.json /
    # image-info.json / the ZIP), not from the last release_build_job's
    # transient status. A build attempt can legitimately end in FAILED (for
    # example the immutable-release guard correctly refusing to rebuild an
    # already-released version) while a perfectly valid, previously-built
    # release for that same or another version still exists and remains
    # deployable -- gating on "was the most recent build attempt SUCCESS"
    # incorrectly blocked Deploy Local in exactly that situation.
    requested=(request.get_json(silent=True) or {}).get("version") or request.form.get("version")
    if requested:
        try: artifact=_artifact_for_release(norm(str(requested)))
        except Exception: artifact={}
    else:
        latest=_release_summary().get("latest") or {}
        artifact=_artifact_for_release(str(latest["version"])) if latest.get("version") else {}
    if artifact.get("package") and Path(artifact["package"]).is_file():
        package=Path(artifact["package"]); extract=UPLOAD_DIR/f"local_release_{uuid.uuid4().hex}"; extract.mkdir(parents=True)
        try:
            with zipfile.ZipFile(package) as z: safe_extract_zip(package,extract)
            root=locate_root(extract); version,meta=validate_image_release_contract(root)
            target=RELEASES_DIR/version
            if target.exists(): shutil.rmtree(target)
            shutil.copytree(root,target)
            save_json(target/"agent_manifest.json",{"version":version,"source_name":package.name,"uploaded_at":now_text(),"sha256":sha(package)})
        finally: shutil.rmtree(extract,ignore_errors=True)
    version=str(artifact.get("version") or "")
    if not version or not artifact.get("package_sha256"):
        return jsonify(ok=False,error="LOCAL_BUILD_REQUIRED"),409
    contamination=_release_contamination(version)
    if contamination.get("contaminated"):
        return jsonify(ok=False,error=f"RELEASE_CONTAMINATED: {contamination.get('reason')}"),409
    try: start_deploy(version); return jsonify(ok=True,version=version),202
    except Exception as exc: return jsonify(ok=False,error=str(exc)),409

@app.post("/release-manager/run-test-gate/<version>")
def release_manager_run_test_gate(version):
    """Runs the "release-test" QA evidence profile against THIS Agent's
    own local QA Center (this host's own internal-only MESFlow) and
    returns the raw run payload -- observes only, never records anything
    itself and never mutates a deployment. Called remotely by the
    promoting (DEV) Agent right after it has already verified an
    image-release deploy to this host; the caller records the returned
    payload into ITS OWN evidence store via _record_gate_run(), since only
    the promoting Agent owns the authoritative production-readiness gate
    for a release. This is the MESFlow-release equivalent of what
    _run_local_gate() already does locally for LOCAL -- see
    _run_qa_profile() and _remote_agent_run_test_gate()."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    try:
        version=norm(version)
        digest=_received_release_digest(version)
        payload=_run_qa_profile(version,"TEST",artifact_digest=digest)
        return jsonify(ok=True,payload=payload)
    except Exception as exc:
        return jsonify(ok=False,error=str(exc)),409

@app.get("/api/release-manager/promote-test")
def release_manager_promote_test_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,job=load_state().get("promote_test_job"),summary=_release_summary())

@app.post("/api/release-manager/promote-test")
def release_manager_promote_test():
    """LOCAL_PASS -> select the exact frozen release -> verify ZIP SHA/image
    digest/source commit -> upload the SAME zip to the configured
    PRODUCTION_TEST Agent -> remote verifies SHA -> deploy --no-build ->
    health/version/schema -> TEST_PASS. Never rebuilds anything."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    summary=_release_summary()
    latest=summary.get("latest") or {}
    requested=(request.get_json(silent=True) or {}).get("version") or request.form.get("version")
    version=str(requested or latest.get("version") or "")
    if not version: return jsonify(ok=False,error="NO_RELEASE_TO_PROMOTE"),409
    promotion=_load_promotion_state()
    if promotion.get("version")!=version or not promotion.get("local_pass"):
        return jsonify(ok=False,error="LOCAL_PASS_REQUIRED"),409
    contamination=_release_contamination(version)
    if contamination.get("contaminated"):
        return jsonify(ok=False,error=f"RELEASE_CONTAMINATED: {contamination.get('reason')}"),409
    url,user,password=_production_test_target()
    if not url or not password:
        return jsonify(ok=False,error="PRODUCTION_TEST_AGENT_NOT_CONFIGURED"),409
    try: start_promote_test(version); return jsonify(ok=True,version=version),202
    except RuntimeError as exc: return jsonify(ok=False,error=str(exc)),409

@app.get("/api/release-manager/history")
def release_manager_history():
    """Unified Deployment History (task: Deployment History tab) --
    component/environment/result/date/version-search filters, bounded page
    size, newest first (deployment_history is already stored newest-first)."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    args=request.args
    result=_deployment_history_query(component=args.get("component") or None,environment=args.get("environment") or None,
        result=args.get("result") or None,q=args.get("q") or None,page=args.get("page",1),page_size=args.get("page_size",20))
    return jsonify(ok=True,**result)

@app.get("/api/release-manager/history/<entry_id>")
def release_manager_history_detail(entry_id):
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    items=load_state().get("deployment_history") or []
    entry=next((e for e in items if e.get("id")==entry_id),None)
    if not entry: return jsonify(ok=False,error="NOT_FOUND"),404
    d=dict(entry); d["result"]=_deployment_history_result(entry.get("status"),entry.get("rolled_back_to"))
    log_tail=""
    lf=entry.get("log_file")
    if lf:
        try: log_tail=tail(Path(lf),200)
        except Exception: log_tail=""
    d["log_tail"]=log_tail
    return jsonify(ok=True,item=d)

@app.post("/api/release-manager/production-preflight")
def release_manager_production_preflight():
    """Read-only: logs in and issues GET requests only (/api/status,
    /api/ops/summary, /api/ops/backups) against the configured Production
    Agent. Never uploads a release, never calls /deploy/<version>."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    try:
        report=_run_production_preflight()
        return jsonify(ok=True,preflight=report)
    except Exception as exc:
        return jsonify(ok=False,error=str(exc)),409

@app.post("/api/release-manager/target-agents")
def release_manager_target_agents():
    """Read-only: refreshes and returns the LOCAL/PRODUCTION TEST/PRODUCTION
    compatibility table. Logs in + GET /api/status against each configured
    target only."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    rows=_target_agents_table()
    save_json(CONFIG_DIR/"target-agents.json",{"checked_at":now_text(),"rows":rows})
    return jsonify(ok=True,rows=rows)

@app.get("/api/release-manager/target-agents")
def release_manager_target_agents_get():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,**load_json(CONFIG_DIR/"target-agents.json",{"checked_at":None,"rows":[]}))

@app.get("/api/release-manager/agent-bump-version")
def release_manager_agent_bump_version_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    vf=DEPLOY_AGENT_SOURCE_DIR/"VERSION.txt"
    current=vf.read_text(encoding="utf-8-sig").strip() if vf.is_file() else ""
    return jsonify(ok=True,enabled=MESFLOW_BUILD_ENABLED,current_version=current,last=load_state().get("agent_version_bump"))

@app.post("/api/release-manager/agent-bump-version")
def release_manager_agent_bump_version():
    """Runs deploy-agent/scripts/bump-version.sh -- updates VERSION.txt,
    agent.py's AGENT_VERSION, the Dockerfile ARG, both compose files'
    default image tags, README.md and docs/DEPLOY_DOCKER.md consistently.
    Fast, synchronous, source-only; never builds. Optional
    {"target_version":"X.Y.Z"}; omitted/blank increments the last segment
    by 1."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    body=request.get_json(silent=True) or {}
    try: return jsonify(ok=True,**_run_agent_version_bump(body.get("target_version") or ""))
    except (ValueError,RuntimeError) as exc: return jsonify(ok=False,error=str(exc)),409
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500

@app.post("/api/release-manager/build-agent-package")
def release_manager_build_agent_package():
    """Builds the Deploy Agent's own immutable update artifact from the
    current workspace source (scripts/build-agent-release.sh): source
    preflight, version validation, this Agent's own test suite, Docker
    image build, SHA256, manifest, BUILD_REPORT.md -- the exact package
    format Bootstrap's /updater/update already knows how to install. Does
    not push anywhere; see /api/release-manager/update-agent for that."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    if not MESFLOW_BUILD_ENABLED:
        return jsonify(ok=False,error="BUILD_DISABLED",detail="This Agent has MESFLOW_BUILD_ENABLED=0 (not a DEV host)."),403
    try: start_agent_package_build(); return jsonify(ok=True,job=load_state().get("agent_package_build_job")),202
    except RuntimeError as exc: return jsonify(ok=False,error=str(exc)),409

@app.get("/api/release-manager/agent-package/download")
def release_manager_agent_package_download():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    release=_latest_agent_release()
    if not release.get("package_exists"):
        return jsonify(ok=False,error="AGENT_ARTIFACT_NOT_FOUND"),404
    return send_file(release["package"],as_attachment=True,download_name=Path(release["package"]).name)

@app.post("/api/release-manager/update-agent")
def release_manager_update_agent():
    """Pushes the latest built Agent update artifact (scripts/build-agent-release.sh)
    to the target's host-side updater over HTTP -- no SSH. The target is
    whatever MESFLOW_{PRODUCTION_TEST,PRODUCTION}_AGENT_UPDATER_URL/TOKEN
    point at -- historically deploy-agent/updater/ on :8099, now migrating to
    bootstrap/ on :8098, which vendors that same updater's tested
    verification/update/rollback logic and serves an identical
    POST /updater/update contract (see
    reports/BOOTSTRAP_AGENT_UPDATER_CONSOLIDATION.md). Only the configured
    URL's port changes for that cutover; nothing here or in those env var
    names does. Production
    requires MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 on this Agent AND an
    explicit {"confirm": true} in the request body."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    role=str((request.get_json(silent=True) or {}).get("role") or request.form.get("role") or "").strip().upper()
    if role not in ("PRODUCTION_TEST","PRODUCTION"):
        return jsonify(ok=False,error="INVALID_ROLE"),400
    if role=="PRODUCTION":
        confirmed=bool((request.get_json(silent=True) or {}).get("confirm"))
        if not confirmed:
            return jsonify(ok=False,error="PRODUCTION_AGENT_UPDATE_REQUIRES_CONFIRM",
                            detail="Production Agent update requires explicit human confirmation on every call."),403
    try: start_agent_update(role); return jsonify(ok=True,role=role),202
    except RuntimeError as exc: return jsonify(ok=False,error=str(exc)),409

@app.get("/api/release-manager/production-preflight")
def release_manager_production_preflight_get():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,preflight=load_json(CONFIG_DIR/"production-preflight.json",{}))

@app.post("/api/release-manager/promote-production")
def release_manager_promote_production():
    """Wired but never executes without explicit human approval:
    MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 on this Agent AND a request body of
    {"confirm": true}. Requires LOCAL_PASS + TEST_PASS + matching ZIP SHA +
    matching image digest + schema PASS + not contaminated, verified fresh
    on every call (never trusts a stale flag)."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    summary=_release_summary()
    promotion=summary.get("promotion") or {}
    version=str((summary.get("latest") or {}).get("version") or "")
    if not promotion.get("production_gate"):
        return jsonify(ok=False,error="GATE_NOT_PASSED",blocked=summary.get("blocked",{}).get("production")),409
    enabled=os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() in {"1","true","yes","on"}
    confirmed=bool((request.get_json(silent=True) or {}).get("confirm"))
    if not (enabled and confirmed):
        return jsonify(ok=False,error="PRODUCTION_PROMOTE_NOT_APPROVED",
                        detail="Requires MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 on this Agent AND {\"confirm\":true} in the request body. Neither is a default — a human must set both explicitly."),403
    # Deliberately not implemented further in this change: even with the gate
    # passed and explicitly confirmed, this Agent does not perform a
    # production deploy in this codebase revision. See
    # reports/RELEASE_MANAGER_BUILD_ONCE.md — Production deploys remain a
    # separate, explicitly-scoped, human-executed action.
    return jsonify(ok=False,error="PRODUCTION_DEPLOY_NOT_IMPLEMENTED",
                    detail=f"Gate passed for {version} and explicitly approved, but this Agent build does not execute production deploys yet."),501

# ---------------- QA Center Release Manager (Build Once / Promote Same Artifact) ----------------
# Mirrors every /api/release-manager/* route above 1:1 for the second
# application. Independent state/promotion/locks throughout -- see the
# "QA Center: Build Once / Promote Same Artifact" section above agent.py.

@app.get("/api/qa-release-manager")
def qa_release_manager():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,enabled=MESFLOW_BUILD_ENABLED,summary=_qa_release_summary(),job=load_state().get("qa_release_build_job"))

@app.get("/api/qa-release-manager/cleanup-releases")
def qa_release_manager_cleanup_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,retention=QA_RELEASE_RETENTION,last_report=load_state().get("qa_release_cleanup_report"))

@app.post("/api/qa-release-manager/cleanup-releases")
def qa_release_manager_cleanup_run():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    try: return jsonify(ok=True,report=_qa_cleanup_old_releases("MANUAL"))
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500

@app.get("/api/qa-release-manager/bump-version")
def qa_release_manager_bump_version_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,enabled=MESFLOW_BUILD_ENABLED,current_version=_qa_release_summary().get("source_version",""),last=load_state().get("qa_version_bump"))

@app.post("/api/qa-release-manager/bump-version")
def qa_release_manager_bump_version():
    """Runs qa-center/scripts/bump-version.sh -- updates current/VERSION +
    current/agent.py's APP_VERSION consistently. Fast, synchronous,
    source-only; never builds. Optional {"target_version":"X.Y.Z"};
    omitted/blank increments the last segment by 1."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    body=request.get_json(silent=True) or {}
    try: return jsonify(ok=True,**_run_qa_version_bump(body.get("target_version") or ""))
    except (ValueError,RuntimeError) as exc: return jsonify(ok=False,error=str(exc)),409
    except Exception as exc: return jsonify(ok=False,error=str(exc)),500

@app.post("/api/qa-release-manager/build")
def qa_release_manager_build():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    try: start_qa_release_build(); return jsonify(ok=True,job=load_state().get("qa_release_build_job")),202
    except RuntimeError as exc: return jsonify(ok=False,error=str(exc)),409

@app.post("/api/qa-release-manager/deploy-local")
def qa_release_manager_deploy_local():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    requested=(request.get_json(silent=True) or {}).get("version") or request.form.get("version")
    if requested:
        try: artifact=_qa_artifact_for_release(norm(str(requested)))
        except Exception: artifact={}
    else:
        latest=_qa_release_summary().get("latest") or {}
        artifact=_qa_artifact_for_release(str(latest["version"])) if latest.get("version") else {}
    version=str(artifact.get("version") or "")
    if not version or not artifact.get("package_sha256"):
        return jsonify(ok=False,error="QA_LOCAL_BUILD_REQUIRED"),409
    contamination=_qa_release_contamination(version)
    if contamination.get("contaminated"):
        return jsonify(ok=False,error=f"RELEASE_CONTAMINATED: {contamination.get('reason')}"),409
    try: start_qa_local_deploy(version); return jsonify(ok=True,version=version),202
    except Exception as exc: return jsonify(ok=False,error=str(exc)),409

@app.get("/api/qa-release-manager/promote-test")
def qa_release_manager_promote_test_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,job=load_state().get("qa_promote_test_job"),summary=_qa_release_summary())

@app.post("/api/qa-release-manager/promote-test-preflight")
def qa_release_manager_promote_test_preflight():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    try:
        result = _qa_promote_test_preflight()
        return jsonify(ok=True, **result)
    except Exception as ex:
        info = _qa_error_explain(str(ex))
        return jsonify(ok=False,error=info['code'],reason=info['reason'],next_action=info['next_action'],detail=info['detail']),409

@app.post("/api/qa-release-manager/promote-test")
def qa_release_manager_promote_test():
    """LOCAL_PASS -> select the exact frozen QA release -> verify ZIP SHA ->
    upload the SAME zip to the configured PRODUCTION_TEST Agent -> remote
    verifies checksums+digest -> deploy --no-build -> health/version ->
    TEST_PASS. Never rebuilds anything. Reuses the SAME
    MESFLOW_PRODUCTION_TEST_AGENT_URL/_USER/_PASSWORD target as MESFlow
    promotion -- it is the same physical Deploy Agent on that host."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    summary=_qa_release_summary()
    latest=summary.get("latest") or {}
    requested=(request.get_json(silent=True) or {}).get("version") or request.form.get("version")
    version=str(requested or latest.get("version") or "")
    if not version: return jsonify(ok=False,error="NO_RELEASE_TO_PROMOTE"),409
    promotion=_qa_load_promotion_state()
    if promotion.get("version")!=version or not promotion.get("local_pass"):
        return jsonify(ok=False,error="LOCAL_PASS_REQUIRED"),409
    contamination=_qa_release_contamination(version)
    if contamination.get("contaminated"):
        return jsonify(ok=False,error=f"RELEASE_CONTAMINATED: {contamination.get('reason')}"),409
    url,user,password=_production_test_target()
    if not url or not password:
        return jsonify(ok=False,error="PRODUCTION_TEST_AGENT_NOT_CONFIGURED"),409
    try: start_qa_promote_test(version); return jsonify(ok=True,version=version),202
    except RuntimeError as exc: return jsonify(ok=False,error=str(exc)),409

@app.post("/api/qa-release-manager/promote-production")
def qa_release_manager_promote_production():
    """Same wired-but-never-executes gate as MESFlow's promote-production."""
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    verify_csrf()
    summary=_qa_release_summary()
    promotion=summary.get("promotion") or {}
    version=str((summary.get("latest") or {}).get("version") or "")
    if not promotion.get("production_gate"):
        return jsonify(ok=False,error="GATE_NOT_PASSED",blocked=summary.get("blocked",{}).get("production")),409
    enabled=os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() in {"1","true","yes","on"}
    confirmed=bool((request.get_json(silent=True) or {}).get("confirm"))
    if not (enabled and confirmed):
        return jsonify(ok=False,error="PRODUCTION_PROMOTE_NOT_APPROVED",
                        detail="Requires MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 on this Agent AND {\"confirm\":true} in the request body."),403
    return jsonify(ok=False,error="PRODUCTION_DEPLOY_NOT_IMPLEMENTED",
                    detail=f"Gate passed for QA {version} and explicitly approved, but this Agent build does not execute production deploys yet."),501

# ---------------- Minimal Deploy Agent ESP OTA ----------------
def _ota_admin_token_valid():
    auth=str(request.headers.get("Authorization") or "")
    supplied=auth[7:].strip() if auth.lower().startswith("bearer ") else str(request.headers.get("X-MESFlow-Deploy-Agent-Token") or "").strip()
    expected=str(os.environ.get("MESFLOW_DEPLOY_AGENT_TOKEN") or os.environ.get("MESFLOW_OTA_PUBLISH_TOKEN") or "").strip()
    return bool(expected and supplied and hmac.compare_digest(expected,supplied))

def _ota_admin_required():
    if logged_in() or _ota_admin_token_valid(): return None
    return jsonify(ok=False,error="AUTH_REQUIRED"),401

def _ota_device_kiosk_id():
    token=str(request.headers.get("X-Kiosk-Token") or "").strip()
    kiosk_id=str((request.get_json(silent=True) or {}).get("kiosk_id") or request.args.get("kiosk_id") or "").strip()
    if not token or not kiosk_id:return None
    # The Agent never opens MESFlow's database. MESFlow validates this device
    # token as part of the readiness request below.
    return kiosk_id

def _ota_download_url(artifact_id, kiosk_id):
    """Advertise the externally reachable HTTPS origin to ESP devices."""
    configured = str(os.environ.get("WORKSHOP_AGENT_PUBLIC_URL") or "").rstrip("/")
    if configured:
        return f"{configured}/api/esp-ota/file/{artifact_id}?kiosk_id={quote(kiosk_id, safe='')}"
    host = request.headers.get("X-Forwarded-Host") or request.host
    proto = (request.headers.get("X-Forwarded-Proto") or "").split(",", 1)[0].strip()
    if not proto:
        proto = "https" if str(host).split(":", 1)[0].endswith("mesflow.net") else request.scheme
    return f"{proto}://{host}{request.script_root}/api/esp-ota/file/{artifact_id}?kiosk_id={quote(kiosk_id, safe='')}"

def _mesflow_readiness(kiosk_id,device_token,include_internal=True):
    path=f"/api/internal/kiosks/{quote(kiosk_id,safe='')}/ota-readiness"
    req=urllib.request.Request(MES_URL+path,headers={"X-Kiosk-Token":device_token,"X-Deploy-Agent":"1","User-Agent":"MESFlow-Deploy-Agent-OTA"})
    internal=str(os.environ.get("MESFLOW_INTERNAL_API_TOKEN") or "") if include_internal else ""
    if internal:req.add_header("X-MESFlow-Internal-Token",internal)
    try:
        with urllib.request.urlopen(req,timeout=5) as response:
            payload=json.loads(response.read().decode("utf-8")); return {"available":True,**payload}
    except urllib.error.HTTPError as exc:
        if exc.code in (401,403):
            return {"available":False,"auth_failed":True,"ota_ready":False,"reason":"AUTH_REQUIRED"}
        return {"available":False,"ota_ready":False,"reason":"WAITING_MESFLOW_STATE","error":str(exc)}
    except Exception as exc:
        return {"available":False,"ota_ready":False,"reason":"WAITING_MESFLOW_STATE","error":str(exc)}

def _mesflow_inventory():
    internal=str(os.environ.get("MESFLOW_INTERNAL_API_TOKEN") or "")
    if not internal: return None
    req=urllib.request.Request(MES_URL+"/api/internal/kiosks",headers={"X-MESFlow-Internal-Token":internal,"X-Deploy-Agent":"1"})
    try:
        with urllib.request.urlopen(req,timeout=5) as response:
            payload=json.loads(response.read().decode("utf-8")); return payload.get("items",payload if isinstance(payload,list) else [])
    except Exception:return None

def _device_token_valid(kiosk_id, token):
    return bool(token and _mesflow_readiness(kiosk_id, token, include_internal=False).get("available"))

@app.get("/ota")
def ota_console():
    # Back-compat only: this page now lives at /kiosk/ota (task:
    # ESP_KIOSK_UI_SEPARATION). Stays exempt from protect()'s generic
    # redirect-to-login below so an OTA-admin-token client hitting the old
    # bare URL still lands on a page it can authenticate against, exactly
    # as before -- kiosk_ota_page() re-applies the same _ota_admin_required()
    # gate itself.
    return redirect(url_for("kiosk_ota_page"))

@app.post("/api/esp-builder/start")
def esp_builder_start():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    try:
        start_esp_builder()
        return jsonify(ok=True,job=load_state().get("esp_builder_job")),202
    except RuntimeError as exc:
        return jsonify(ok=False,error=str(exc)),409

@app.get("/api/esp-builder/status")
def esp_builder_status():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    return jsonify(ok=True,enabled=ESP_BUILD_ENABLED,source_path=str(ESP_KIOSK_SOURCE_DIR),job=load_state().get("esp_builder_job"))

@app.get("/api/esp-ota/devices")
@app.get("/api/ota/devices")
def ota_devices():
    gate=_ota_admin_required()
    if gate:return gate
    items=_mesflow_inventory()
    if items is None:return jsonify(ok=False,error="MESFLOW_UNAVAILABLE"),503
    return jsonify(ok=True,items=ota.sync_devices(items))

@app.get("/api/esp-ota/status/<job_id>")
@app.get("/api/ota/status/<job_id>")
def ota_job_status(job_id):
    gate=_ota_admin_required()
    if gate:return gate
    item=ota.get_job(job_id)
    return (jsonify(ok=True,job=item),200) if item else (jsonify(ok=False,error="NOT_FOUND"),404)

@app.get("/api/esp-ota/jobs")
def ota_jobs():
    gate=_ota_admin_required()
    if gate:return gate
    return jsonify(ok=True,items=ota.list_jobs())

@app.post("/api/esp-ota/jobs/<job_id>/cancel")
def ota_cancel_job(job_id):
    if not (_ota_admin_token_valid() or logged_in()):return jsonify(ok=False,error="AUTH_REQUIRED"),401
    item=ota.cancel_job(job_id)
    return (jsonify(ok=True,job=item),200) if item else (jsonify(ok=False,error="NOT_FOUND"),404)

@app.post("/api/esp-ota/upload")
def ota_upload_and_flash():
    if not (_ota_admin_token_valid() or logged_in()):return jsonify(ok=False,error="AUTH_REQUIRED"),401
    upload=request.files.get("firmware"); form=request.form
    if not upload:return jsonify(ok=False,error="OTA_REQUIRED_FIELDS"),400
    try:
        if str(upload.filename or "").lower().endswith(".zip"):
            artifact=ota._save_firmware_package(upload.stream,upload.filename)
        else:
            version=str(form.get("version") or "").strip()
            if not version:return jsonify(ok=False,error="VERSION_REQUIRED"),400
            hardware=str(form.get("hardware_model") or "").strip()
            artifact=ota._save_firmware(upload.stream,upload.filename,version,hardware)
        ids=json.loads(form.get("kiosk_ids") or "[]")
        job=ota.create_job(artifact,ids)
        return jsonify(ok=True,firmware=artifact,job=job),201
    except ValueError as exc:
        code=str(exc); status=409 if code in {"VERSION_CONFLICT","OTA_ALREADY_RUNNING"} else 400
        return jsonify(ok=False,error=code),status
    except Exception as exc:return jsonify(ok=False,error="OTA_UPLOAD_FAILED",message=str(exc)),400

@app.get("/api/esp-ota/firmware")
def ota_firmware_list():
    gate=_ota_admin_required()
    if gate:return gate
    return jsonify(ok=True,items=ota.list_firmware())

@app.get("/api/esp-ota/check")
@app.get("/api/ota/check")
def ota_device_check():
    kiosk_id=_ota_device_kiosk_id()
    if not kiosk_id:return jsonify(update_available=False,reason="AUTH_REQUIRED"),401
    token=str(request.headers.get("X-Kiosk-Token") or "")
    # Validate the device token without the Agent's internal bypass first.
    # A temporary MESFlow outage must remain a safe WAITING state, not turn a
    # still-valid pending job into a terminal failure.
    token_check=_mesflow_readiness(kiosk_id, token, include_internal=False)
    if token_check.get("auth_failed"): return jsonify(update_available=False,reason="AUTH_REQUIRED"),401
    if not token_check.get("available"):
        return jsonify(update_available=False,reason="WAITING_MESFLOW_STATE"),200
    readiness=_mesflow_readiness(kiosk_id, token)
    if readiness.get("auth_failed"): return jsonify(update_available=False,reason="AUTH_REQUIRED"),401
    if not readiness.get("available"):
        return jsonify(update_available=False,reason="WAITING_MESFLOW_STATE"),200
    if not ota.readiness_allows_update(readiness):
        # Leave the job device PENDING. The next normal ESP poll will retry and
        # will claim the update as soon as the instantaneous readiness is safe.
        reason=readiness.get("reason") or "WAITING_MESFLOW_STATE"
        return jsonify(update_available=False,reason=reason,readiness={
            "online":readiness.get("online"),
            "ui_state":readiness.get("ui_state"),
            "offline_queue_count":readiness.get("offline_queue_count"),
            "health_state":readiness.get("health_state"),
            "active_session":readiness.get("active_session",False),
            "ota_ready":False,
        })
    result=ota.check_update(kiosk_id,str(request.args.get("current_version") or ""),str(request.args.get("hardware_model") or ""))
    if result.get("update_available"):
        result["url"]=_ota_download_url(result["firmware_id"], kiosk_id)
    return jsonify(result)

@app.get("/api/ota/firmware/<artifact_id>/download")
@app.get("/api/esp-ota/file/<artifact_id>")
def ota_device_download(artifact_id):
    kiosk_id=_ota_device_kiosk_id()
    if not kiosk_id:
        app.logger.warning("OTA_DOWNLOAD auth_missing artifact=%s", artifact_id)
        return jsonify(ok=False,error="AUTH_REQUIRED"),401
    if not _device_token_valid(kiosk_id,str(request.headers.get("X-Kiosk-Token") or "")):
        app.logger.warning("OTA_DOWNLOAD auth_failed kiosk_id=%s artifact=%s", kiosk_id, artifact_id)
        return jsonify(ok=False,error="AUTH_REQUIRED"),401
    row=ota.target_for_download(kiosk_id,artifact_id)
    if not row:
        app.logger.warning("OTA_DOWNLOAD not_assigned kiosk_id=%s artifact=%s", kiosk_id, artifact_id)
        return jsonify(ok=False,error="DOWNLOAD_NOT_ASSIGNED"),403
    path=Path(row["storage_path"])
    expected_size = row["file_size"] if "file_size" in row.keys() else row["size"]
    if not path.is_file() or path.stat().st_size!=expected_size:
        app.logger.error("OTA_DOWNLOAD artifact_invalid kiosk_id=%s artifact=%s path=%s", kiosk_id, artifact_id, path)
        return jsonify(ok=False,error="OTA_ARTIFACT_INVALID"),410
    app.logger.info("OTA_DOWNLOAD serve kiosk_id=%s job_id=%s artifact=%s bytes=%s", kiosk_id, row["job_id"], artifact_id, expected_size)
    return send_file(path,mimetype="application/octet-stream",as_attachment=True,download_name=row["filename"],conditional=True,etag=row["sha256"])

@app.post("/api/esp-ota/event")
@app.post("/api/ota/event")
def ota_device_event():
    kiosk_id=_ota_device_kiosk_id()
    if not kiosk_id:return jsonify(ok=False,error="AUTH_REQUIRED"),401
    if not _device_token_valid(kiosk_id,str(request.headers.get("X-Kiosk-Token") or "")): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    body=request.get_json(silent=True) or {}; body["kiosk_id"]=kiosk_id
    return jsonify(ok=True,**ota.record_event(body)),201


# ---------------- Server Operations Console ----------------
def ops_summary():
    return collect_system_health_summary(mes_status, qa_status)

# ---------------- Operations Center: Incident model ----------------
# Deploy Agent owns SYSTEM/INFRASTRUCTURE incidents (see
# reports/SYSTEM_LOG_AUDIT_SEPARATION.md). Persisted as JSON, matching this
# Agent's existing state-file convention (no database driver here) --
# fingerprint-keyed so a condition that keeps being true stays ONE row
# (occurrence_count increments), never a new incident per poll.
INCIDENTS_FILE=CONFIG_DIR/"incidents.json"
INCIDENT_POLL_SECONDS=int(os.environ.get("MESFLOW_INCIDENT_POLL_SECONDS","30"))
PREDICTIVE_SAMPLE_SECONDS=max(60,int(os.environ.get("MESFLOW_PREDICTIVE_SAMPLE_SECONDS","300")))
PREDICTIVE_RAW_DAYS=max(7,int(os.environ.get("MESFLOW_PREDICTIVE_RAW_DAYS","14")))
PREDICTIVE_HOURLY_DAYS=max(PREDICTIVE_RAW_DAYS,int(os.environ.get("MESFLOW_PREDICTIVE_HOURLY_DAYS","90")))
PREDICTIVE_DAILY_DAYS=max(PREDICTIVE_HOURLY_DAYS,int(os.environ.get("MESFLOW_PREDICTIVE_DAILY_DAYS","365")))
PREDICTIVE_MIN_SAMPLES=max(5,int(os.environ.get("MESFLOW_PREDICTIVE_MIN_SAMPLES","12")))
PREDICTIVE_MIN_HOURS=max(1,float(os.environ.get("MESFLOW_PREDICTIVE_MIN_HOURS","48")))
PREDICTIVE_DISK_HIGH_DAYS=max(1,float(os.environ.get("MESFLOW_PREDICTIVE_DISK_HIGH_DAYS","7")))
PREDICTIVE_DISK_MEDIUM_DAYS=max(PREDICTIVE_DISK_HIGH_DAYS,float(os.environ.get("MESFLOW_PREDICTIVE_DISK_MEDIUM_DAYS","14")))
METRICS_FILE=DATA_DIR/"predictive_metrics.json"
AI_ANALYSIS_FILE=DATA_DIR/"incident_ai_analysis.json"
_metric_store=MetricStore(METRICS_FILE,PREDICTIVE_RAW_DAYS,PREDICTIVE_HOURLY_DAYS,PREDICTIVE_DAILY_DAYS)
_ai_provider=(HTTPJSONAIProvider(os.environ.get("MESFLOW_AI_PROVIDER_URL",""),os.environ.get("MESFLOW_AI_MODEL",""),float(os.environ.get("MESFLOW_AI_TIMEOUT_SECONDS","12")))
              if os.environ.get("MESFLOW_AI_ENABLED","0").lower() in {"1","true","yes","on"} and os.environ.get("MESFLOW_AI_PROVIDER_URL") else DisabledAIProvider())
_incident_ai=IncidentAIService(AI_ANALYSIS_FILE,_ai_provider,int(os.environ.get("MESFLOW_AI_MAX_CONTEXT_BYTES","48000")))
# Containers this Agent is responsible for alerting on. A container NOT in
# this set that happens to be stopped is not this system's incident --
# never assume every historical/unrelated container should be running.
EXPECTED_CONTAINERS=set(x.strip() for x in os.environ.get(
    "MESFLOW_EXPECTED_CONTAINERS","mesflow-app,mesflow-postgres,mesflow-deploy-agent,mesflow-qa-center,mesflow-nginx").split(",") if x.strip())
_incident_lock=threading.Lock()

# P3 Notification: critical incident -> notification -> recovery (section
# 33: no Redis/RabbitMQ needed at this scale -- the same JSON-file store
# convention as incidents.json, reconciled from the existing incident
# monitor loop below). WEB always available; Telegram/Email report
# NOT_CONFIGURED rather than failing when unset (section 6).
NOTIFICATIONS_FILE=CONFIG_DIR/"notifications.json"
_notification_channels={
    "WEB":WebChannel(),
    "TELEGRAM":TelegramChannel(os.environ.get("MESFLOW_TELEGRAM_BOT_TOKEN",""),os.environ.get("MESFLOW_TELEGRAM_CHAT_ID","")),
    "EMAIL":EmailChannel(os.environ.get("MESFLOW_SMTP_HOST",""),int(os.environ.get("MESFLOW_SMTP_PORT","587") or 587),
        os.environ.get("MESFLOW_SMTP_USER",""),os.environ.get("MESFLOW_SMTP_PASSWORD",""),
        str(os.environ.get("MESFLOW_SMTP_USE_TLS","1")).lower() in {"1","true","yes","on"},
        os.environ.get("MESFLOW_SMTP_FROM",""),os.environ.get("MESFLOW_SMTP_TO","")),
}
_notification_dispatcher=NotificationDispatcher(_notification_channels,NOTIFICATIONS_FILE,environment_label(SERVER_ROLE),
    min_severity={"TELEGRAM":os.environ.get("MESFLOW_NOTIFY_TELEGRAM_MIN_SEVERITY","HIGH").upper(),
                  "EMAIL":os.environ.get("MESFLOW_NOTIFY_EMAIL_MIN_SEVERITY","CRITICAL").upper()})

def _load_incidents():
    with _incident_lock:
        return load_json(INCIDENTS_FILE,{"items":{}})

def _save_incidents(store):
    with _incident_lock:
        save_json(INCIDENTS_FILE,store)

def _incident_conditions():
    """Read-only evidence gathering only -- never a mutation (section 14)."""
    conditions=[]
    try:
        mes=mes_status()
        if not mes.get("online"):
            conditions.append(("MESFLOW_DOWN","SERVICE_DOWN","CRITICAL","health-monitor","mesflow","mesflow",
                "MESFlow application unreachable","api_online=False, docker_running=%s"%mes.get("docker",{}).get("running"),{"mes_status":mes}))
    except Exception as e:
        conditions.append(("MESFLOW_CHECK_FAILED","DIAGNOSTIC_FAILURE","MEDIUM","health-monitor","mesflow","mesflow",
            "MESFlow health check itself failed","%s: %s"%(type(e).__name__,e),{}))
    try:
        if QA_URL:
            qa=qa_status()
            if not qa.get("online"):
                conditions.append(("QA_DOWN","SERVICE_DOWN","HIGH","health-monitor","qa-center","qa-center",
                    "QA Center unreachable","online=False",{"qa_status":qa}))
    except Exception:
        pass
    try:
        for c in ops_docker():
            name=(c.get("Names") or "").lstrip("/")
            if name not in EXPECTED_CONTAINERS:continue
            state=str(c.get("State") or "").lower();status_text=str(c.get("Status") or "")
            if state and state!="running":
                conditions.append((f"CONTAINER_DOWN:{name}","CONTAINER_DOWN","HIGH","docker",socket.gethostname(),name,
                    f"Container {name} is not running","state=%s status=%s"%(state,status_text),{"container":c}))
            elif "unhealthy" in status_text.lower():
                conditions.append((f"CONTAINER_UNHEALTHY:{name}","CONTAINER_UNHEALTHY","HIGH","docker",socket.gethostname(),name,
                    f"Container {name} reports unhealthy","status=%s"%status_text,{"container":c}))
    except Exception:
        pass
    try:
        vm=psutil.virtual_memory();root=psutil.disk_usage('/') if os.name!='nt' else psutil.disk_usage(Path.cwd().anchor)
        if root.percent>=90:
            conditions.append(("DISK_CRITICAL","CAPACITY","CRITICAL","host",socket.gethostname(),"disk",
                f"Disk usage at {root.percent:.0f}%","percent=%.1f"%root.percent,{"percent":root.percent,"free":_bytes(root.free)}))
        if vm.percent>=90:
            conditions.append(("RAM_CRITICAL","CAPACITY","CRITICAL","host",socket.gethostname(),"ram",
                f"RAM usage at {vm.percent:.0f}%","percent=%.1f"%vm.percent,{"percent":vm.percent}))
    except Exception:
        pass
    return conditions

def sync_incidents(conditions):
    """Fingerprint dedup + ACTIVE/AUTO_RESOLVED lifecycle (section 7/8).
    A condition still present on this poll: update last_seen_at/
    occurrence_count on the SAME row, never a new one. A condition that
    was ACTIVE and is no longer observed: AUTO_RESOLVED. An
    already-ACKNOWLEDGED incident that recurs re-activates (reopen)."""
    store=_load_incidents();items=store.setdefault("items",{})
    now_iso=now_text();seen=set()
    for fp,itype,severity,source,server,service,summary,reason,evidence in conditions:
        seen.add(fp)
        existing=items.get(fp)
        if existing and existing.get("status") in ("ACTIVE","ACKNOWLEDGED"):
            existing["last_seen_at"]=now_iso;existing["occurrence_count"]=int(existing.get("occurrence_count",1))+1
            existing["summary"]=summary;existing["technical_reason"]=reason;existing["evidence"]=evidence
            if existing.get("status")=="ACKNOWLEDGED" and existing.get("_reopen_on_recur",True):
                pass  # stays ACKNOWLEDGED until a human/auto-resolve changes it -- recurrence alone doesn't spam
        else:
            cycles=list((existing or {}).get("cycles") or [])
            cycles.append({"started_at":now_iso,"resolved_at":None})
            items[fp]={"incident_id":(existing or {}).get("incident_id") or uuid.uuid4().hex,
                "fingerprint":fp,"incident_type":itype,"severity":severity,"source":source,"server":server,"service":service,
                "started_at":(existing or {}).get("started_at") or now_iso,"last_seen_at":now_iso,"resolved_at":None,
                "status":"ACTIVE","summary":summary,"technical_reason":reason,"impact":"","evidence":evidence,
                "diagnostic_summary":"","acknowledged_by":"","resolution_reason":"",
                "occurrence_count":int((existing or {}).get("occurrence_count",0))+1,"cycles":cycles[-200:]}
    for fp,inc in list(items.items()):
        if inc.get("status") in ("ACTIVE","ACKNOWLEDGED") and fp not in seen:
            inc["status"]="AUTO_RESOLVED";inc["resolved_at"]=now_iso
            if inc.get("cycles") and not inc["cycles"][-1].get("resolved_at"):inc["cycles"][-1]["resolved_at"]=now_iso
    _save_incidents(store)
    return items

_notification_health={"last_run_at":None,"last_success_at":None,"last_error":""}

def _incident_monitor_loop():
    while True:
        try:
            items=sync_incidents(_incident_conditions())
            _notification_health["last_run_at"]=now_text()
            try:
                # Reconciled every cycle, not just on the open/close edge --
                # this is what makes a mid-dispatch crash self-heal on the
                # very next poll instead of needing a separate retry queue
                # (section 34/47).
                _notification_dispatcher.reconcile(items)
                _notification_health["last_success_at"]=now_text();_notification_health["last_error"]=""
            except Exception as e:
                _notification_health["last_error"]=f"{type(e).__name__}: {e}"
                try:append_log(f"Notification dispatch error: {type(e).__name__}: {e}")
                except Exception:pass
        except Exception as e:
            try:append_log(f"Incident monitor error: {type(e).__name__}: {e}")
            except Exception:pass
        time.sleep(max(10,INCIDENT_POLL_SECONDS))

def start_incident_monitor():
    threading.Thread(target=_incident_monitor_loop,daemon=True).start()

def _postgres_database_size():
    """Best-effort read-only DB sizing; credentials never leave the container.

    `docker exec` defaults to the container's root user, not the `postgres`
    role -- a bare `psql` with no -U/-d then fails closed with "role root
    does not exist" (confirmed against a real Postgres container while
    building P4). Connect explicitly as the app's own configured role/DB,
    using the credentials already present in the target container's own
    environment (POSTGRES_USER/POSTGRES_PASSWORD/POSTGRES_DB) -- never typed
    or stored by this Agent."""
    if not shutil.which("docker"):return None
    sql="SELECT pg_database_size(current_database());"
    command=["docker","exec","mesflow-postgres","sh","-lc",
             f'PGPASSWORD="$POSTGRES_PASSWORD" psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Atqc "{sql}" 2>/dev/null']
    result=_run_capture(command,12)
    try:return int(str(result.get("stdout") or "").strip().splitlines()[-1]) if result.get("ok") else None
    except (ValueError,IndexError):return None

def _postgres_table_sizes(limit=10):
    """Infrequent, read-only top-table snapshot; never runs on page load."""
    if not shutil.which("docker"):return []
    sql=("SELECT n.nspname||'.'||c.relname||'|'||pg_total_relation_size(c.oid) "
         "FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace "
         "WHERE c.relkind IN ('r','m') AND n.nspname NOT IN ('pg_catalog','information_schema') "
         f"ORDER BY pg_total_relation_size(c.oid) DESC LIMIT {int(limit)};")
    result=_run_capture(["docker","exec","mesflow-postgres","sh","-lc",
        f'PGPASSWORD="$POSTGRES_PASSWORD" psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Atqc "{sql}" 2>/dev/null'],20)
    rows=[]
    if result.get("ok"):
        for line in str(result.get("stdout") or "").splitlines():
            try:name,size=line.rsplit("|",1);rows.append((name,int(size)))
            except (ValueError,TypeError):continue
    return rows

# P4 Backup / DB / Storage Center. Deliberately separate storage from the
# existing MESFlow source-code rollback snapshots (DATA_DIR/mes_backups,
# see the comment near MESFLOW_RELEASE_RETENTION above) -- these are real
# PostgreSQL database backups (pg_dump), a different concern entirely
# (section 38: "keep them distinct").
DB_BACKUPS_DIR=DATA_DIR/"db_backups"
DB_BACKUPS_FILE=CONFIG_DIR/"db_backups.json"
RESTORE_DRILLS_FILE=CONFIG_DIR/"restore_drills.json"
DB_AUDIT_FILE=CONFIG_DIR/"db_audit.json"
_pg_target=db_backup.PostgresTarget(container=os.environ.get("MESFLOW_POSTGRES_CONTAINER","mesflow-postgres"))
_db_audit_lock=threading.Lock()

def _db_audit(action,data):
    """Structured audit trail for every P4 mutation (section 38/58), on top
    of the existing human-readable AGENT_LOG -- every backup/verify/pin/
    retention-delete/restore-drill action is recorded here with actor,
    reason and timestamp, never silently."""
    entry={"action":action,"at":now_text(),**{k:v for k,v in data.items()}}
    with _db_audit_lock:
        store=load_json(DB_AUDIT_FILE,{"items":[]})
        items=store.setdefault("items",[]);items.append(entry)
        store["items"]=items[-1000:]
        save_json(DB_AUDIT_FILE,store)
    try:append_log(f"[db-audit] {action}: "+", ".join(f"{k}={v}" for k,v in data.items() if k not in ("evidence",)))
    except Exception:pass

_db_backup_service=db_backup.BackupService(_pg_target,DB_BACKUPS_DIR,DB_BACKUPS_FILE,
    app_version_provider=lambda:mes_status().get("version",""),audit=_db_audit)
_db_retention_service=db_backup.RetentionService(_db_backup_service,audit=_db_audit)
_db_restore_drill_service=db_backup.RestoreDrillService(_pg_target,RESTORE_DRILLS_FILE,audit=_db_audit)
_db_storage_service=db_backup.StorageService(categories={
    "backups":DB_BACKUPS_DIR,"postgresql_release_backups":DATA_DIR/"mes_backups",
    "releases":RELEASES_DIR,"logs":LOG_DIR,"uploads":UPLOAD_DIR,
})

def _active_restore_drill_source():
    """Backup id currently referenced by the most recent RUNNING restore
    drill, if any -- retention must never delete it out from under an
    in-flight drill (section 63)."""
    items=_db_restore_drill_service.list()
    running=next((d for d in items if d.get("status")=="RUNNING"),None)
    return running.get("backup_id") if running else None

# ---------------------------------------------------------------------
# Server Incident Recovery Console -- managed MESFlow stack allowlist,
# dependency-aware recovery, port-conflict-aware diagnosis. Own audit
# trail, separate from the P4 DB-domain audit above. Container names are
# env-overridable (matching the existing MESFLOW_POSTGRES_CONTAINER
# convention _pg_target already uses) SPECIFICALLY so tests can point
# every managed name at something that provably does not exist -- never
# reuse the real container names against a real Docker daemon in a test
# (see AGENTS.md/docs: a spawned "throwaway" test agent hitting real
# containers is a documented past incident, not a hypothetical).
# ---------------------------------------------------------------------
RECOVERY_AUDIT_FILE=CONFIG_DIR/"recovery_audit.json"
_recovery_audit_lock=threading.Lock()

def _recovery_audit(action,data):
    entry={"action":action,"at":now_text(),**{k:v for k,v in data.items()}}
    with _recovery_audit_lock:
        store=load_json(RECOVERY_AUDIT_FILE,{"items":[]})
        items=store.setdefault("items",[]);items.append(entry)
        store["items"]=items[-1000:]
        save_json(RECOVERY_AUDIT_FILE,store)
    try:append_log(f"[recovery-audit] {action}: "+", ".join(f"{k}={v}" for k,v in data.items() if k not in ("detail",)))
    except Exception:pass

MANAGED_SERVICES=[
    {"id":"postgres","label":"PostgreSQL","container":_pg_target.container,"depends_on":[]},
    {"id":"mesflow","label":"MESFlow","container":os.environ.get("MESFLOW_APP_CONTAINER","mesflow-app"),"depends_on":["postgres"]},
    {"id":"nginx","label":"Gateway / Nginx","container":os.environ.get("MESFLOW_NGINX_CONTAINER","mesflow-nginx"),"depends_on":["mesflow"]},
    {"id":"qa","label":"QA Center","container":os.environ.get("MESFLOW_QA_CONTAINER","mesflow-qa-center"),"depends_on":["mesflow"]},
]

def _docker_pid_owner_map():
    """Best-effort PID->container-name map for currently RUNNING
    containers, used only to label a port conflict's owner in the UI --
    never to decide whether to kill anything (section 7: never blindly
    kill a port owner)."""
    ids_result=_run_capture(["docker","ps","-q"],10)
    ids=[x for x in ids_result.get("stdout","").splitlines() if x.strip()]
    if not ids:return {}
    fmt="{{.Id}}\t{{.Name}}\t{{.State.Pid}}"
    r=_run_capture(["docker","inspect","--format",fmt,*ids],10)
    out={}
    for line in r.get("stdout","").splitlines():
        parts=line.split("\t")
        if len(parts)==3 and parts[2].strip().isdigit():
            pid=int(parts[2].strip())
            if pid:out[pid]=parts[1].lstrip("/")
    return out

_recovery_service=recovery.RecoveryOrchestrator(
    MANAGED_SERVICES,_run_capture,
    mes_status_fn=mes_status,qa_status_fn=qa_status,
    server_role_provider=lambda:SERVER_ROLE,
    hostname_provider=socket.gethostname,
    audit=_recovery_audit,
    listeners_fn=lambda:ops_ports(),  # ops_ports() is defined later in this file; resolve lazily at call time.
    container_pid_lookup_fn=_docker_pid_owner_map,
    allow_production_test_start=str(os.environ.get("MESFLOW_RECOVERY_ALLOW_TEST_START","1")).lower() in {"1","true","yes","on"},
)

def _incident_recovery_recommendation(incident):
    """Attaches the safe recovery action(s) for a known incident type
    (section 6) -- computed fresh at read time from live container
    state, never persisted into incidents.json. Returns None for
    incident types this console has no managed-service mapping for
    (e.g. DISK_CRITICAL) so the UI simply shows no recovery block."""
    try:
        return _recovery_service.recommend_for_incident(incident.get("incident_type",""))
    except recovery.NotManagedError:
        return None

# ---------------------------------------------------------------------
# P5 Multi-server: Server Registry / Fleet Health / Remote Agent client
# ---------------------------------------------------------------------
# Communication reuses the existing, already-tested session+CSRF client
# (_remote_agent_client/_remote_agent_get_json, in production use by
# scripts/promote-test.sh long before this task) rather than a new
# protocol -- see agent_backend/fleet.py's module docstring.
SERVERS_FILE=CONFIG_DIR/"servers.json"
LOCAL_SERVER_ID="local"
_server_registry=fleet.ServerRegistryService(SERVERS_FILE,audit=_db_audit)

def _p5_environment_from_server_role(role):
    """P5's registry vocabulary is deliberately DEV/TEST/PRODUCTION/OTHER
    (section 4) -- NOT the same as P3's environment_label(), which maps
    SERVER_ROLE=DEV to the notification-facing label "LOCAL". Conflating
    the two would make a DEV control-plane node register itself under an
    environment value ("LOCAL") the registry doesn't even accept."""
    role=(role or "").strip().upper()
    if role=="DEV":return "DEV"
    if role in ("TEST","PRODUCTION_TEST"):return "TEST"
    if role=="PRODUCTION":return "PRODUCTION"
    return "OTHER"

def _register_local_server():
    """Section 70: the current host is a first-class server in its own
    registry, using the SAME model remote nodes use -- never a special
    case. Never overwrites an already-registered local record (idempotent
    across restarts)."""
    if _server_registry.get(LOCAL_SERVER_ID):return
    env=_p5_environment_from_server_role(SERVER_ROLE)
    roles=["CONTROL"] if env=="DEV" else ["MESFLOW","POSTGRESQL","DEPLOY_AGENT"]+(["QA"] if QA_URL else [])
    _server_registry.register(server_id=LOCAL_SERVER_ID,name=socket.gethostname() or "local",environment=env,
        roles=roles,agent_url="local",hostname=socket.gethostname(),production_confirmed=(env=="PRODUCTION"),actor="system")
    _server_registry.record_handshake(LOCAL_SERVER_ID,{"agent_id":_agent_instance_id(),
        "agent_version":AGENT_VERSION,"capabilities":AGENT_CAPABILITIES,"hostname":socket.gethostname()},actor="system")

def _normalize_remote_error(exc):
    """Section 65: every remote failure collapses to one of a small,
    UI-meaningful set of codes -- never a raw traceback as the primary
    signal."""
    if isinstance(exc,_RemoteAgentError):
        text=str(exc)
        return (fleet.ERROR_AUTH_FAILED if "LOGIN_FAILED" in text else fleet.ERROR_OPERATION_FAILED),text
    if isinstance(exc,TimeoutError) or isinstance(exc,socket.timeout):
        return fleet.ERROR_TIMEOUT,f"{type(exc).__name__}: {exc}"
    if isinstance(exc,urllib.error.URLError):
        reason=getattr(exc,"reason",exc)
        if isinstance(reason,(TimeoutError,socket.timeout)):return fleet.ERROR_TIMEOUT,f"timeout: {exc}"
        return fleet.ERROR_UNREACHABLE,f"{type(exc).__name__}: {exc}"
    return fleet.ERROR_OPERATION_FAILED,f"{type(exc).__name__}: {exc}"

def _local_fleet_identity():
    return {"agent_id":_agent_instance_id(),"agent_version":AGENT_VERSION,
            "capabilities":AGENT_CAPABILITIES,"hostname":socket.gethostname(),
            "api_protocol_version":API_PROTOCOL_VERSION,"server_role":SERVER_ROLE,
            "mes":mes_status(),"qa":(qa_status() if QA_URL else {"configured":False})}

def _remote_session(server_raw,timeout=25):
    """Returns an authenticated (opener,base) for a non-local registered
    server -- raises _RemoteAgentError/URLError on failure, never silently
    swallowed. `server_raw` must come from ServerRegistryService.get_raw()
    (needs the real credential); never pass a redacted record here."""
    url=server_raw.get("agent_url") or ""
    if not url:raise _RemoteAgentError("REMOTE_AGENT_NOT_CONFIGURED: no agent_url on this server record")
    opener,base,csrf=_remote_agent_client(url,server_raw.get("agent_user") or "admin",server_raw.get("agent_password") or "",timeout=timeout)
    return opener,base,csrf

def _query_remote_agent(server):
    """FleetHealthService.poll_fn -- one bounded-timeout call per server,
    normalized into a RemoteCallResult. `server` here is a REDACTED record
    (from registry.list()); the raw credential is fetched fresh so a stale
    closure never outlives a credential rotation."""
    sid=server["server_id"];t0=time.time()
    if server.get("agent_url")=="local":
        return fleet.RemoteCallResult(ok=True,server_id=sid,operation="health",data=_local_fleet_identity(),duration_ms=int((time.time()-t0)*1000))
    raw=_server_registry.get_raw(sid)
    try:
        opener,base,_csrf=_remote_session(raw,timeout=60)
        status=_remote_agent_get_json(opener,base,"/api/status",timeout=60)
        return fleet.RemoteCallResult(ok=True,server_id=sid,operation="health",data=status,duration_ms=int((time.time()-t0)*1000))
    except Exception as exc:
        code,msg=_normalize_remote_error(exc)
        return fleet.RemoteCallResult(ok=False,server_id=sid,operation="health",error=msg,error_code=code,duration_ms=int((time.time()-t0)*1000))

_fleet_health_service=fleet.FleetHealthService(_server_registry,_query_remote_agent)
FLEET_POLL_SECONDS=max(15,int(os.environ.get("MESFLOW_FLEET_POLL_SECONDS","45")))
_fleet_health_status={"last_run_at":None,"last_success_at":None,"last_error":""}

def _fleet_health_loop():
    while True:
        try:
            _fleet_health_service.poll_once()
            _fleet_health_status["last_run_at"]=now_text();_fleet_health_status["last_success_at"]=now_text();_fleet_health_status["last_error"]=""
        except Exception as e:
            _fleet_health_status["last_run_at"]=now_text();_fleet_health_status["last_error"]=f"{type(e).__name__}: {e}"
            try:append_log(f"Fleet health poll error: {type(e).__name__}: {e}")
            except Exception:pass
        time.sleep(FLEET_POLL_SECONDS)

def start_fleet_health_monitor():
    _register_local_server()
    threading.Thread(target=_fleet_health_loop,daemon=True).start()

_server_deploy_locks={}
_server_deploy_locks_guard=threading.Lock()

def _server_deploy_lock_for(server_id,component):
    # Lock per (server, component) -- section 23: a QA deploy on another
    # server, or a different component on the same server, must not be
    # blocked by an in-flight deploy elsewhere.
    key=f"{server_id}:{component}"
    with _server_deploy_locks_guard:
        lock=_server_deploy_locks.get(key)
        if lock is None:
            lock=threading.Lock();_server_deploy_locks[key]=lock
        return lock

def _deploy_release_to_server(server_id,version,component="mesflow",actor="",confirm=False):
    """Section 20/21: routes a deploy through a REGISTERED server reference
    -- never a raw host/IP taken from the request. Reuses the exact
    upload/status HTTP contract _run_promote_test already uses (same local
    artifact, no remote rebuild); this is the server_id-addressed
    generalization of that same mechanism (section 69: the original
    PRODUCTION_TEST/PRODUCTION env-var-configured promotion buttons keep
    working completely unmodified alongside this new path).

    Stops at "stage + verify digest" (returns digest_match evidence) --
    the remote's own /upload handler queues its own local deploy job
    asynchronously (existing, tested behavior, unchanged here); this
    function does not block waiting for that remote job.

    SAFETY (found the hard way while building this task -- see
    reports/P5_MULTI_SERVER.md "Safety incident"): the remote's /upload
    handler ALWAYS auto-triggers a real local deploy, which runs real
    docker-compose operations against container names fixed by the
    release's own compose.yml (e.g. "mesflow-app"). Docker container names
    are global on a given daemon -- a "remote" Agent that happens to share
    THIS HOST's Docker daemon (a loopback/same-host target) can therefore
    stop/replace the REAL production container of the same name, even
    though it is a different Agent process on a different port. A
    same-host target is refused outright unless the operator explicitly
    opts in, acknowledging the risk, via MESFLOW_ALLOW_LOOPBACK_DEPLOY=1."""
    if component!="mesflow":raise _RemoteAgentError(f"UNSUPPORTED_COMPONENT: {component}")
    record=_server_registry.get(server_id)
    if not record:raise _RemoteAgentError("SERVER_NOT_FOUND")
    if not record.get("enabled") or record.get("registration_status") not in ("ACTIVE","UNREACHABLE"):
        raise _RemoteAgentError(f"SERVER_NOT_DEPLOYABLE: registration_status={record.get('registration_status')}")
    if record.get("environment")=="PRODUCTION":
        # Section 22/72: explicit approval, resolved from the REGISTRY's
        # own environment classification -- never from a request field.
        if os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() not in {"1","true","yes","on"} or not confirm:
            raise _RemoteAgentError("PRODUCTION_DEPLOY_NOT_APPROVED: set MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 on this Agent AND pass confirm=true")
    elif record.get("environment")!="TEST":
        raise _RemoteAgentError(f"UNSUPPORTED_TARGET_ENVIRONMENT: {record.get('environment')} (only TEST/PRODUCTION servers accept deploys)")
    # Authorization is settled above; this is the last gate before any
    # credential resolution or remote call is attempted.
    target_host=urlparse(record.get("agent_url") or "").hostname or ""
    if target_host in ("127.0.0.1","localhost","::1") and os.environ.get("MESFLOW_ALLOW_LOOPBACK_DEPLOY","").strip().lower() not in {"1","true","yes","on"}:
        raise _RemoteAgentError(
            "LOOPBACK_DEPLOY_REFUSED: this server's agent_url resolves to this same host. Deploying to a "
            "same-host target can mutate a REAL container of the same name (container names are global on "
            "a Docker daemon, not isolated per Agent). Set MESFLOW_ALLOW_LOOPBACK_DEPLOY=1 to override, only "
            "in a fully isolated environment with no same-named production container present.")
    lock=_server_deploy_lock_for(server_id,component)
    if not lock.acquire(False):raise _RemoteAgentError("DEPLOY_ALREADY_RUNNING_FOR_THIS_SERVER_COMPONENT")
    try:
        artifact=_artifact_for_release(version)
        if not artifact.get("package") or not Path(artifact["package"]).is_file():
            raise _RemoteAgentError("PACKAGE_NOT_FOUND")
        zip_path=Path(artifact["package"]);local_sha=sha(zip_path)
        if artifact.get("package_sha256") and artifact["package_sha256"]!=local_sha:
            raise _RemoteAgentError("PACKAGE_SHA_SELF_CHECK_FAILED")
        raw=_server_registry.get_raw(server_id)
        opener,base,csrf=_remote_agent_client(raw["agent_url"],raw.get("agent_user") or "admin",raw.get("agent_password") or "",timeout=30)
        target_status=_remote_agent_get_json(opener,base,"/api/status")
        compat=_agent_compatibility(target_status)
        if compat["status"]=="INCOMPATIBLE":raise _RemoteAgentError(f"TARGET_AGENT_INCOMPATIBLE: {compat['reason']}")
        _db_audit("REMOTE_DEPLOY_STARTED",{"server_id":server_id,"version":version,"component":component,"actor":actor,"local_sha256":local_sha[:16]})
        _remote_agent_upload(opener,base,csrf,zip_path,timeout=600)
        # Digest evidence (section 84): read back the remote's OWN manifest
        # for this version and compare -- proves byte-identical transfer,
        # never a remote rebuild.
        remote_releases=_remote_agent_get_json(opener,base,"/api/releases")
        remote_entry=next((r for r in remote_releases.get("items",[]) if canonical_version(r.get("version",""))==canonical_version(version)),None)
        digest_match=bool(remote_entry and remote_entry.get("sha256")==local_sha)
        result={"server_id":server_id,"version":version,"component":component,"local_sha256":local_sha,
                "remote_sha256":(remote_entry or {}).get("sha256",""),"digest_match":digest_match}
        _db_audit("REMOTE_DEPLOY_ARTIFACT_TRANSFERRED",{"server_id":server_id,"version":version,"digest_match":digest_match,"actor":actor})
        return result
    except Exception as exc:
        code=str(exc) if isinstance(exc,_RemoteAgentError) else f"{type(exc).__name__}: {exc}"
        _db_audit("REMOTE_DEPLOY_FAILED",{"server_id":server_id,"version":version,"error":code,"actor":actor})
        raise
    finally:
        lock.release()

def _remote_get_json_for_server(server_id,path,timeout=60):
    """Routes a read-only GET to a REMOTE (never 'local') target resolved
    strictly from the trusted registry -- never a caller-supplied URL
    (section 36/37). Callers must handle the local-server case themselves
    by calling the equivalent in-process function directly (no HTTP
    loopback to self). Returns (ok,data_or_None,error_code,error_message)."""
    record=_server_registry.get(server_id)
    if not record:return False,None,"NOT_FOUND","unknown server_id"
    if not record.get("enabled") or record.get("registration_status") in ("DISABLED","REVOKED"):
        return False,None,"SERVER_DISABLED",f"server is {record.get('registration_status')}"
    raw=_server_registry.get_raw(server_id)
    try:
        opener,base,_csrf=_remote_session(raw,timeout=timeout)
        data=_remote_agent_get_json(opener,base,path,timeout=timeout)
        return True,data,"",""
    except Exception as exc:
        code,msg=_normalize_remote_error(exc)
        return False,None,code,msg

def _remote_post_json_for_server(server_id,path,payload=None,timeout=60):
    """POST-JSON sibling of _remote_get_json_for_server -- same registry-
    resolved-target contract (section 36/37/71)."""
    record=_server_registry.get(server_id)
    if not record:return False,None,"NOT_FOUND","unknown server_id"
    if not record.get("enabled") or record.get("registration_status") in ("DISABLED","REVOKED"):
        return False,None,"SERVER_DISABLED",f"server is {record.get('registration_status')}"
    raw=_server_registry.get_raw(server_id)
    try:
        opener,base,csrf=_remote_session(raw,timeout=timeout)
        data=_remote_agent_post_json(opener,base,path,csrf,payload,timeout=timeout)
        return True,data,"",""
    except Exception as exc:
        code,msg=_normalize_remote_error(exc)
        return False,None,code,msg

def _production_mutation_approved(payload):
    return (os.environ.get("MESFLOW_PRODUCTION_PROMOTE_ENABLED","").strip().lower() in {"1","true","yes","on"}
            and bool(payload.get("confirm")))

def collect_predictive_samples(sampled_at=None):
    """Bounded, read-only sampler. Never runs during an HTTP request."""
    timestamp=sampled_at or datetime.now().astimezone().isoformat()
    root=psutil.disk_usage('/') if os.name!='nt' else psutil.disk_usage(Path.cwd().anchor)
    vm=psutil.virtual_memory()
    rows=[_metric_store.add("disk_used_bytes",root.used,"bytes","root",{"total_bytes":root.total},timestamp),
          _metric_store.add("cpu_percent",psutil.cpu_percent(interval=None),"percent","host",{},timestamp),
          _metric_store.add("ram_percent",vm.percent,"percent","host",{},timestamp)]
    db_size=_postgres_database_size()
    if db_size is not None:
        rows.append(_metric_store.add("db_size_bytes",db_size,"bytes","postgresql",{},timestamp))
        table_rows=_metric_store.samples("db_table_size_bytes",None)
        last_table=max((datetime.fromisoformat(str(x["sampled_at"]).replace("Z","+00:00")).timestamp() for x in table_rows),default=0)
        current_epoch=datetime.fromisoformat(timestamp.replace("Z","+00:00")).timestamp()
        if current_epoch-last_table>=3600:
            for table,size in _postgres_table_sizes():rows.append(_metric_store.add("db_table_size_bytes",size,"bytes",table,{},timestamp))
    return rows

def predictive_summary():
    disk_samples=_metric_store.samples("disk_used_bytes","root")
    disk_capacity=None
    if disk_samples:disk_capacity=(disk_samples[-1].get("metadata") or {}).get("total_bytes")
    disk=linear_forecast(disk_samples,disk_capacity,min_samples=PREDICTIVE_MIN_SAMPLES,min_hours=PREDICTIVE_MIN_HOURS)
    db_samples=_metric_store.samples("db_size_bytes","postgresql")
    db=linear_forecast(db_samples,None,thresholds=(),min_samples=PREDICTIVE_MIN_SAMPLES,min_hours=PREDICTIVE_MIN_HOURS)
    db_anomaly=robust_anomaly(db_samples,min_samples=PREDICTIVE_MIN_SAMPLES)
    disk_anomaly=robust_anomaly(disk_samples,min_samples=PREDICTIVE_MIN_SAMPLES)
    cpu_anomaly=robust_anomaly(_metric_store.samples("cpu_percent","host"),min_samples=PREDICTIVE_MIN_SAMPLES)
    ram_anomaly=robust_anomaly(_metric_store.samples("ram_percent","host"),min_samples=PREDICTIVE_MIN_SAMPLES)
    table_samples=_metric_store.samples("db_table_size_bytes",None);table_names=sorted({x.get("component_id","") for x in table_samples})
    table_growth=[]
    for table in table_names:
        forecast=linear_forecast([x for x in table_samples if x.get("component_id")==table],None,thresholds=(),min_samples=max(5,min(PREDICTIVE_MIN_SAMPLES,8)),min_hours=24)
        latest=max((float(x["value"]) for x in table_samples if x.get("component_id")==table),default=0)
        table_growth.append({"table":table,"current_bytes":latest,"growth_per_day":forecast.growth_per_day,"confidence":forecast.confidence})
    table_growth.sort(key=lambda x:(x["growth_per_day"] or 0,x["current_bytes"]),reverse=True)
    incidents=list(_load_incidents().get("items",{}).values())
    recurring=recurring_failures(incidents)
    insights=[]
    days90=disk.thresholds.get("90") if disk.thresholds else None
    if days90 is not None:
        risk="HIGH" if days90<PREDICTIVE_DISK_HIGH_DAYS else "MEDIUM" if days90<PREDICTIVE_DISK_MEDIUM_DAYS else "LOW" if days90<30 else "INFO"
        insight={"id":"disk-capacity-root","type":"DISK_CAPACITY_RISK","risk":risk,"status":"ACTIVE","predicted":True,
                 "title":f"Disk có thể đạt 90% trong khoảng {max(1,round(days90))} ngày","confidence":disk.confidence,"evidence":{"forecast":asdict(disk)}}
        insight["suggested_checks"]=deterministic_suggestions(insight);insights.append(insight)
    if db_anomaly.get("status")=="ANOMALOUS":
        insight={"id":"db-growth-anomaly","type":"DB_GROWTH_ANOMALY","risk":"MEDIUM","status":"ACTIVE","predicted":True,
                 "title":"Tốc độ tăng PostgreSQL lệch khỏi baseline","confidence":db_anomaly.get("confidence"),"evidence":{"anomaly":db_anomaly,"forecast":asdict(db)}}
        insight["suggested_checks"]=deterministic_suggestions(insight);insights.append(insight)
    for name,anomaly in (("CPU",cpu_anomaly),("RAM",ram_anomaly),("DISK_USAGE",disk_anomaly)):
        if anomaly.get("status")=="ANOMALOUS":insights.append({"id":"anomaly-"+name.lower(),"type":"METRIC_ANOMALY","risk":"LOW","status":"ACTIVE","predicted":True,
            "title":f"{name} khác baseline lịch sử","confidence":anomaly.get("confidence"),"evidence":{"anomaly":anomaly},"suggested_checks":[]})
    for row in recurring[:10]:
        insight={"id":"recurring-"+hashlib.sha256(row["fingerprint"].encode()).hexdigest()[:12],"type":"RECURRING_FAILURE","risk":row["risk"],"status":"ACTIVE","predicted":True,
                 "title":f'{row["fingerprint"]} lặp lại {row["incidents"]} lần',"confidence":"HIGH" if row["incidents"]>=5 else "MEDIUM","evidence":{"recurrence":row}}
        insight["suggested_checks"]=deterministic_suggestions(insight);insights.append(insight)
    risk_order={"HIGH":4,"MEDIUM":3,"LOW":2,"INFO":1};insights.sort(key=lambda x:risk_order.get(x["risk"],0),reverse=True)
    return {"ok":True,"generated_at":now_text(),"learning_baseline":disk.status=="INSUFFICIENT_DATA" and db.status=="INSUFFICIENT_DATA",
            "disk":asdict(disk),"database":{**asdict(db),"fastest_growing_tables":table_growth[:10]},"anomalies":{"database_size":db_anomaly,"disk_usage":disk_anomaly,"cpu":cpu_anomaly,"ram":ram_anomaly},"recurring":recurring,"insights":insights[:20],
            "policy":{"sample_seconds":PREDICTIVE_SAMPLE_SECONDS,"raw_days":PREDICTIVE_RAW_DAYS,"hourly_days":PREDICTIVE_HOURLY_DAYS,"daily_days":PREDICTIVE_DAILY_DAYS,
                      "minimum_samples":PREDICTIVE_MIN_SAMPLES,"minimum_hours":PREDICTIVE_MIN_HOURS}}

def _predictive_monitor_loop():
    while True:
        try:collect_predictive_samples()
        except Exception as error:
            try:append_log(f"Predictive sampler degraded: {type(error).__name__}: {error}")
            except Exception:pass
        time.sleep(PREDICTIVE_SAMPLE_SECONDS)

def start_predictive_monitor():
    threading.Thread(target=_predictive_monitor_loop,daemon=True).start()

def ops_backups():
    """Read-only rollback/backup readiness: what _create_linux_backup() has
    produced so far, and free space where the next one would land. Never
    creates, deletes or restores anything."""
    root=DATA_DIR/"mes_backups"
    entries=[]
    if root.is_dir():
        for d in sorted(root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            if not d.is_dir(): continue
            first_install=(d/"FIRST_INSTALL_BACKUP_MARKER").is_file() or any(d.glob(".mesflow_first_install_baseline"))
            version=""
            vfile=d/"VERSION.txt"
            if vfile.is_file():
                try: version=vfile.read_text(encoding="utf-8-sig").strip()
                except OSError: pass
            entries.append({"name":d.name,"modified_at":datetime.fromtimestamp(d.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                             "version":version,"first_install_baseline":first_install})
    try:
        free_bytes=shutil.disk_usage(root if root.is_dir() else DATA_DIR).free
    except OSError:
        free_bytes=None
    return {"count":len(entries),"most_recent":entries[0] if entries else None,"entries":entries[:20],
            "free_space":_bytes(free_bytes) if free_bytes is not None else "unknown",
            "mechanism":"automatic: a fresh backup of the current release is created immediately before every deploy cutover; rollback restores it if verification fails"}

def ops_services():
    if os.name=='nt': return []
    cmd=["systemctl","list-units","--type=service","--all","--no-legend","--plain","--no-pager"]
    r=_run_capture(cmd,10); out=[]
    for ln in r.get("stdout","").splitlines():
        parts=ln.split(None,4)
        if len(parts)>=4:
            unit,load,active,sub=parts[:4]; desc=parts[4] if len(parts)>4 else ''
            out.append({"unit":unit,"load":load,"active":active,"sub":sub,"description":desc})
    return out

def ops_docker():
    if not shutil.which('docker'): return []
    fmt='{{json .}}'
    r=_run_capture(["docker","ps","-a","--no-trunc","--format",fmt],12); out=[]
    for ln in r.get('stdout','').splitlines():
        try: out.append(json.loads(ln))
        except json.JSONDecodeError: pass
    return out

def ops_ports():
    rows=[]
    try:
        for c in psutil.net_connections(kind='inet'):
            if c.status != psutil.CONN_LISTEN or not c.laddr: continue
            pid=c.pid or 0; name=''
            if pid:
                try:name=psutil.Process(pid).name()
                except Exception: pass
            rows.append({"ip":c.laddr.ip,"port":c.laddr.port,"pid":pid,"process":name})
    except (psutil.AccessDenied,PermissionError): pass
    return sorted(rows,key=lambda x:(x['port'],x['ip']))

def _dangerous_command(cmd):
    c=' '.join((cmd or '').strip().lower().split())
    patterns=[r'(^|[;&|])\s*rm\s+-[^\n]*r[^\n]*\s+/(\s|$)',r'\bmkfs\b',r'\bdd\s+if=',r'\b(shutdown|reboot|poweroff|halt)\b',
              r'docker\s+system\s+prune',r'docker\s+volume\s+(rm|prune)',r'\b(drop\s+database|drop\s+table|truncate\s+table)\b']
    return any(re.search(p,c,re.I) for p in patterns)

def _ssh_exec(host,port,user,command,password=None,key_path=None,timeout=12):
    client=paramiko.SSHClient(); client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    kwargs={"hostname":host,"port":int(port or 22),"username":user,"timeout":timeout,"banner_timeout":timeout,"auth_timeout":timeout,"look_for_keys":True,"allow_agent":True}
    if password: kwargs['password']=password
    if key_path: kwargs['key_filename']=os.path.expanduser(key_path)
    started=time.time()
    try:
        client.connect(**kwargs)
        stdin,stdout,stderr=client.exec_command(command,timeout=max(timeout,30),get_pty=False)
        out=stdout.read().decode('utf-8',errors='replace'); err=stderr.read().decode('utf-8',errors='replace'); code=stdout.channel.recv_exit_status()
        return {"ok":code==0,"exit_code":code,"stdout":out[-200000:],"stderr":err[-50000:],"duration_ms":int((time.time()-started)*1000)}
    except Exception as ex:
        return {"ok":False,"exit_code":-1,"stdout":"","stderr":str(ex),"duration_ms":int((time.time()-started)*1000)}
    finally:
        client.close()

@app.get('/ops')
def ops_page():
    view=request.args.get('view','overview')
    # Real bug found+fixed (reports/SERVICES_DIAGNOSTICS_AUDIT_FIX.md):
    # 'diagnostics' used to have no view/section of its own -- the sidebar's
    # "Chẩn đoán" link pointed at ?view=services (the generic host/systemd
    # units list, HỆ THỐNG group), and this page_keys dict force-mapped that
    # SAME view to page_key='diagnostics' so that one link would highlight
    # correctly. But the HỆ THỐNG group has its own, separate "Services"
    # link to that identical ?view=services URL expecting page_key='services'
    # -- so clicking THAT link always ended up highlighting "Chẩn đoán"
    # instead, and neither link ever showed anything resembling diagnosis.
    # Diagnostics is now a real, distinct view/section (see ops.html) with
    # its own URL, so no special-case remap is needed for it any more.
    allowed={'overview','fleet','alerts','incidents','services','diagnostics','docker','ports','backup','logs','terminal','recovery'}
    if view not in allowed:view='overview'
    # 'overview' still needs remapping: this page's own ?view=overview (Sức
    # khoẻ hệ thống) must not collide with the dashboard route's
    # page_key='overview' (Tổng quan, a different sidebar group entirely).
    page_keys={'overview':'health'}
    return render_template('ops.html',csrf=session.get('csrf',''),agent_version=AGENT_VERSION,
                           server_role=SERVER_ROLE,initial_view=view,page_key=page_keys.get(view,view),
                           initial_target=request.args.get('target',''))

def _internal_allowed():
    # Same shared secret/pattern MESFlow itself uses for the reverse direction
    # (mesflow.web.internal_ota._internal_allowed): a constant-time compare
    # against MESFLOW_INTERNAL_API_TOKEN, already provisioned on both sides.
    expected=str(os.environ.get("MESFLOW_INTERNAL_API_TOKEN") or "").strip()
    supplied=str(request.headers.get("X-MESFlow-Internal-Token") or "").strip()
    return bool(expected and supplied and hmac.compare_digest(expected,supplied))

@app.get('/api/ops/summary', endpoint='ops_summary')
@app.get('/api/ops/summary')
def api_ops_summary():
    # Exempted from the blanket before_request login-redirect (see protect())
    # so MESFlow's System Health provider can read CPU/RAM/Disk/Docker
    # without a browser session -- but still requires either a real login
    # session (existing Ops Console UI) or the shared internal token.
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    summary=ops_summary()
    # section 35: if the notification/incident monitor loop stops running,
    # System Health must eventually show this subsystem as degraded rather
    # than silently losing alerts.
    summary["notifications"]={**_notification_health,"channels":_notification_dispatcher.channel_status()}
    return jsonify(summary)

@app.get('/api/ops/backups')
def api_ops_backups(): return jsonify(ops_backups())

@app.get('/api/incidents')
def api_incidents():
    # Same availability contract as /api/ops/summary: usable via this
    # Agent's own login OR the shared internal token, deliberately NOT
    # coupled to MESFlow's own session (section 5 -- must stay reachable
    # when MESFlow itself is down).
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    status=request.args.get('status','').strip().upper()
    items=list(_load_incidents().get('items',{}).values())
    if status:items=[i for i in items if i.get('status')==status]
    items.sort(key=lambda i:i.get('last_seen_at',''),reverse=True)
    return jsonify({"ok":True,"items":items})

@app.get('/api/incidents/<incident_id>')
def api_incident_detail(incident_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    item=next((i for i in _load_incidents().get('items',{}).values() if i.get('incident_id')==incident_id),None)
    if not item:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    item=dict(item);item["recovery"]=_incident_recovery_recommendation(item)
    return jsonify({"ok":True,"item":item})

@app.get('/api/ops/predictions')
def api_ops_predictions():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify(predictive_summary())

@app.get('/api/ops/metrics/<metric>/trend')
def api_ops_metric_trend(metric):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    if metric not in {"disk_used_bytes","db_size_bytes","cpu_percent","ram_percent"}:return jsonify({"ok":False,"error":"UNKNOWN_METRIC"}),404
    component={"disk_used_bytes":"root","db_size_bytes":"postgresql","cpu_percent":"host","ram_percent":"host"}[metric]
    rows=_metric_store.samples(metric,component)
    return jsonify({"ok":True,"metric":metric,"component_id":component,"items":rows[-1000:]})

def _incident_by_id(incident_id):
    return next((i for i in _load_incidents().get('items',{}).values() if i.get('incident_id')==incident_id),None)

@app.get('/api/incidents/<incident_id>/ai-analysis')
def api_incident_ai_analysis(incident_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    incident=_incident_by_id(incident_id)
    if not incident:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    summary=predictive_summary()
    return jsonify({"ok":True,"analysis":_incident_ai.analyze(incident,{"disk":summary["disk"],"database":summary["database"],"anomalies":summary["anomalies"]},summary["recurring"])})

@app.post('/api/incidents/<incident_id>/ai-analysis/regenerate')
def api_incident_ai_regenerate(incident_id):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf();incident=_incident_by_id(incident_id)
    if not incident:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    summary=predictive_summary()
    analysis=_incident_ai.analyze(incident,{"disk":summary["disk"],"database":summary["database"],"anomalies":summary["anomalies"]},summary["recurring"],force=True)
    analysis["requested_by"]=session.get("username","")
    return jsonify({"ok":True,"analysis":analysis})

@app.post('/api/incidents/<incident_id>/acknowledge')
def api_incident_acknowledge(incident_id):
    # Acknowledging is a human decision, not a monitoring signal --
    # requires a real login session (never the internal token) and CSRF,
    # same as every other state-changing route in this Agent.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    store=_load_incidents()
    for inc in store.get('items',{}).values():
        if inc.get('incident_id')==incident_id:
            inc['status']='ACKNOWLEDGED';inc['acknowledged_by']=session.get('username','')
            _save_incidents(store)
            return jsonify({"ok":True,"item":inc})
    return jsonify({"ok":False,"error":"NOT_FOUND"}),404

@app.post('/api/incidents/<incident_id>/resolve')
def api_incident_resolve(incident_id):
    # Manual resolve, e.g. a known false positive or a fix already applied
    # out of band -- still just a status/text update, never triggers any
    # infrastructure action (section 14).
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    reason=str((request.get_json(silent=True) or {}).get('reason','')).strip()
    store=_load_incidents()
    for inc in store.get('items',{}).values():
        if inc.get('incident_id')==incident_id:
            inc['status']='RESOLVED';inc['resolved_at']=now_text();inc['resolution_reason']=reason
            if inc.get('cycles') and not inc['cycles'][-1].get('resolved_at'):inc['cycles'][-1]['resolved_at']=inc['resolved_at']
            _save_incidents(store)
            return jsonify({"ok":True,"item":inc})
    return jsonify({"ok":False,"error":"NOT_FOUND"}),404

@app.get('/api/incidents/<incident_id>/notifications')
def api_incident_notifications(incident_id):
    # section 37 (Incident Drawer "Notifications" section) -- same
    # availability contract as the incident routes themselves.
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    incident=_incident_by_id(incident_id)
    if not incident:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"items":_notification_dispatcher.deliveries_for(incident_id)})

@app.get('/api/notification-channels')
def api_notification_channels():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"ok":True,"channels":_notification_dispatcher.channel_status(),
        "min_severity":_notification_dispatcher.min_severity,"environment":_notification_dispatcher.environment})

@app.post('/api/notification-channels/<channel>/test')
def api_notification_channel_test(channel):
    # section 31: explicit admin-only test send, never a fabricated incident.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    if channel.upper() not in ('WEB','TELEGRAM','EMAIL'):return jsonify({"ok":False,"error":"UNKNOWN_CHANNEL"}),400
    return jsonify(_notification_dispatcher.test_send(channel.upper()))

# ---------------------------------------------------------------------
# P4 Backup / DB / Storage Center
# ---------------------------------------------------------------------

@app.get('/api/ops/db/summary')
def api_ops_db_summary():
    # Same availability contract as /api/ops/predictions -- a read-only
    # diagnostic view, usable via this Agent's own login or the internal
    # token, never coupled to MESFlow's own session.
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    summary=db_backup.postgres_summary(_pg_target)
    fastest_growing=predictive_summary()["database"].get("fastest_growing_tables",[])
    summary["fastest_growing_tables"]=fastest_growing
    return jsonify({"ok":True,**summary})

@app.get('/api/ops/db-backups')
def api_ops_db_backups():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"ok":True,"items":_db_backup_service.list()})

@app.post('/api/ops/db-backups')
def api_ops_db_backups_create():
    # Manual PostgreSQL backup (P4 vertical slice 1) -- a real login
    # session and CSRF, same bar as every other state-changing route in
    # this Agent. Never runs automatically from this route.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    payload=request.get_json(silent=True) or {}
    retention_class=str(payload.get('retention_class') or 'manual').strip()
    reason=str(payload.get('reason') or '').strip()
    try:
        record=_db_backup_service.create(retention_class=retention_class,triggered_by=session.get('username',''),reason=reason)
    except ValueError as e:
        return jsonify({"ok":False,"error":"INVALID_RETENTION_CLASS","detail":str(e)}),400
    except db_backup.ConflictError as e:
        return jsonify({"ok":False,"error":"BACKUP_ALREADY_RUNNING","detail":str(e)}),409
    status=200 if record.get('status')=='SUCCESS' else 502
    return jsonify({"ok":record.get('status')=='SUCCESS',"item":record}),status

@app.get('/api/ops/db-backups/<backup_id>')
def api_ops_db_backup_detail(backup_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    record=_db_backup_service.get(backup_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"item":record})

@app.post('/api/ops/db-backups/<backup_id>/verify')
def api_ops_db_backup_verify(backup_id):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    if not _db_backup_service.get(backup_id):return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    try:
        record=_db_backup_service.verify(backup_id)
    except ValueError as e:
        return jsonify({"ok":False,"error":"CANNOT_VERIFY","detail":str(e)}),400
    return jsonify({"ok":record.get('verification_status')=='VERIFIED',"item":record})

@app.post('/api/ops/db-backups/<backup_id>/pin')
def api_ops_db_backup_pin(backup_id):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    if not _db_backup_service.get(backup_id):return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"item":_db_backup_service.pin(backup_id,actor=session.get('username',''))})

@app.post('/api/ops/db-backups/<backup_id>/unpin')
def api_ops_db_backup_unpin(backup_id):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    if not _db_backup_service.get(backup_id):return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"item":_db_backup_service.unpin(backup_id,actor=session.get('username',''))})

@app.post('/api/ops/db-backups/<backup_id>/restore-test')
def api_ops_db_backup_restore_test(backup_id):
    # Restore Drill (P4 vertical slice 3): LOCAL/TEST only, isolated
    # generated temp DB, never Production -- section 21/55. An explicit
    # confirm flag is required in addition to login+CSRF because this is a
    # "controlled IT action" against a real Postgres server, even though
    # the target database itself is always a disposable throwaway.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    if environment_label(SERVER_ROLE)=='PRODUCTION':
        return jsonify({"ok":False,"error":"RESTORE_DRILL_BLOCKED_IN_PRODUCTION",
            "detail":"Restore drills are only permitted in LOCAL/TEST environments (SERVER_ROLE=%s)"%SERVER_ROLE}),403
    payload=request.get_json(silent=True) or {}
    if not payload.get('confirm'):
        return jsonify({"ok":False,"error":"CONFIRMATION_REQUIRED","detail":"POST {\"confirm\": true} to run a restore drill"}),400
    record=_db_backup_service.get(backup_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    try:
        drill=_db_restore_drill_service.run(record)
    except db_backup.RestoreDrillError as e:
        return jsonify({"ok":False,"error":"RESTORE_DRILL_REJECTED","detail":str(e)}),400
    if drill.get('status')=='SUCCESS':
        _db_backup_service.mark_restore_tested(backup_id)
    return jsonify({"ok":drill.get('status')=='SUCCESS',"item":drill})

@app.get('/api/ops/restore-drills')
def api_ops_restore_drills():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"ok":True,"items":_db_restore_drill_service.list()})

@app.get('/api/ops/storage')
def api_ops_storage():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"ok":True,"filesystem":_db_storage_service.filesystem_summary(str(DATA_DIR)),
        "categories":_db_storage_service.category_sizes(),"docker":_db_storage_service.docker_storage()})

@app.get('/api/ops/storage/retention/preview')
def api_ops_storage_retention_preview():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"ok":True,**_db_retention_service.preview(active_restore_source=_active_restore_drill_source())})

@app.post('/api/ops/storage/retention/apply')
def api_ops_storage_retention_apply():
    # Backup Retention (P4 vertical slice 2): deletes real backup files on
    # disk -- explicit confirm required in addition to login+CSRF (section
    # 61: destructive/high-risk actions must never run automatically).
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    payload=request.get_json(silent=True) or {}
    if not payload.get('confirm'):
        return jsonify({"ok":False,"error":"CONFIRMATION_REQUIRED","detail":"POST {\"confirm\": true} to apply retention"}),400
    reason=str(payload.get('reason') or '').strip()
    result=_db_retention_service.apply(actor=session.get('username',''),reason=reason,active_restore_source=_active_restore_drill_source())
    return jsonify({"ok":True,**result})

@app.get('/api/ops/db-audit')
def api_ops_db_audit():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    items=list(reversed(load_json(DB_AUDIT_FILE,{"items":[]}).get('items',[])))
    return jsonify({"ok":True,"items":items[:500]})

# ---------------------------------------------------------------------
# P5 Multi-server: Server Registry / Fleet Health API
# ---------------------------------------------------------------------

def _server_with_cache(record):
    cached=_fleet_health_service.cached().get(record["server_id"])
    out=dict(record)
    if cached:out["last_poll"]={"ok":cached.ok,"error_code":cached.error_code,"duration_ms":cached.duration_ms,"correlation_id":cached.correlation_id}
    return out

@app.get('/api/servers')
def api_servers_list():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    environment=request.args.get('environment','').strip().upper() or None
    items=[_server_with_cache(s) for s in _server_registry.list(environment=environment)]
    return jsonify({"ok":True,"items":items,"summary":_fleet_health_service.fleet_summary()})

@app.post('/api/servers')
def api_servers_register():
    # Registering a server is a privileged, audited action (section 8/61) --
    # never available via the internal token, always a real login+CSRF.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    payload=request.get_json(silent=True) or {}
    name=str(payload.get('name') or '').strip()
    environment=str(payload.get('environment') or '').strip().upper()
    if not name:return jsonify({"ok":False,"error":"NAME_REQUIRED"}),400
    try:
        record=_server_registry.register(name=name,environment=environment,roles=payload.get('roles') or [],
            agent_url=str(payload.get('agent_url') or '').strip(),agent_user=str(payload.get('agent_user') or 'admin').strip(),
            agent_password=str(payload.get('agent_password') or ''),tags=payload.get('tags') or [],
            hostname=str(payload.get('hostname') or '').strip(),
            production_confirmed=bool(payload.get('production_confirmed')),actor=session.get('username',''))
    except ValueError as e:
        return jsonify({"ok":False,"error":"INVALID_ENVIRONMENT","detail":str(e)}),400
    except fleet.ProductionConfirmationRequired as e:
        return jsonify({"ok":False,"error":"PRODUCTION_CONFIRMATION_REQUIRED","detail":str(e)}),403
    return jsonify({"ok":True,"item":record})

@app.get('/api/servers/<server_id>')
def api_server_detail(server_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"item":_server_with_cache(record)})

@app.post('/api/servers/<server_id>/test-connection')
def api_server_test_connection(server_id):
    # Section 60: a live handshake NOW (never the cache) -- reachable,
    # authenticated, agent_id/version/hostname/capabilities, all shown
    # before the server is trusted with anything else.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    result=_query_remote_agent(record)
    if not result.ok:
        _server_registry.record_handshake_failure(server_id,result.error,actor=session.get('username',''))
        return jsonify({"ok":False,"error":result.error_code,"detail":result.error}),502
    try:
        updated=_server_registry.record_handshake(server_id,result.data,actor=session.get('username',''))
    except fleet.DuplicateAgentIdentity as e:
        return jsonify({"ok":False,"error":"DUPLICATE_AGENT_IDENTITY","detail":str(e)}),409
    compatibility=_agent_compatibility(result.data)
    return jsonify({"ok":True,"item":updated,"identity":result.data,"compatibility":compatibility})

@app.post('/api/servers/<server_id>/disable')
def api_server_disable(server_id):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    if not _server_registry.get(server_id):return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"item":_server_registry.disable(server_id,actor=session.get('username',''))})

@app.post('/api/servers/<server_id>/enable')
def api_server_enable(server_id):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    if not _server_registry.get(server_id):return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"item":_server_registry.enable(server_id,actor=session.get('username',''))})

@app.get('/api/servers/<server_id>/health')
def api_server_health(server_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    return jsonify({"ok":True,"item":_server_with_cache(record)})

@app.post('/api/servers/<server_id>/diagnostics')
def api_server_diagnostics(server_id):
    # Section 36: an allowlisted diagnostic, resolved strictly from the
    # registry -- an immediate live health/status refresh, never an
    # arbitrary remote command. This is the entire allowlist for now.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    if not record.get("enabled"):return jsonify({"ok":False,"error":"SERVER_DISABLED"}),409
    result=_query_remote_agent(record)
    if result.ok:_server_registry.update_health_cache(server_id,fleet.classify_health(now_text()),result.data,last_seen=now_text())
    else:_server_registry.record_handshake_failure(server_id,result.error)
    return jsonify({"ok":result.ok,"error_code":result.error_code,"error":result.error,
        "correlation_id":result.correlation_id,"duration_ms":result.duration_ms,"data":result.data})

@app.get('/api/servers/<server_id>/storage')
def api_server_storage(server_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    if record.get("agent_url")=="local":
        return jsonify({"ok":True,"server_id":server_id,"filesystem":_db_storage_service.filesystem_summary(str(DATA_DIR)),
            "categories":_db_storage_service.category_sizes(),"docker":_db_storage_service.docker_storage()})
    ok,data,code,msg=_remote_get_json_for_server(server_id,"/api/ops/storage")
    if not ok:return jsonify({"ok":False,"error":code,"detail":msg}),502
    return jsonify({"ok":True,"server_id":server_id,**{k:v for k,v in data.items() if k!="ok"}})

@app.get('/api/servers/<server_id>/backups')
def api_server_backups(server_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    if record.get("agent_url")=="local":
        return jsonify({"ok":True,"server_id":server_id,"items":_db_backup_service.list()})
    ok,data,code,msg=_remote_get_json_for_server(server_id,"/api/ops/db-backups")
    if not ok:return jsonify({"ok":False,"error":code,"detail":msg}),502
    return jsonify({"ok":True,"server_id":server_id,"items":data.get("items",[])})

@app.post('/api/servers/<server_id>/backups')
def api_server_backup_create(server_id):
    # Vertical slice 3 (section 92): DEV requests a REAL backup ON the
    # target server -- the backup itself always executes locally on that
    # server (never centrally), matching section 28's flow exactly. A
    # PRODUCTION-registered target needs the same explicit approval as a
    # PRODUCTION deploy (section 72) -- never just because environment
    # happens to say "test" in the request body.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    payload=request.get_json(silent=True) or {}
    if record.get("environment")=="PRODUCTION" and not _production_mutation_approved(payload):
        return jsonify({"ok":False,"error":"PRODUCTION_BACKUP_NOT_APPROVED",
            "detail":"set MESFLOW_PRODUCTION_PROMOTE_ENABLED=1 on this Agent AND pass confirm=true"}),403
    # Defense-in-depth (same root cause as the deploy loopback guard, see
    # _deploy_release_to_server's docstring): a same-host "remote" target
    # is where a misconfigured/defaulted container name (e.g. an unset
    # MESFLOW_POSTGRES_CONTAINER falling back to the real "mesflow-postgres")
    # could reach real infrastructure instead of the intended throwaway one.
    _backup_target_host=urlparse(record.get("agent_url") or "").hostname or ""
    if record.get("agent_url")!="local" and _backup_target_host in ("127.0.0.1","localhost","::1") and os.environ.get("MESFLOW_ALLOW_LOOPBACK_BACKUP","").strip().lower() not in {"1","true","yes","on"}:
        return jsonify({"ok":False,"error":"LOOPBACK_BACKUP_REFUSED",
            "detail":"this server's agent_url resolves to this same host; set MESFLOW_ALLOW_LOOPBACK_BACKUP=1 to override"}),403
    reason=str(payload.get('reason') or '').strip() or f"remote backup via fleet (actor={session.get('username','')})"
    actor=session.get('username','')
    _db_audit("REMOTE_BACKUP_STARTED",{"server_id":server_id,"actor":actor})
    if record.get("agent_url")=="local":
        try:
            item=_db_backup_service.create(retention_class="manual",triggered_by=actor,reason=reason)
        except db_backup.ConflictError as e:
            return jsonify({"ok":False,"error":"BACKUP_ALREADY_RUNNING","detail":str(e)}),409
        _db_audit("REMOTE_BACKUP_COMPLETED",{"server_id":server_id,"backup_id":item.get('backup_id'),"status":item.get('status')})
        return jsonify({"ok":item.get('status')=='SUCCESS',"server_id":server_id,"item":item})
    # A real pg_dump + upload/login round trip can legitimately take longer
    # than a simple JSON call under host load -- generous timeout here on
    # purpose (this is a rare, explicit, human-triggered action, not a
    # polled one).
    ok,data,code,msg=_remote_post_json_for_server(server_id,"/api/ops/db-backups",{"retention_class":"manual","reason":reason},timeout=180)
    if not ok:
        _db_audit("REMOTE_BACKUP_FAILED",{"server_id":server_id,"error":msg})
        return jsonify({"ok":False,"error":code,"detail":msg}),502
    item=data.get("item") or {}
    _db_audit("REMOTE_BACKUP_COMPLETED",{"server_id":server_id,"backup_id":item.get('backup_id'),"status":item.get('status')})
    return jsonify({"ok":data.get("ok",False),"server_id":server_id,"item":item})

@app.get('/api/servers/<server_id>/incidents')
def api_server_incidents(server_id):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    record=_server_registry.get(server_id)
    if not record:return jsonify({"ok":False,"error":"NOT_FOUND"}),404
    if record.get("agent_url")=="local":
        return jsonify({"ok":True,"server_id":server_id,"items":list(_load_incidents().get('items',{}).values())})
    ok,data,code,msg=_remote_get_json_for_server(server_id,"/api/incidents")
    if not ok:return jsonify({"ok":False,"error":code,"detail":msg}),502
    return jsonify({"ok":True,"server_id":server_id,"items":data.get("items",[])})

@app.get('/api/fleet/summary')
def api_fleet_summary():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    counts=_fleet_health_service.fleet_summary()
    active_incidents=[]
    for server in _server_registry.list(enabled=True):
        sid=server["server_id"]
        if server.get("agent_url")=="local":
            items=list(_load_incidents().get('items',{}).values())
        else:
            ok,data,_code,_msg=_remote_get_json_for_server(sid,"/api/incidents?status=ACTIVE")
            items=(data or {}).get("items",[]) if ok else []
        for inc in items:
            if inc.get("status") in ("ACTIVE","ACKNOWLEDGED"):
                active_incidents.append({"server_id":sid,"server_name":server.get("name"),"environment":server.get("environment"),
                    "incident_type":inc.get("incident_type"),"severity":inc.get("severity"),"summary":inc.get("summary")})
    counts["active_incidents"]=len(active_incidents)
    return jsonify({"ok":True,"counts":counts,"active_incidents":active_incidents[:50]})

@app.post('/api/servers/<server_id>/deploy')
def api_server_deploy(server_id):
    # Vertical slice 2 (section 91): server_id-routed deploy, reusing the
    # exact same artifact-upload/digest contract as the existing
    # PRODUCTION_TEST/PRODUCTION promotion buttons -- never a raw URL from
    # the request, never a rebuild on the remote.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf()
    payload=request.get_json(silent=True) or {}
    version=str(payload.get('version') or '').strip()
    component=str(payload.get('component') or 'mesflow').strip()
    if not version:return jsonify({"ok":False,"error":"VERSION_REQUIRED"}),400
    try:
        result=_deploy_release_to_server(server_id,version,component=component,
            actor=session.get('username',''),confirm=bool(payload.get('confirm')))
    except _RemoteAgentError as e:
        code=str(e)
        # Authorization/safety refusals (never even attempted a remote call)
        # are client errors -- 403, not 502. 502 is reserved for an actual
        # remote-communication failure.
        if "ALREADY_RUNNING" in code:return jsonify({"ok":False,"error":code}),409
        if "NOT_FOUND" in code:return jsonify({"ok":False,"error":code}),404
        if any(k in code for k in ("NOT_APPROVED","REFUSED","NOT_DEPLOYABLE","UNSUPPORTED_")):
            return jsonify({"ok":False,"error":code}),403
        return jsonify({"ok":False,"error":code}),502
    return jsonify({"ok":result.get("digest_match",False),"item":result})

@app.get('/api/releases')
def api_releases():
    # Read-only, session-or-internal-token gated like every other ops
    # route -- used both by the Fleet deploy-digest-verification flow
    # above and by the multi-server release-status comparison (section 24).
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"ok":True,"items":list_releases()})

@app.get('/api/ops/services')
def api_ops_services(): return jsonify({"items":ops_services()})

@app.get('/api/ops/docker')
def api_ops_docker():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"items":ops_docker()})

@app.get('/api/ops/ports')
def api_ops_ports(): return jsonify({"items":ops_ports()})

@app.get('/api/ops/logs')
def api_ops_logs():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    source=request.args.get('source','agent'); lines=max(20,min(1000,int(request.args.get('lines','200'))))
    allowed={
        'agent': ['journalctl','-u','mesflow-deploy-agent.service','-n',str(lines),'--no-pager'],
        'mesflow': ['docker','logs','--tail',str(lines),'mesflow-app'],
        'postgres': ['docker','logs','--tail',str(lines),'mesflow-postgres'],
        'nginx': ['journalctl','-u','nginx.service','-n',str(lines),'--no-pager'],
        'qa': ['journalctl','-u','mesflow-qa-center.service','-n',str(lines),'--no-pager'],
        'kernel': ['journalctl','-k','-p','warning','-n',str(lines),'--no-pager'],
        'errors': ['journalctl','-p','err','-n',str(lines),'--no-pager'],
    }
    cmd=allowed.get(source)
    if not cmd: return jsonify({"ok":False,"error":"Unknown log source"}),400
    r=_run_capture(cmd,15); return jsonify(r)

@app.post('/api/ops/local-command')
def api_ops_local_command():
    if not HOST_OPS_ENABLED: return jsonify({"ok":False,"error":"Host-local command execution is disabled in this runtime"}),403
    verify_csrf(); d=request.get_json(silent=True) or {}; cmd=str(d.get('command','')).strip()
    if not cmd: return jsonify({"ok":False,"error":"Command is empty"}),400
    if len(cmd)>4000: return jsonify({"ok":False,"error":"Command too long"}),400
    if _dangerous_command(cmd) and not d.get('confirm_dangerous'):
        return jsonify({"ok":False,"needs_confirmation":True,"error":"Lệnh có khả năng phá dữ liệu hoặc reboot. Xác nhận để chạy."}),409
    append_log(f"OPS local command: {cmd[:500]}")
    return jsonify(_run_capture(cmd,timeout=max(5,min(120,int(d.get('timeout',30)))),shell=True))

@app.post('/api/ops/ssh-command')
def api_ops_ssh_command():
    verify_csrf(); d=request.get_json(silent=True) or {}
    host=str(d.get('host','')).strip(); user=str(d.get('user','')).strip(); command=str(d.get('command','')).strip()
    if not host or not user or not command: return jsonify({"ok":False,"error":"Host, user và command là bắt buộc"}),400
    if len(command)>4000: return jsonify({"ok":False,"error":"Command too long"}),400
    if _dangerous_command(command) and not d.get('confirm_dangerous'):
        return jsonify({"ok":False,"needs_confirmation":True,"error":"Lệnh SSH có khả năng phá dữ liệu hoặc reboot. Xác nhận để chạy."}),409
    append_log(f"OPS SSH {user}@{host}:{d.get('port',22)} command: {command[:500]}")
    result=_ssh_exec(host,d.get('port',22),user,command,password=d.get('password') or None,key_path=d.get('key_path') or None,timeout=max(5,min(60,int(d.get('timeout',15)))))
    return jsonify(result)

@app.post('/api/ops/service-action')
def api_ops_service_action():
    if not HOST_OPS_ENABLED: return jsonify({"ok":False,"error":"systemd service actions are disabled in this runtime"}),403
    verify_csrf(); d=request.get_json(silent=True) or {}; unit=str(d.get('unit','')); action=str(d.get('action',''))
    if not re.fullmatch(r'[A-Za-z0-9_.@:-]+\.service',unit) or action not in {'start','stop','restart'}: return jsonify({"ok":False,"error":"Invalid service/action"}),400
    append_log(f"OPS systemctl {action} {unit}")
    return jsonify(_run_capture(['systemctl',action,unit],30))

@app.post('/api/ops/docker-action')
def api_ops_docker_action():
    verify_csrf(); d=request.get_json(silent=True) or {}; name=str(d.get('name','')); action=str(d.get('action',''))
    if not re.fullmatch(r'[A-Za-z0-9_.-]+',name) or action not in {'start','stop','restart'}: return jsonify({"ok":False,"error":"Invalid container/action"}),400
    append_log(f"OPS docker {action} {name}")
    return jsonify(_run_capture(['docker',action,name],60))

# ---------------------------------------------------------------------
# Server Incident Recovery Console -- managed-allowlist-only routes.
# Every route below rejects a `sid` outside MANAGED_SERVICES with a 404
# NOT_MANAGED before touching Docker at all -- this is what makes
# "unrelated containers stay read-only" a server-enforced guarantee, not
# just something the UI happens to not offer (task section 1/13).
# ---------------------------------------------------------------------

@app.get('/api/ops/recovery/services')
def api_recovery_services():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify({"ok":True,"items":_recovery_service.list_service_views()})

@app.get('/api/ops/recovery/services/<sid>')
def api_recovery_service_detail(sid):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    try:return jsonify({"ok":True,"item":_recovery_service.service_view(sid)})
    except recovery.NotManagedError:return jsonify({"ok":False,"error":"NOT_MANAGED"}),404

@app.get('/api/ops/recovery/services/<sid>/logs')
def api_recovery_service_logs(sid):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    lines=max(20,min(2000,int(request.args.get('lines','200') or 200)))
    try:return jsonify(_recovery_service.logs(sid,lines=lines))
    except recovery.NotManagedError:return jsonify({"ok":False,"error":"NOT_MANAGED"}),404

@app.get('/api/ops/recovery/services/<sid>/ports')
def api_recovery_service_ports(sid):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    try:return jsonify({"ok":True,"items":_recovery_service.ports(sid)})
    except recovery.NotManagedError:return jsonify({"ok":False,"error":"NOT_MANAGED"}),404

@app.post('/api/ops/recovery/services/<sid>/start')
def api_recovery_service_start(sid):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf();d=request.get_json(silent=True) or {}
    try:
        step=_recovery_service.start_service(sid,actor=session.get('username',''),
            production_approved=bool(d.get('confirm_production')),incident_id=str(d.get('incident_id') or ''))
    except recovery.NotManagedError:return jsonify({"ok":False,"error":"NOT_MANAGED"}),404
    return jsonify({"ok":step.action in ("STARTED","SKIPPED_ALREADY_HEALTHY"),"item":asdict(step)})

@app.post('/api/ops/recovery/services/<sid>/restart')
def api_recovery_service_restart(sid):
    # Advanced/never-primary action (task section 2) -- still allowlist-only.
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf();d=request.get_json(silent=True) or {}
    try:
        step=_recovery_service.restart_service(sid,actor=session.get('username',''),
            production_approved=bool(d.get('confirm_production')),incident_id=str(d.get('incident_id') or ''))
    except recovery.NotManagedError:return jsonify({"ok":False,"error":"NOT_MANAGED"}),404
    return jsonify({"ok":step.action=="RESTARTED","item":asdict(step)})

@app.post('/api/ops/recovery/services/<sid>/stop')
def api_recovery_service_stop(sid):
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf();d=request.get_json(silent=True) or {}
    try:
        step=_recovery_service.stop_service(sid,actor=session.get('username',''),
            production_approved=bool(d.get('confirm_production')),incident_id=str(d.get('incident_id') or ''))
    except recovery.NotManagedError:return jsonify({"ok":False,"error":"NOT_MANAGED"}),404
    return jsonify({"ok":step.action=="STOPPED","item":asdict(step)})

@app.get('/api/ops/recovery/preflight')
def api_recovery_preflight():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    return jsonify(_recovery_service.preflight())

@app.post('/api/ops/recovery/stack')
def api_recovery_stack():
    if not logged_in(): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    verify_csrf();d=request.get_json(silent=True) or {}
    try:
        run=_recovery_service.recover_stack(actor=session.get('username',''),
            production_approved=bool(d.get('confirm_production')),incident_id=str(d.get('incident_id') or ''))
    except recovery.RecoveryAlreadyRunning:
        return jsonify({"ok":False,"error":"RECOVERY_ALREADY_RUNNING"}),409
    return jsonify({"ok":run.status=="COMPLETED","item":asdict(run)})

@app.get('/api/ops/recovery/system-check')
def api_recovery_system_check():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    docker_available=_recovery_service.preflight().get("docker_available",False)
    result=recovery.system_check(ops_summary(),_recovery_service.list_service_views(),docker_available=docker_available)
    return jsonify({"ok":True,**result})

@app.get('/api/ops/recovery/diagnose/<kind>')
def api_recovery_diagnose(kind):
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    if kind not in recovery.DIAGNOSIS_KINDS: return jsonify({"ok":False,"error":"UNKNOWN_DIAGNOSIS_KIND"}),404
    try:
        result=_recovery_service.run_diagnosis(kind,service_id=request.args.get('service',''),host_summary=ops_summary())
    except recovery.NotManagedError:
        return jsonify({"ok":False,"error":"NOT_MANAGED"}),404
    return jsonify({"ok":True,**result})

@app.get('/api/ops/recovery/audit')
def api_recovery_audit():
    if not (logged_in() or _internal_allowed()): return jsonify({"ok":False,"error":"AUTH_REQUIRED"}),401
    items=list(reversed(load_json(RECOVERY_AUDIT_FILE,{"items":[]}).get('items',[])))
    return jsonify({"ok":True,"items":items[:200]})

@app.post("/upload")
def upload_release():
    verify_csrf();u=request.files.get("release_zip")
    append_log(f"MES upload request received: filename={getattr(u,'filename','')!r}")
    if job_running():
        append_log("MES upload rejected: deployment already running")
        flash("Đang deploy","error");return redirect(url_for("index"))
    if not u or not u.filename or not u.filename.lower().endswith('.zip'):
        append_log("MES upload rejected: missing/invalid ZIP")
        flash("Chọn file ZIP","error");return redirect(url_for("index"))
    z=UPLOAD_DIR/f"{int(time.time())}_{secure_filename(u.filename)}";e=UPLOAD_DIR/f"extract_{secrets.token_hex(8)}"
    response={"ok":False,"stage":"uploading"}
    try:
        append_log(f"MES upload saving: {u.filename}")
        u.save(z)
        append_log(f"MES upload saved: bytes={z.stat().st_size}")
        if not zipfile.is_zipfile(z): raise ValueError("Uploaded file is not a valid ZIP")
        append_log("MES upload extracting")
        e.mkdir();safe_extract_zip(z,e);r=locate_root(e)
        append_log(f"MES upload root detected: {r.name}")
        # /upload is now strictly the image-release (Build Once artifact) contract --
        # the legacy manual-upload UI that could send a non-image-release ZIP has
        # been removed (see reports/RELEASE_DEPLOY_UX_CLEANUP.md); the only caller
        # left is _remote_agent_upload(), which always transfers image-release-type
        # artifacts produced by Deploy Local.
        v,meta=validate_image_release_contract(r)
        append_log(f"MES upload version detected: {v}")
        append_log(f"MES upload validated: version={v}, root={r.name}, protocol={meta.get('deployment_protocol',1)}")
        t=RELEASES_DIR/v
        replacement=RELEASES_DIR/f".{v}.replacement-{secrets.token_hex(6)}"
        shutil.copytree(r,replacement)
        save_json(replacement/"agent_manifest.json",{"version":v,"uploaded_at":now_text(),"source_name":u.filename,"sha256":sha(z)})
        if t.exists():
            append_log(f"Version {v} already exists; replacing old release staging for retry")
            flash(f"Version {v} đã tồn tại; đang thay thế release staging cũ", "warning")
            old=RELEASES_DIR/f".{v}.previous-{secrets.token_hex(6)}"
            t.replace(old)
            try: replacement.replace(t)
            except Exception:
                old.replace(t)
                raise
            shutil.rmtree(old,ignore_errors=True)
        else:
            replacement.replace(t)
        append_log(f"MES release stored: {v}")
        append_log(f"MES deploy job started: {v}")
        start_deploy(v)
        flash(f"Đã upload và bắt đầu deploy MESFlow {v}","success")
        response={"ok":True,"stage":"queued","version":v,"message":f"Đã nhận ZIP {v}; đang xếp hàng deploy.","redirect_url":url_for("release_manager_page")}
    except Exception as ex:
        append_log(f"MES upload/deploy failed before redirect: stage=upload_or_validation exception={type(ex).__name__} error={ex}")
        flash(f"Upload / deploy MESFlow thất bại: {ex}","error")
        response={"ok":False,"stage":"upload_or_validation","error_class":type(ex).__name__,"error":str(ex)}
    finally:
        z.unlink(missing_ok=True);shutil.rmtree(e,ignore_errors=True)
    if request.headers.get("X-Requested-With")=="XMLHttpRequest":
        return jsonify(response), (200 if response["ok"] else 400)
    return redirect(url_for("index"))

# KEEP -- this is NOT the legacy manual-upload flow. _remote_agent_deploy()
# (default path_fmt="/deploy/{}") is called explicitly by _run_promote_test()
# right after _remote_agent_upload(), i.e. this route is the REAL trigger the
# current MESFlow TEST-promotion machine-to-machine flow depends on. Found
# via a real audit mistake during this task: an earlier pass deleted this
# route on the (wrong) assumption that /upload's own auto-deploy was the only
# trigger in play; _run_promote_test's explicit second call proves otherwise.
@app.post("/deploy/<version>")
def deploy(version):
    verify_csrf()
    try:
        version=norm(version);start_deploy(version);flash(f"Đã bắt đầu deploy {version}","success")
    except Exception as ex:
        flash(str(ex),"error")
    return redirect(url_for("index"))

# --- QA Center image-release receive (target side: PRODUCTION_TEST/PRODUCTION) ---
# Distinct routes from the legacy /qa/upload (full-source ZIP, auto-deploys,
# bind-mounted at runtime -- kept working unmodified). These only ever
# receive an immutable QA image-release artifact (image + compose.yml +
# metadata, never application source) and deploy it --no-build. Store-only
# on upload; /qa-release/deploy/<version> is the sole deploy trigger (no
# redundant double-deploy-call ambiguity).

TUTORIAL_CHUNK_DIR=TUTORIAL_UPLOAD_DIR/"chunked"; TUTORIAL_CHUNK_DIR.mkdir(parents=True,exist_ok=True)
TUTORIAL_CHUNK_MAX_BYTES=max(1024*1024,min(int(os.environ.get("MESFLOW_TUTORIAL_UPLOAD_CHUNK_MAX_MB","32"))*1024*1024,64*1024*1024))
TUTORIAL_MAX_ARTIFACT_BYTES=max(1024*1024,int(os.environ.get("MESFLOW_TUTORIAL_UPLOAD_MAX_ARTIFACT_MB","8192"))*1024*1024)

def _tutorial_chunk_dir(upload_id):
    if not re.fullmatch(r"[0-9a-f]{32}",str(upload_id or "")): raise ValueError("INVALID_UPLOAD_ID")
    return TUTORIAL_CHUNK_DIR/upload_id

def _tutorial_unpack_publish(artifact,expected_sha):
    if SERVER_ROLE=="PRODUCTION": raise PermissionError("TUTORIAL_PRODUCTION_DEPLOY_BLOCKED")
    artifact=Path(artifact)
    if sha(artifact)!=expected_sha: raise ValueError("TUTORIAL_FINAL_SHA256_MISMATCH")
    temp=Path(tempfile.mkdtemp(prefix="tutorial-unpack-",dir=str(TUTORIAL_UPLOAD_DIR)))
    try:
        total=0
        with artifact.open("rb") as raw, zstandard.ZstdDecompressor().stream_reader(raw) as reader, tarfile.open(fileobj=reader,mode="r|") as archive:
            for member in archive:
                name=str(member.name).replace("\\","/")
                target=(temp/name).resolve(); target.relative_to(temp.resolve())
                if member.issym() or member.islnk() or member.isdir():
                    if member.isdir() and name.rstrip('/') in {'videos'}: target.mkdir(parents=True,exist_ok=True)
                    elif not member.isdir(): raise ValueError("TUTORIAL_ARCHIVE_LINK_REJECTED")
                    continue
                if not member.isfile() or (name!="manifest.json" and not re.fullmatch(r"videos/[A-Za-z0-9._-]+\.(mp4|webm)",name,re.I)):
                    raise ValueError("TUTORIAL_ARCHIVE_MEMBER_REJECTED")
                total+=int(member.size or 0)
                if total>TUTORIAL_MAX_ARTIFACT_BYTES: raise ValueError("TUTORIAL_EXTRACT_TOO_LARGE")
                target.parent.mkdir(parents=True,exist_ok=True); source=archive.extractfile(member)
                with target.open("wb") as out: shutil.copyfileobj(source,out)
        manifest=_tutorial_validate_tree(temp)[0]
        _tutorial_atomic_publish(temp,TARGET_HOME/"runtime/tutorials")
        def done(state): state["tutorial_deploy"]={"status":"DEPLOYED","stage":"DEPLOYED","sha256":expected_sha,"artifact_name":artifact.name,"video_count":manifest["video_count"],"deployed_at":now_text()}
        update_state(done); return manifest
    finally: shutil.rmtree(temp,ignore_errors=True)

@app.post("/tutorial-release/chunk/start")
def tutorial_chunk_start():
    verify_csrf()
    if SERVER_ROLE=="PRODUCTION": return jsonify(ok=False,error="TUTORIAL_PRODUCTION_DEPLOY_BLOCKED"),403
    p=request.get_json(silent=True) or {}; filename=secure_filename(str(p.get("filename") or "")); digest=str(p.get("sha256") or "").lower()
    try: size=int(p.get("total_size") or 0); chunk_size=int(p.get("chunk_size") or 0)
    except Exception: size=chunk_size=0
    if not filename.endswith(".tar.zst"): return jsonify(ok=False,error="TUTORIAL_INVALID_FILENAME"),400
    if size<=0 or size>TUTORIAL_MAX_ARTIFACT_BYTES or chunk_size<=0 or chunk_size>TUTORIAL_CHUNK_MAX_BYTES or not re.fullmatch(r"[0-9a-f]{64}",digest): return jsonify(ok=False,error="TUTORIAL_INVALID_UPLOAD_CONTRACT"),400
    upload_id=uuid.uuid4().hex; d=_tutorial_chunk_dir(upload_id); d.mkdir(); save_json(d/"meta.json",{"filename":filename,"total_size":size,"sha256":digest,"chunk_size":chunk_size,"received":0,"next_index":0,"created_at":now_text()}); (d/"payload.part").touch()
    return jsonify(ok=True,upload_id=upload_id,max_chunk_bytes=TUTORIAL_CHUNK_MAX_BYTES)

@app.post("/tutorial-release/chunk/<upload_id>/<int:index>")
def tutorial_chunk_put(upload_id,index):
    verify_csrf()
    try:
        d=_tutorial_chunk_dir(upload_id); meta=load_json(d/"meta.json",{})
        if not meta: raise ValueError("TUTORIAL_UPLOAD_NOT_FOUND")
        if index!=int(meta["next_index"]): raise ValueError(f"TUTORIAL_CHUNK_OUT_OF_ORDER expected={meta['next_index']} got={index}")
        data=request.get_data(cache=False); expected=request.headers.get("X-Chunk-SHA256","").lower()
        if not data or len(data)>TUTORIAL_CHUNK_MAX_BYTES or hashlib.sha256(data).hexdigest()!=expected: raise ValueError("TUTORIAL_CHUNK_SHA256_MISMATCH")
        meta["received"]=int(meta["received"])+len(data)
        if meta["received"]>int(meta["total_size"]): raise ValueError("TUTORIAL_CHUNK_EXCEEDS_TOTAL")
        with (d/"payload.part").open("ab") as out: out.write(data)
        meta["next_index"]=index+1; save_json(d/"meta.json",meta); return jsonify(ok=True,index=index,received=meta["received"],total_size=meta["total_size"])
    except Exception as ex: return jsonify(ok=False,error=str(ex)),400

@app.post("/tutorial-release/chunk/<upload_id>/complete")
def tutorial_chunk_complete(upload_id):
    verify_csrf(); p=request.get_json(silent=True) or {}
    try:
        d=_tutorial_chunk_dir(upload_id); meta=load_json(d/"meta.json",{}); part=d/"payload.part"
        if not meta or int(meta["received"])!=int(meta["total_size"]) or part.stat().st_size!=int(meta["total_size"]): raise ValueError("TUTORIAL_MISSING_CHUNK")
        if int(p.get("chunks",-1))!=int(meta["next_index"]): raise ValueError("TUTORIAL_CHUNK_COUNT_MISMATCH")
        if sha(part)!=meta["sha256"]: raise ValueError("TUTORIAL_FINAL_SHA256_MISMATCH")
        manifest=_tutorial_unpack_publish(part,meta["sha256"]); shutil.rmtree(d,ignore_errors=True)
        return jsonify(ok=True,status="DEPLOYED",sha256=meta["sha256"],video_count=manifest["video_count"])
    except Exception as ex: return jsonify(ok=False,error=str(ex)),400

@app.post("/tutorial-release/chunk/<upload_id>/abort")
def tutorial_chunk_abort(upload_id):
    verify_csrf(); shutil.rmtree(_tutorial_chunk_dir(upload_id),ignore_errors=True); return jsonify(ok=True)

@app.get("/api/tutorial-release/status")
def tutorial_release_status(): return jsonify(ok=True,tutorial=load_state().get("tutorial_deploy") or {"status":"NOT_DEPLOYED"})

def _stage_qa_release_zip(z,source_name):
    """Validate and atomically stage one completed immutable QA release ZIP.
    Shared by the legacy single-request receiver and the chunked receiver."""
    z=Path(z); e=QA_UPLOAD_DIR/f"extract_{secrets.token_hex(8)}"
    try:
        if not zipfile.is_zipfile(z): raise ValueError("Uploaded file is not a valid ZIP")
        e.mkdir(); safe_extract_zip(z,e); r=locate_qa_image_release_root(e)
        v,meta=validate_qa_image_release_contract(r)
        append_log(f"QA image-release validated: version={v}")
        t=QA_IMAGE_RELEASES_DIR/v
        replacement=QA_IMAGE_RELEASES_DIR/f".{v}.replacement-{secrets.token_hex(6)}"
        shutil.copytree(r,replacement)
        save_json(replacement/"agent_manifest.json",{"version":v,"uploaded_at":now_text(),"source_name":source_name,"sha256":sha(z)})
        if t.exists():
            old=QA_IMAGE_RELEASES_DIR/f".{v}.previous-{secrets.token_hex(6)}"
            t.replace(old)
            try: replacement.replace(t)
            except Exception:
                old.replace(t); raise
            shutil.rmtree(old,ignore_errors=True)
        else:
            replacement.replace(t)
        append_log(f"QA image-release stored: {v}")
        return v
    finally:
        shutil.rmtree(e,ignore_errors=True)

@app.post("/qa-release/upload")
def qa_release_upload():
    """Legacy single-request QA receiver, retained for compatibility.
    New promotion clients use the chunked routes below so large image bundles
    never hit reverse-proxy/cloud request-body limits."""
    verify_csrf(); u=request.files.get("qa_release_zip")
    append_log(f"QA image-release upload received: filename={getattr(u,'filename','')!r}")
    if not u or not u.filename or not u.filename.lower().endswith('.zip'):
        return jsonify(ok=False,error="Chọn file ZIP QA hợp lệ"),400
    z=QA_UPLOAD_DIR/f"qa_release_{int(time.time())}_{secure_filename(u.filename)}"
    try:
        u.save(z)
        v=_stage_qa_release_zip(z,u.filename)
        return jsonify(ok=True,version=v,message=f"Đã nhận QA release {v}")
    except Exception as ex:
        append_log(f"QA image-release upload failed: {type(ex).__name__}: {ex}")
        return jsonify(ok=False,error=str(ex)),400
    finally:
        z.unlink(missing_ok=True)

QA_CHUNK_DIR=QA_UPLOAD_DIR/"chunked"
QA_CHUNK_DIR.mkdir(parents=True,exist_ok=True)
QA_CHUNK_MAX_BYTES=max(1024*1024,min(int(os.environ.get("MESFLOW_QA_UPLOAD_CHUNK_MAX_MB","32"))*1024*1024,64*1024*1024))
QA_CHUNK_MAX_ARTIFACT_BYTES=max(1024*1024,int(os.environ.get("MESFLOW_QA_UPLOAD_MAX_ARTIFACT_MB","8192"))*1024*1024)

def _qa_chunk_upload_dir(upload_id):
    if not re.fullmatch(r"[0-9a-f]{32}",str(upload_id or "")): raise ValueError("INVALID_UPLOAD_ID")
    return QA_CHUNK_DIR/upload_id

def _qa_chunk_meta(upload_id):
    d=_qa_chunk_upload_dir(upload_id); meta=load_json(d/"meta.json",{})
    if not meta: raise ValueError("QA_CHUNK_UPLOAD_NOT_FOUND")
    return d,meta

@app.post("/qa-release/chunk/start")
def qa_release_chunk_start():
    verify_csrf(); payload=request.get_json(silent=True) or {}
    filename=secure_filename(str(payload.get("filename") or ""))
    try: total_size=int(payload.get("total_size") or 0)
    except Exception: total_size=0
    expected_sha=str(payload.get("sha256") or "").lower()
    try: requested_chunk=int(payload.get("chunk_size") or 0)
    except Exception: requested_chunk=0
    if not filename.lower().endswith('.zip'): return jsonify(ok=False,error="QA_CHUNK_INVALID_FILENAME"),400
    if total_size<=0 or total_size>QA_CHUNK_MAX_ARTIFACT_BYTES: return jsonify(ok=False,error="QA_CHUNK_INVALID_TOTAL_SIZE"),400
    if not re.fullmatch(r"[0-9a-f]{64}",expected_sha): return jsonify(ok=False,error="QA_CHUNK_INVALID_SHA256"),400
    if requested_chunk<=0 or requested_chunk>QA_CHUNK_MAX_BYTES: return jsonify(ok=False,error="QA_CHUNK_SIZE_NOT_ALLOWED",max_bytes=QA_CHUNK_MAX_BYTES),400
    upload_id=uuid.uuid4().hex; d=QA_CHUNK_DIR/upload_id; d.mkdir(parents=True)
    meta={"filename":filename,"total_size":total_size,"sha256":expected_sha,"chunk_size":requested_chunk,
          "next_index":0,"received":0,"created_at":now_text()}
    save_json(d/"meta.json",meta); (d/"payload.zip.part").touch()
    append_log(f"QA chunked upload started: id={upload_id} file={filename} bytes={total_size} chunk={requested_chunk}")
    return jsonify(ok=True,upload_id=upload_id,max_chunk_bytes=QA_CHUNK_MAX_BYTES)

@app.post("/qa-release/chunk/<upload_id>/<int:index>")
def qa_release_chunk_put(upload_id,index):
    verify_csrf()
    try:
        d,meta=_qa_chunk_meta(upload_id)
        if index!=int(meta.get("next_index",0)): raise ValueError(f"QA_CHUNK_OUT_OF_ORDER expected={meta.get('next_index')} got={index}")
        content_length=request.content_length
        if content_length is not None and (content_length<=0 or content_length>QA_CHUNK_MAX_BYTES): raise ValueError("QA_CHUNK_TOO_LARGE")
        data=request.get_data(cache=False)
        if not data or len(data)>QA_CHUNK_MAX_BYTES: raise ValueError("QA_CHUNK_TOO_LARGE_OR_EMPTY")
        expected=request.headers.get("X-Chunk-SHA256","").lower()
        actual=hashlib.sha256(data).hexdigest()
        if not re.fullmatch(r"[0-9a-f]{64}",expected) or actual!=expected: raise ValueError("QA_CHUNK_SHA256_MISMATCH")
        received=int(meta.get("received",0))+len(data)
        if received>int(meta["total_size"]): raise ValueError("QA_CHUNK_EXCEEDS_TOTAL_SIZE")
        with (d/"payload.zip.part").open("ab") as f: f.write(data)
        meta["received"]=received; meta["next_index"]=index+1; save_json(d/"meta.json",meta)
        return jsonify(ok=True,upload_id=upload_id,index=index,received=received,total_size=meta["total_size"])
    except Exception as ex:
        append_log(f"QA chunk upload failed: id={upload_id} index={index} error={ex}")
        return jsonify(ok=False,error=str(ex)),400

@app.post("/qa-release/chunk/<upload_id>/complete")
def qa_release_chunk_complete(upload_id):
    verify_csrf(); payload=request.get_json(silent=True) or {}
    try:
        d,meta=_qa_chunk_meta(upload_id); part=d/"payload.zip.part"
        expected_sha=str(meta["sha256"]); expected_size=int(meta["total_size"])
        if int(meta.get("received",0))!=expected_size or part.stat().st_size!=expected_size: raise ValueError("QA_CHUNK_FINAL_SIZE_MISMATCH")
        if payload.get("total_size") is not None and int(payload["total_size"])!=expected_size: raise ValueError("QA_CHUNK_CLIENT_SIZE_MISMATCH")
        if payload.get("sha256") and str(payload["sha256"]).lower()!=expected_sha: raise ValueError("QA_CHUNK_CLIENT_SHA_MISMATCH")
        if payload.get("chunks") is not None and int(payload["chunks"])!=int(meta.get("next_index",0)): raise ValueError("QA_CHUNK_COUNT_MISMATCH")
        actual_sha=sha(part)
        if actual_sha!=expected_sha: raise ValueError("QA_CHUNK_FINAL_SHA256_MISMATCH")
        final=QA_UPLOAD_DIR/f"qa_release_chunked_{int(time.time())}_{meta['filename']}"
        part.replace(final)
        try:
            version=_stage_qa_release_zip(final,meta["filename"])
        finally:
            final.unlink(missing_ok=True)
        shutil.rmtree(d,ignore_errors=True)
        append_log(f"QA chunked upload completed: id={upload_id} version={version} bytes={expected_size}")
        return jsonify(ok=True,version=version,sha256=actual_sha,total_size=expected_size)
    except Exception as ex:
        append_log(f"QA chunk complete failed: id={upload_id} error={ex}")
        return jsonify(ok=False,error=str(ex)),400

@app.post("/qa-release/chunk/<upload_id>/abort")
def qa_release_chunk_abort(upload_id):
    verify_csrf()
    try: d=_qa_chunk_upload_dir(upload_id); shutil.rmtree(d,ignore_errors=True)
    except Exception as ex: return jsonify(ok=False,error=str(ex)),400
    return jsonify(ok=True,upload_id=upload_id)

@app.post("/qa-release/deploy/<version>")
def qa_release_deploy(version):
    verify_csrf()
    try:
        version=norm(version)
        root=QA_IMAGE_RELEASES_DIR/version
        if not (root/"release.json").is_file(): raise ValueError(f"QA release {version} not uploaded to this Agent yet")
        start_qa_target_deploy(version)
        return jsonify(ok=True,version=version,message=f"Đã bắt đầu deploy QA {version}")
    except Exception as ex:
        return jsonify(ok=False,error=str(ex)),400
@app.post("/qa/restart")
def qa_restart():
    # Task section 40: an operation on a tab must not bounce the user back
    # to a different page -- these controls now live on the Release Deploy
    # tab's QA Center card.
    if not HOST_OPS_ENABLED: flash("QA host restart is disabled in this container runtime","error"); return redirect(url_for("release_manager_page",tab="deploy"))
    verify_csrf()
    try:
        if qa_job_running(): raise RuntimeError("QA Center đang deploy")
        if qa_current_version()=="Chưa cài": raise RuntimeError("QA Center chưa được cài")
        _stop_qa()
        pid=_start_qa(); _wait_qa(qa_current_version(),pid=pid); flash("Đã restart QA Center","success")
    except Exception as ex: flash(f"Restart QA thất bại: {ex}","error")
    return redirect(url_for("release_manager_page",tab="deploy"))

@app.post("/qa/stop")
def qa_stop():
    if not HOST_OPS_ENABLED: flash("QA host stop is disabled in this container runtime","error"); return redirect(url_for("release_manager_page",tab="deploy"))
    verify_csrf()
    try:
        _stop_qa()
        flash("Đã dừng QA Center","success")
    except Exception as ex: flash(f"Dừng QA thất bại: {ex}","error")
    return redirect(url_for("release_manager_page",tab="deploy"))

@app.post("/change-password")
def change_password():
    verify_csrf();c=ensure_config();old=request.form.get("old_password","");new=request.form.get("new_password","")
    if not check_password_hash(c["password_hash"],old):flash("Mật khẩu hiện tại không đúng","error")
    elif len(new)<10:flash("Mật khẩu mới tối thiểu 10 ký tự","error")
    else:c["password_hash"]=generate_password_hash(new);save_json(CONFIG_FILE,c);(CONFIG_DIR/"FIRST_LOGIN.txt").unlink(missing_ok=True);flash("Đã đổi mật khẩu","success")
    # Task section 40: an operation on a specific tab must not bounce the
    # user back to a different page -- this form now lives on Agent Update.
    return redirect(url_for("release_manager_page",tab="agent-update")+"#securitySettings")
@app.get("/live")
def live():return {"ok":True,"agent_version":AGENT_VERSION,"frontend_build_id":FRONTEND_BUILD_ID,"runtime_mode":RUNTIME_MODE}
@app.get("/health")
def health():return {"ok":True,"agent_version":AGENT_VERSION,"api_protocol_version":API_PROTOCOL_VERSION,"capabilities":AGENT_CAPABILITIES,"runtime_mode":RUNTIME_MODE,"server_role":SERVER_ROLE,"build_enabled":MESFLOW_BUILD_ENABLED,"source_dir":str(MESFLOW_SOURCE_DIR),"deploy_enabled":DEPLOY_ENABLED,"host_ops_enabled":HOST_OPS_ENABLED,"mes":mes_status(),"qa":qa_status(),"job_running":job_running(),"qa_job_running":qa_job_running(),"tutorial_job_running":tutorial_job_running(),"esp_tutorial_job_running":_esp_tutorial_job_lock.locked(),"esp_tutorial":esp_tutorial_status()}
def main():
    recover_interrupted_deploy(); job_running()
    reconcile_orphaned_jobs_on_startup()
    # Operations Center incident monitoring must keep running independently
    # of whether anyone has the UI open, and independently of MESFlow's own
    # availability (section 5) -- a background daemon thread, not tied to
    # any HTTP request.
    start_incident_monitor()
    start_predictive_monitor()
    start_fleet_health_monitor()
    append_log(f"Agent {AGENT_VERSION} start {HOST}:{PORT}, MES={MES_URL}, QA={QA_URL}")
    # Configurable (never below 8, the long-established default): a fleet
    # of Remote Agents now also serves Agent-to-Agent calls on top of the
    # human UI, and a fixed small pool can be exhausted by many concurrent/
    # retried connections (observed while load-testing P5's multi-server
    # test harness -- see reports/P5_MULTI_SERVER.md).
    serve(app,host=HOST,port=PORT,threads=max(8,int(os.environ.get("WORKSHOP_AGENT_THREADS","8") or 8)))

# === AGENT PACKAGE COMPLETE UI v1 ===
def _agent_package_candidate_roots():
    roots=[]
    configured=os.environ.get("MESFLOW_AGENT_PACKAGE_DIR","").strip()
    if configured:
        roots.append(Path(configured))
    here=Path(__file__).resolve().parent
    roots += [
        here/"artifacts",
        here.parent/"artifacts"/"deploy-agent",
        here.parent/"artifacts"/"deploy-agent"/"releases",
        Path("/workspace/mesflow/artifacts/deploy-agent"),
        Path("/workspace/mesflow/artifacts/deploy-agent/releases"),
    ]
    out=[]; seen=set()
    for p in roots:
        try: key=str(p.resolve())
        except Exception: key=str(p)
        if key not in seen:
            seen.add(key); out.append(p)
    return out

def _agent_latest_package():
    release=_latest_agent_release()
    if not release.get("package_exists"):
        return None
    p=Path(release["package"])
    st=p.stat()
    source_version=_deploy_agent_source_version()
    return {
        "filename":p.name,
        "path":str(p),
        "version":release.get("version",""),
        "sha256":sha(p),
        "size":st.st_size,
        "size_mb":round(st.st_size/1024/1024,2),
        "built_at":release.get("built_at") or datetime.fromtimestamp(st.st_mtime).astimezone().isoformat(timespec="seconds"),
        "source_version":source_version,
        "runtime_version":AGENT_VERSION,
        "is_current_source":release.get("version")==source_version,
    }

@app.get("/api/agent-package/latest")
def agent_package_latest_complete():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    pkg=_agent_latest_package()
    source_version=_deploy_agent_source_version()
    return jsonify(ok=True,package=pkg,source_version=source_version,runtime_version=AGENT_VERSION,
                   bootstrap_url=os.environ.get("MESFLOW_BOOTSTRAP_URL","").strip())

@app.get("/api/agent-package/download")
def agent_package_download_complete():
    if not logged_in(): return jsonify(ok=False,error="AUTH_REQUIRED"),401
    pkg=_agent_latest_package()
    if not pkg: return jsonify(ok=False,error="AGENT_PACKAGE_NOT_FOUND"),404
    p=Path(pkg["path"])
    allowed=False
    for root in _agent_package_candidate_roots():
        try:
            p.resolve().relative_to(root.resolve()); allowed=True; break
        except Exception:
            pass
    if not allowed or not p.is_file():
        return jsonify(ok=False,error="AGENT_PACKAGE_PATH_NOT_ALLOWED"),403
    return send_file(p,as_attachment=True,download_name=p.name,mimetype="application/zip")


if __name__=="__main__":main()
