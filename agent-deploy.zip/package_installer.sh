#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
VERSION="$(tr -d '\r\n' < "$ROOT/VERSION.txt")"
NAME="MESFlow_Server_Bootstrap_Agent_First_v${VERSION}"
OUT="${1:-$ROOT/../artifacts/deploy-agent/${NAME}.zip}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$WORK/$NAME/payload"
cp "$ROOT/installer/install.sh" "$ROOT/installer/update-gateway.sh" "$ROOT/installer/diagnose-gateway.sh" "$ROOT/installer/README.md" "$WORK/$NAME/"
# Reuse the same allow/exclude and secret gate as the source package.  The
# former cp -a copied .git/.venv and then tried to clean a small subset,
# which was both large and easy to get wrong.
SOURCE_ZIP="$WORK/source.zip"
python3 "$ROOT/tools/build_source_package.py" "$SOURCE_ZIP" >/dev/null
unzip -q "$SOURCE_ZIP" -d "$WORK/source"
SOURCE_ROOT="$WORK/source/mesflow-deploy-agent-source-${VERSION}"
test -f "$SOURCE_ROOT/agent.py" -a -f "$SOURCE_ROOT/VERSION.txt"
cp -a "$SOURCE_ROOT" "$WORK/$NAME/payload/mesflow-deploy-agent"
rm -rf "$WORK/$NAME/payload/mesflow-deploy-agent/installer"
chmod +x "$WORK/$NAME/install.sh" "$WORK/$NAME/update-gateway.sh" "$WORK/$NAME/diagnose-gateway.sh"
mkdir -p "$(dirname "$OUT")"
(cd "$WORK" && zip -qr "$OUT" "$NAME")
echo "$OUT"
